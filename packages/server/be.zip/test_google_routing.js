import { 
  isGemmaModel, 
  validateGemmaModel, 
  parseGemmaThoughts, 
  compileGoogleEndpoint 
} from "./dist/core/modelRouter.js";

async function runTest() {
  console.log("=== STARTING GOOGLE PROVIDER ROUTING & GEMMA 4 THINKING INTEGRATION TEST ===");

  // Test Case 1: isGemmaModel & validateGemmaModel
  console.log("\n--- TEST CASE 1: Gemma String Validation Constraints ---");
  
  // 1.1 Standard Gemini check
  const isGeminiGemma = isGemmaModel("gemini-2.0-flash");
  console.log(`Is 'gemini-2.0-flash' a Gemma model? ${isGeminiGemma}`);
  if (isGeminiGemma) throw new Error("Incorrectly detected Gemini as a Gemma model.");

  // 1.2 Gemma check
  const isGemmaGemma = isGemmaModel("gemma-4-31b-it");
  console.log(`Is 'gemma-4-31b-it' a Gemma model? ${isGemmaGemma}`);
  if (!isGemmaGemma) throw new Error("Failed to detect Gemma 4 as a Gemma model.");

  // 1.3 Validate Gemma 4 approval
  console.log("Validating 'gemma-4-31b-it' (should succeed)...");
  validateGemmaModel("gemma-4-31b-it"); 
  console.log("Success: Gemma 4 approved successfully.");

  // 1.4 Validate Legacy Gemma 2 rejection
  console.log("Validating 'gemma-2-9b-it' (should be rejected and warn)...");
  try {
    validateGemmaModel("gemma-2-9b-it");
    throw new Error("Failed to reject legacy Gemma 2 model!");
  } catch (err) {
    console.log(`Success: Legacy Gemma 2 rejected correctly with message: "${err.message}"`);
  }

  // 1.5 Validate Generic Gemma rejection
  console.log("Validating 'gemma' (should be rejected and warn)...");
  try {
    validateGemmaModel("gemma");
    throw new Error("Failed to reject generic legacy Gemma model!");
  } catch (err) {
    console.log(`Success: Generic Gemma rejected correctly with message: "${err.message}"`);
  }


  // Test Case 2: compileGoogleEndpoint (AI Studio vs Vertex AI)
  console.log("\n--- TEST CASE 2: Cloud Endpoint Compilation ---");

  // 2.1 Google AI Studio configuration
  const aiStudioConfig = {
    modelName: "gemma-4-31b-it",
    apiKey: "ai-studio-api-key-xyz",
    baseUrl: ""
  };
  const studioParams = compileGoogleEndpoint(aiStudioConfig);
  console.log("AI Studio URL:", studioParams.url);
  console.log("AI Studio Headers:", JSON.stringify(studioParams.headers));
  if (!studioParams.url.includes("generativelanguage.googleapis.com") || !studioParams.url.includes("key=ai-studio-api-key-xyz")) {
    throw new Error("AI Studio endpoint URL compiled incorrectly!");
  }

  // 2.2 Google Cloud Vertex AI configuration
  const vertexConfig = {
    modelName: "gemma-4-26b-a4b-it",
    apiKey: "oauth2-bearer-token-abc",
    baseUrl: "https://us-east4-aiplatform.googleapis.com/v1/projects/my-agentic-org/locations/us-east4/publishers/google/models/"
  };
  const vertexParams = compileGoogleEndpoint(vertexConfig);
  console.log("Vertex AI URL:", vertexParams.url);
  console.log("Vertex AI Headers:", JSON.stringify(vertexParams.headers));
  if (!vertexParams.url.includes("us-east4-aiplatform.googleapis.com") || !vertexParams.url.includes("/projects/my-agentic-org/locations/us-east4")) {
    throw new Error("Vertex AI endpoint URL compiled incorrectly!");
  }
  if (vertexParams.headers["Authorization"] !== "Bearer oauth2-bearer-token-abc") {
    throw new Error("Vertex AI bearer headers compiled incorrectly!");
  }

  // 2.3 Body builder system instruction test
  const body = vertexParams.bodyBuilder("System Directive: Answer concisely.", "User Question text");
  console.log("Request Payload Body:", JSON.stringify(body, null, 2));
  if (body.systemInstruction.parts[0].text !== "System Directive: Answer concisely.") {
    throw new Error("Body builder failed to inject systemInstruction natively!");
  }
  if (body.contents[0].parts[0].text !== "User Question text") {
    throw new Error("Body builder failed to inject user content!");
  }


  // Test Case 3: parseGemmaThoughts Delimiter Extraction
  console.log("\n--- TEST CASE 3: Gemma 4 Thinking Mode Delimiter Parsing ---");

  // 3.1 Test native Gemma 4 delimiters <|channel>thought ... <channel|>
  const rawGemma4Text = `<|channel>thought
1. User asked for a database select.
2. I must compile target query sequence.
3. Returning sql code.
<channel|>Here is the SQL query: SELECT * FROM messages;`;

  const parsedGemma4 = parseGemmaThoughts(rawGemma4Text);
  console.log("Extracted Thoughts:\n", parsedGemma4.thoughts);
  console.log("Extracted Answer:\n", parsedGemma4.answer);

  if (parsedGemma4.thoughts !== "1. User asked for a database select.\n2. I must compile target query sequence.\n3. Returning sql code.") {
    throw new Error("Gemma 4 native thought extraction failed!");
  }
  if (parsedGemma4.answer !== "Here is the SQL query: SELECT * FROM messages;") {
    throw new Error("Gemma 4 native answer cleaning failed!");
  }

  // 3.2 Test general thinking delimiters <|think|> ... </|think|>
  const rawThinkText = `<|think|>Analyzing loop counts...</|think|>All operations cleared.`;
  const parsedThink = parseGemmaThoughts(rawThinkText);
  console.log("Extracted Thoughts:", parsedThink.thoughts);
  console.log("Extracted Answer:", parsedThink.answer);

  if (parsedThink.thoughts !== "Analyzing loop counts...") {
    throw new Error("Alternate <|think|> delimiter parsing failed!");
  }
  if (parsedThink.answer !== "All operations cleared.") {
    throw new Error("Alternate <|think|> answer cleaning failed!");
  }

  console.log("\n=== INTEGRATION TEST PASSED SUCCESSFULLY ===");
}

runTest().catch((err) => {
  console.error("Test failed:", err);
  process.exit(1);
});
