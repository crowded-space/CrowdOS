import { eq } from "drizzle-orm";
import { getDb, closeDatabaseConnection } from "./dist/config/database.js";
import { EventBroker } from "./dist/core/EventBroker.js";
import { IndexBuilder } from "./dist/core/IndexBuilder.js";
import { ToolExecutor } from "./dist/tools/ToolExecutor.js";
import {
  agents,
  channels,
  messages,
  channelIndex,
  compressedSummaries,
  toolkitModules
} from "./dist/db/schema.js";

async function runTest() {
  console.log("=== STARTING FEATURE 16 INDEX & OMNISCIENT INTEGRATION TEST ===");
  const db = getDb();

  // 1. Get or create general channel
  let ch = await db.query.channels.findFirst({
    where: eq(channels.name, "general"),
  });
  if (!ch) {
    console.log("Creating temporary general channel...");
    ch = {
      id: "ch-test-index",
      categoryId: null,
      name: "general",
      type: "standard",
      createdBy: "system",
      position: 0,
      createdAt: new Date(),
    };
    await db.insert(channels).values(ch);
  }
  const channelId = ch.id;

  // Clean up any existing index and summary logs for this channel to guarantee a clean state
  await db.delete(channelIndex).where(eq(channelIndex.channelId, channelId));
  await db.delete(compressedSummaries).where(eq(compressedSummaries.channelId, channelId));

  // 2. Fetch seeded Librarian Specialist agent
  let librarian = await db.query.agents.findFirst({
    where: eq(agents.id, "agent-librarian"),
  });
  if (!librarian) {
    throw new Error("Seeded @agent-librarian not found! Run seed command first.");
  }
  console.log(`Librarian agent verified: @${librarian.name} (isOmniscient: ${librarian.isOmniscient}, Authority: L${librarian.authorityLevel})`);

  // 3. Create a non-omniscient L3 Worker Sparrow agent to test security guards
  let sparrow = await db.query.agents.findFirst({
    where: eq(agents.id, "agent-sparrow-test"),
  });

  if (!sparrow) {
    console.log("Creating mock non-omniscient Sparrow Agent...");
    const model = await db.query.modelModules.findFirst();
    const inst = await db.query.instructionModules.findFirst();
    const toolkit = await db.query.toolkitModules.findFirst();

    sparrow = {
      id: "agent-sparrow-test",
      name: "Sparrow_Coder",
      title: "Worker Coder",
      species: "Sparrow",
      authorityLevel: 3,
      modelModuleId: model?.id || "fallback-model",
      instructionModuleId: inst?.id || "fallback-instruction",
      toolkitModuleId: toolkit?.id || "fallback-toolkit",
      memorySharingPolicy: "vertical",
      isOmniscient: false,
      status: "idle",
      isTemplate: false,
      permissions: { spawnAgents: false, patchRuntime: false, accessAllChannels: false },
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    await db.insert(agents).values(sparrow);
  }

  // Ensure sparrow has a valid toolkit module and authorize the search tool inside it to test authLevel restriction
  if (sparrow.toolkitModuleId) {
    const tk = await db.query.toolkitModules.findFirst({
      where: eq(toolkitModules.id, sparrow.toolkitModuleId),
    });
    if (tk && !tk.tools.includes("search_all_channels")) {
      console.log(`Authorizing search_all_channels inside Sparrow's toolkit module ${tk.id} to test L0 authority block...`);
      await db.update(toolkitModules)
        .set({
          tools: [...tk.tools, "search_all_channels"]
        })
        .where(eq(toolkitModules.id, tk.id));
    }
  }

  // Ensure Librarian has `search_all_channels` authorized inside its toolkit
  if (librarian.toolkitModuleId) {
    const tk = await db.query.toolkitModules.findFirst({
      where: eq(toolkitModules.id, librarian.toolkitModuleId),
    });
    if (tk && !tk.tools.includes("search_all_channels")) {
      console.log(`Authorizing search_all_channels inside Librarian's toolkit module ${tk.id}...`);
      await db.update(toolkitModules)
        .set({
          tools: [...tk.tools, "search_all_channels"]
        })
        .where(eq(toolkitModules.id, tk.id));
    }
  }

  // 4. Setup EventBroker
  const broker = new EventBroker();

  // Find the last sequence number to avoid duplicate key conflicts
  const lastMsg = await db.query.messages.findFirst({
    where: eq(messages.channelId, channelId),
    orderBy: (table, { desc }) => [desc(table.sequenceNumber)],
  });
  const startSeq = lastMsg ? lastMsg.sequenceNumber + 1 : 1;

  // 5. Test Case 1: Ingest 12 messages and verify drift tracking
  console.log("\n--- TEST CASE 1: Ingesting 12 messages to general ---");
  for (let i = 1; i <= 12; i++) {
    const msgId = `msg-test-index-${i}-${Date.now()}`;
    await db.insert(messages).values({
      id: msgId,
      channelId,
      authorId: sparrow.id,
      authorName: sparrow.name,
      authorLevel: String(sparrow.authorityLevel),
      authorType: "agent",
      content: `Message log entry ${i} for testing indexing summaries. Key decision approved.`,
      isInternalMonologue: false,
      sequenceNumber: startSeq + i,
      timestamp: new Date()
    });

    await IndexBuilder.incrementMessageCount(channelId);
  }

  // Check the drift count
  let idxRecord = await db.query.channelIndex.findFirst({
    where: eq(channelIndex.channelId, channelId),
  });
  console.log(`Initial drift count tracked: ${idxRecord?.messageCountSinceIndex} messages.`);
  if (!idxRecord || idxRecord.messageCountSinceIndex !== 12) {
    throw new Error(`Drift count increment failed! Expected 12, got ${idxRecord?.messageCountSinceIndex}`);
  }

  // 6. Test Case 2: Run background stale re-indexing (since drift 12 >= 10 threshold)
  console.log("\n--- TEST CASE 2: Running background stale channel reindexing ---");
  await IndexBuilder.reindexStaleChannels(broker);

  // Check that index has been generated and drift reset to 0
  idxRecord = await db.query.channelIndex.findFirst({
    where: eq(channelIndex.channelId, channelId),
  });
  console.log(`Post-indexing topic summary: "${idxRecord?.topicSummary}"`);
  console.log(`Post-indexing drift count: ${idxRecord?.messageCountSinceIndex}`);

  if (!idxRecord || idxRecord.messageCountSinceIndex !== 0) {
    throw new Error("Drift count did not reset to 0 after reindexing!");
  }
  if (!idxRecord.topicSummary || idxRecord.topicSummary.includes("Empty channel")) {
    throw new Error("Topic summary was not compiled correctly!");
  }

  // Verify compressed summary entry exists
  const summaryCount = await db.select().from(compressedSummaries).where(eq(compressedSummaries.channelId, channelId));
  console.log(`Compressed historical summaries compiled count: ${summaryCount.length}`);
  if (summaryCount.length === 0) {
    throw new Error("No compressed summary history log entry was recorded!");
  }

  // 7. Test Case 3: Invoke search_all_channels tool under an authorized L2 Librarian Agent (isOmniscient = true)
  console.log("\n--- TEST CASE 3: Invoking search_all_channels under authorized Librarian ---");
  const toolExecutor = new ToolExecutor();
  const libSearchRes = await toolExecutor.execute(
    librarian.id,
    "search_all_channels",
    { query: "decision" }
  );

  console.log("Librarian Search Result Success:", libSearchRes.success);
  console.log("Librarian Search Result Output:", libSearchRes.output);

  if (!libSearchRes.success) {
    throw new Error(`Librarian search failed: ${libSearchRes.error}`);
  }
  if (!libSearchRes.output.includes("general")) {
    throw new Error("Librarian search result did not return `#general` matching channel path!");
  }

  // 8. Test Case 4: Invoke search_all_channels under an unauthorized L3 Coder Agent (isOmniscient = false)
  console.log("\n--- TEST CASE 4: Invoking search_all_channels under unauthorized non-omniscient sparrow ---");
  const sparrowSearchRes = await toolExecutor.execute(
    sparrow.id,
    "search_all_channels",
    { query: "decision" }
  );

  console.log("Sparrow Search Result Success:", sparrowSearchRes.success);
  console.log("Sparrow Search Result Error Message:", sparrowSearchRes.error);

  if (sparrowSearchRes.success) {
    throw new Error("Security breach: Non-omniscient sparrow was authorized to run search_all_channels!");
  }
  if (!sparrowSearchRes.error || !sparrowSearchRes.error.includes("breach")) {
    throw new Error(`Expected 'breach' security error message, got: ${sparrowSearchRes.error}`);
  }

  // 9. Close DB
  await closeDatabaseConnection();

  console.log("\n=== INTEGRATION TEST PASSED SUCCESSFULLY ===");
}

runTest().catch(async (err) => {
  console.error("Test failed:", err);
  try {
    await closeDatabaseConnection();
  } catch (_) {}
  process.exit(1);
});
