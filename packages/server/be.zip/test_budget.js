import { eq } from "drizzle-orm";
import { getDb } from "./dist/config/database.js";
import { EventBroker } from "./dist/core/EventBroker.js";
import { TokenTracker } from "./dist/core/TokenTracker.js";
import { agents, channels, workspaceSettings, tokenUsageLog, messages, runtimeStates } from "./dist/db/schema.js";

async function runTest() {
  console.log("=== STARTING FEATURE 15 BUDGET & SAFETY INTEGRATION TEST ===");
  const db = getDb();

  // 1. Get or create a channel
  let ch = await db.query.channels.findFirst({
    where: eq(channels.name, "general"),
  });
  if (!ch) {
    console.log("Creating temporary general channel...");
    ch = {
      id: "ch-test-budget",
      categoryId: null,
      name: "general",
      type: "standard",
      createdBy: "system",
      position: 0,
      createdAt: new Date(),
    };
    await db.insert(channels).values(ch);
  }

  // 2. Get or create L1 CEO Agent
  let agent = await db.query.agents.findFirst({
    where: eq(agents.authorityLevel, 1),
  });

  if (!agent) {
    console.log("Creating mock Level 1 Agent for test...");
    const model = await db.query.modelModules.findFirst();
    const inst = await db.query.instructionModules.findFirst();

    agent = {
      id: "agent-l1-budget-test",
      name: "Raven_CEO",
      title: "Swarm CEO",
      species: "Raven",
      authorityLevel: 1,
      modelModuleId: model?.id || "fallback-model",
      instructionModuleId: inst?.id || "fallback-instruction",
      memorySharingPolicy: "full",
      isOmniscient: true,
      status: "idle",
      isTemplate: false,
      permissions: { spawnAgents: true, patchRuntime: true, accessAllChannels: true },
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    await db.insert(agents).values(agent);
  }

  // 3. Upsert runtime state for the agent
  let state = await db.query.runtimeStates.findFirst({
    where: eq(runtimeStates.agentId, agent.id),
  });
  if (!state) {
    await db.insert(runtimeStates).values({
      sessionId: `sess-${agent.id}`,
      agentId: agent.id,
      status: "idle",
      overridesApplied: [],
      errorInfo: null,
      createdAt: new Date(),
    });
  }

  // 4. Ensure we have default workspace settings with soft cap = 10,000 tokens
  let settings = await db.query.workspaceSettings.findFirst({
    where: eq(workspaceSettings.id, "default"),
  });

  if (settings) {
    console.log("Setting default workspace soft cap to 10,000 tokens for testing...");
    await db.update(workspaceSettings)
      .set({ globalSoftCap: 10000 })
      .where(eq(workspaceSettings.id, "default"));
  } else {
    console.log("Creating default workspace settings with 10,000 tokens...");
    await db.insert(workspaceSettings).values({
      id: "default",
      globalSoftCap: 10000,
      perProviderBudget: {},
    });
  }

  // Clear existing token usage logs to start fresh
  await db.delete(tokenUsageLog);

  // Setup EventBroker to listen to safety warning & pause alerts
  const broker = new EventBroker();
  let receivedWarning = false;
  let receivedExceeded = false;
  let pausedNotification = false;

  broker.on("message:new", undefined, (event) => {
    const msg = event.payload;
    console.log(`[EVENT] [message:new] from ${msg.authorName}: ${msg.content.substring(0, 70)}...`);
    if (msg.content.includes("reached 80%+")) {
      receivedWarning = true;
    }
    if (msg.content.includes("unresolved error [BUDGET_EXCEEDED]")) {
      pausedNotification = true;
    }
  });

  broker.on("budget:exceeded", undefined, (event) => {
    const payload = event.payload;
    console.log(`[EVENT] [budget:exceeded] payload:`, JSON.stringify(payload));
    receivedExceeded = true;
  });

  // 5. Test Case 1: Track normal usage under 80% (e.g. 5,000 tokens)
  console.log("\n--- TEST CASE 1: Consuming 5,000 tokens (50% of cap) ---");
  let paused = await TokenTracker.trackUsage(broker, agent, ch.id, agent.modelModuleId, 3000, 2000);
  console.log(`Result: Paused = ${paused}`);
  if (paused) throw new Error("Agent was paused prematurely!");

  // 6. Test Case 2: Track usage approaching cap (e.g. additional 3,500 tokens -> total 8,500 = 85%)
  console.log("\n--- TEST CASE 2: Consuming another 3,500 tokens (total 8,500 = 85% of cap) ---");
  paused = await TokenTracker.trackUsage(broker, agent, ch.id, agent.modelModuleId, 2000, 1500);
  console.log(`Result: Paused = ${paused}`);
  if (paused) throw new Error("Agent was paused prematurely at warning limit!");
  if (!receivedWarning) throw new Error("Did not receive budget soft cap warning event!");
  console.log("Success: Received 80%+ budget soft cap warning message successfully.");

  // 7. Test Case 3: Track usage exceeding cap (e.g. additional 2,000 tokens -> total 10,500 = 105%)
  console.log("\n--- TEST CASE 3: Consuming another 2,000 tokens (total 10,500 = 105% of cap) ---");
  paused = await TokenTracker.trackUsage(broker, agent, ch.id, agent.modelModuleId, 1000, 1000);
  console.log(`Result: Paused = ${paused}`);
  if (!paused) throw new Error("Agent was not paused when exceeding budget soft cap!");
  
  // Verify agent is paused in DB
  const updatedAgent = await db.query.agents.findFirst({
    where: eq(agents.id, agent.id),
  });
  console.log(`Updated agent status: ${updatedAgent.status}`);
  if (updatedAgent.status !== "paused") throw new Error("Agent status was not set to paused in DB!");

  // Verify RuntimeState lists BUDGET_EXCEEDED
  const updatedState = await db.query.runtimeStates.findFirst({
    where: eq(runtimeStates.agentId, agent.id),
  });
  console.log(`Runtime State error info:`, JSON.stringify(updatedState.errorInfo));
  if (updatedState.errorInfo?.code !== "BUDGET_EXCEEDED") throw new Error("RuntimeState error code is not BUDGET_EXCEEDED!");

  if (!receivedExceeded) throw new Error("Did not receive budget:exceeded socket event notification!");
  console.log("Success: Agent successfully auto-paused and escalated with safety warning alerts!");

  console.log("\n=== INTEGRATION TEST PASSED SUCCESSFULLY ===");
}

runTest().catch((err) => {
  console.error("Test failed:", err);
  process.exit(1);
});
