import type { Server as HttpServer } from "node:http";
import { Server } from "socket.io";
import { eq } from "drizzle-orm";

import { EventBroker } from "../core/EventBroker.js";
import { MentionParser } from "../core/MentionParser.js";
import { AgentRegistry } from "../core/AgentRegistry.js";
import { L1Runtime } from "../core/L1Runtime.js";
import { L2Runtime } from "../core/L2Runtime.js";
import { LibrarianRuntime } from "../core/LibrarianRuntime.js";
import { IndexBuilder } from "../core/IndexBuilder.js";
import { getDb } from "../config/database.js";
import { messages, agents, channels } from "../db/schema.js";
import type {
  SocketClientToServerEvents,
  SocketServerToClientEvents,
} from "../types/event.types.js";
import type { ChannelMessage } from "../types/message.types.js";
import type { AgentProfile } from "../types/agent.types.js";

const mentionParser = new MentionParser();
const agentRegistry = new AgentRegistry();
const l1Runtime = new L1Runtime();
const l2Runtime = new L2Runtime();
const librarianRuntime = new LibrarianRuntime();
export let globalBroker: EventBroker | null = null;

async function getNextSequenceNumber(channelId: string): Promise<number> {
  const db = getDb();
  const lastMessage = await db.query.messages.findFirst({
    where: eq(messages.channelId, channelId),
    orderBy: (table, { desc }) => [desc(table.sequenceNumber)],
  });
  return lastMessage ? lastMessage.sequenceNumber + 1 : 1;
}

async function triggerAgentReply(broker: EventBroker, channelId: string, agent: AgentProfile): Promise<void> {
  const db = getDb();

  // Update agent status in DB and broadcast
  await db.update(agents).set({ status: "working" }).where(eq(agents.id, agent.id));
  broker.emit("agent:status", { agentId: agent.id, status: "working" });
  broker.emit(
    "agent:thinking",
    { agentId: agent.id, channelId },
    { channelId },
  );

  // Generate dynamic context-aware reply chunks
  const chunks = [
    `Hello! I am @	her name is ${agent.name}, your ${agent.title || "assistant"}. `,
    `I received your mention in this channel. `,
    `My authority level is Level ${agent.authorityLevel} (${agent.species || "Agent"}). `,
    `Ready to execute modular commands and coordinate subtasks.`
  ];

  // Stream reply chunks
  chunks.forEach((chunk, index) => {
    setTimeout(() => {
      broker.emit(
        "message:stream",
        { channelId, agentId: agent.id, chunk },
        { channelId },
      );
    }, 150 * (index + 1));
  });

  // Persist final message and set idle
  setTimeout(async () => {
    const finalContent = chunks.join("");
    const nextSeq = await getNextSequenceNumber(channelId);

    const agentMsg: ChannelMessage = {
      id: `msg-${Date.now()}-agent-${agent.id}`,
      channelId,
      authorId: agent.id,
      authorName: agent.name,
      authorLevel: agent.authorityLevel as any,
      authorType: "agent",
      content: finalContent,
      mentions: [],
      isInternalMonologue: false,
      sequenceNumber: nextSeq,
      timestamp: new Date(),
    };

    await db.insert(messages).values({
      ...agentMsg,
      authorLevel: String(agentMsg.authorLevel),
    });
    broker.emit("message:new", agentMsg, { channelId });

    await db.update(agents).set({ status: "idle" }).where(eq(agents.id, agent.id));
    broker.emit("agent:status", { agentId: agent.id, status: "idle" });
  }, 150 * chunks.length + 200);
}

async function triggerSystemWarning(broker: EventBroker, channelId: string, content: string): Promise<void> {
  const db = getDb();
  const nextSeq = await getNextSequenceNumber(channelId);

  const warningMsg: ChannelMessage = {
    id: `msg-${Date.now()}-system`,
    channelId,
    authorId: "system",
    authorName: "System Warning",
    authorLevel: "stakeholder",
    authorType: "system",
    content,
    mentions: [],
    isInternalMonologue: false,
    sequenceNumber: nextSeq,
    timestamp: new Date(),
  };

  await db.insert(messages).values({
    ...warningMsg,
    authorLevel: String(warningMsg.authorLevel),
  });
  broker.emit("message:new", warningMsg, { channelId });
}

export function registerSocketServer(httpServer: HttpServer, broker: EventBroker) {
  globalBroker = broker;
  const io = new Server<SocketClientToServerEvents, SocketServerToClientEvents>(httpServer, {
    cors: {
      origin: true,
      credentials: true,
    },
  });

  broker.onAny((event) => {
    io.emit(event.type, event.payload as never);
  });

  // Register permanent index count listener for all new messages!
  broker.on("message:new", undefined, async (event) => {
    try {
      const msg = event.payload;
      await IndexBuilder.incrementMessageCount(msg.channelId);
    } catch (err) {
      console.error("[EventBroker] Failed to increment channel message count:", err);
    }
  });

  // Setup periodic background indexing for stale channels (drift >= 10 messages) every 10 minutes
  setInterval(async () => {
    try {
      await IndexBuilder.reindexStaleChannels(broker);
    } catch (err) {
      console.error("[IndexBuilder] Background reindexing task failed:", err);
    }
  }, 10 * 60 * 1000);

  io.on("connection", (socket) => {
    socket.on("user:message", async (payload) => {
      const db = getDb();
      const { channelId, content } = payload;

      try {
        // 1. Resolve and parse mentions from content
        const resolvedMentions = await mentionParser.parseMentions(content);

        // 2. Persist the human operator's message
        const nextSeq = await getNextSequenceNumber(channelId);
        const userMsg: ChannelMessage = {
          id: `msg-${Date.now()}`,
          channelId,
          authorId: "user-1",
          authorName: "Human Operator",
          authorLevel: "stakeholder",
          authorType: "user",
          content,
          mentions: resolvedMentions,
          isInternalMonologue: false,
          sequenceNumber: nextSeq,
          timestamp: new Date(),
        };

        await db.insert(messages).values({
          ...userMsg,
          authorLevel: String(userMsg.authorLevel),
        });
        broker.emit("message:new", userMsg, { channelId });

        // 3. Process mentions and triggers
        const allAgents = await agentRegistry.list({ isTemplate: false });

        if (resolvedMentions.length > 0) {
          // Explicit mentions are present
          for (const mention of resolvedMentions) {
            if (mention.type === "agent") {
              const agent = allAgents.find(a => a.id === mention.targetId);
              if (agent) {
                if (agent.status === "paused") {
                  await triggerSystemWarning(broker, channelId, `Agent @${agent.name} is currently paused.`);
                } else if (agent.status === "offline") {
                  await triggerSystemWarning(broker, channelId, `Agent @${agent.name} is currently offline.`);
                } else {
                  if (agent.id === "agent-librarian" || agent.name.toLowerCase() === "librarian") {
                    await librarianRuntime.execute(broker, channelId, agent, content);
                  } else if (agent.authorityLevel === 1) {
                    await l1Runtime.execute(broker, channelId, agent, content);
                  } else if (agent.authorityLevel === 2) {
                    await l2Runtime.execute(broker, channelId, agent, content);
                  } else {
                    await triggerAgentReply(broker, channelId, agent);
                  }
                }
              }
            } else if (mention.type === "role") {
              // Role mention, e.g. @Level2, L0, L1, etc.
              // Find matching role level: e.g. "role-l2" -> level 2
              const levelStr = mention.targetId.replace("role-l", "");
              const levelNum = parseInt(levelStr, 10);
              if (!isNaN(levelNum)) {
                const matchingAgents = allAgents.filter(a => a.authorityLevel === levelNum);
                for (const agent of matchingAgents) {
                  if (agent.status === "paused") {
                    await triggerSystemWarning(broker, channelId, `Agent @${agent.name} is currently paused.`);
                  } else if (agent.status === "offline") {
                    await triggerSystemWarning(broker, channelId, `Agent @${agent.name} is currently offline.`);
                  } else {
                    if (agent.id === "agent-librarian" || agent.name.toLowerCase() === "librarian") {
                      await librarianRuntime.execute(broker, channelId, agent, content);
                    } else if (agent.authorityLevel === 1) {
                      await l1Runtime.execute(broker, channelId, agent, content);
                    } else if (agent.authorityLevel === 2) {
                      await l2Runtime.execute(broker, channelId, agent, content);
                    } else {
                      await triggerAgentReply(broker, channelId, agent);
                    }
                  }
                }
              }
            }
          }
        } else {
          // No explicit mentions
          // Check if this is the #general channel
          const channel = await db.query.channels.findFirst({
            where: eq(channels.id, channelId),
          });
          const isGeneral = channel?.name.toLowerCase() === "general";

          if (isGeneral) {
            // Trigger all active L0 agents in parallel
            const l0Agents = allAgents.filter(a => a.authorityLevel === 0);
            for (const agent of l0Agents) {
              if (agent.status !== "offline" && agent.status !== "paused") {
                triggerAgentReply(broker, channelId, agent);
              }
            }
          }
        }
      } catch (error: any) {
        console.error("Error in user:message handler:", error);
        await triggerSystemWarning(broker, channelId, `System error processing message: ${error?.message || error}`);
      }
    });
  });

  return io;
}
