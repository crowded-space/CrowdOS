import type { ChannelMessage } from "./message.types.js";
import type { RuntimeOverride, RuntimeState, RuntimeStatus } from "./runtime.types.js";

export interface AgentStatusEventPayload {
  agentId: string;
  status: RuntimeStatus;
}

export interface MessageStreamEventPayload {
  channelId: string;
  agentId: string;
  chunk: string;
}

export interface AgentThinkingEventPayload {
  agentId: string;
  channelId: string;
}

export interface AgentSpawnedEventPayload {
  pairs: string[];
  channelId: string;
  batchNum: number;
}

export interface AgentDespawnedEventPayload {
  agentId: string;
}

export interface AgentPausedEventPayload {
  agentId: string;
  reason: string;
}

export interface RuntimeOverrideEventPayload {
  agentId: string;
  override: RuntimeOverride;
}

export interface RuntimeStateEventPayload {
  agentId: string;
  state: RuntimeState;
}

export interface EscalationEventPayload {
  channelId: string;
  fromAgent: string;
  reason: string;
}

export interface BudgetWarningEventPayload {
  profileId: string;
  usage: number;
  cap: number;
}

export interface BudgetExceededEventPayload {
  profileId: string;
  pausedAgents: string[];
}

export interface UserMessageEventPayload {
  channelId: string;
  content: string;
  mentions: string[];
}

export interface BrokerEventMap {
  "agent:status": AgentStatusEventPayload;
  "message:new": ChannelMessage;
  "message:stream": MessageStreamEventPayload;
  "agent:thinking": AgentThinkingEventPayload;
  "agent:spawned": AgentSpawnedEventPayload;
  "agent:despawned": AgentDespawnedEventPayload;
  "agent:paused": AgentPausedEventPayload;
  "runtime:override": RuntimeOverrideEventPayload;
  "runtime:state": RuntimeStateEventPayload;
  escalation: EscalationEventPayload;
  "budget:warning": BudgetWarningEventPayload;
  "budget:exceeded": BudgetExceededEventPayload;
  "workspace:sync": Record<string, never>;
}

export type BrokerEventType = keyof BrokerEventMap;

export interface BrokerEvent<TType extends BrokerEventType = BrokerEventType> {
  eventId: string;
  type: TType;
  channelId?: string;
  payload: BrokerEventMap[TType];
  timestamp: Date;
}

export type SocketServerToClientEvents = {
  [TType in BrokerEventType]: (payload: BrokerEventMap[TType]) => void;
};

export interface SocketClientToServerEvents {
  "user:message": (payload: UserMessageEventPayload) => void;
}
