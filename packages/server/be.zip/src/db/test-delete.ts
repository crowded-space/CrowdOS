import { eq } from "drizzle-orm";
import { closeDatabaseConnection, getDb } from "../config/database.js";
import { agents, modelModules, channels } from "./schema.js";

async function testDeleteOperations() {
  const db = getDb();
  console.log("Fetching agents...");
  const allAgents = await db.select().from(agents);
  console.log(`Found ${allAgents.length} agents.`);

  for (const ag of allAgents) {
    console.log(`Attempting to delete agent: ${ag.name} (${ag.id})...`);
    try {
      const res = await db.delete(agents).where(eq(agents.id, ag.id)).returning();
      console.log(`Successfully deleted agent ${ag.name}!`, res);
    } catch (err: any) {
      console.error(`Failed to delete agent ${ag.name}: ${err.message} | Detail: ${err.detail}`);
    }
  }

  console.log("\nFetching model modules...");
  const allModules = await db.select().from(modelModules);
  console.log(`Found ${allModules.length} model modules.`);

  for (const mod of allModules) {
    console.log(`Attempting to delete model module: ${mod.label} (${mod.id})...`);
    try {
      const res = await db.delete(modelModules).where(eq(modelModules.id, mod.id)).returning();
      console.log(`Successfully deleted model module ${mod.label}!`, res);
    } catch (err: any) {
      console.error(`Failed to delete model module ${mod.label}: ${err.message} | Detail: ${err.detail}`);
    }
  }

  console.log("\nFetching channels...");
  const allChannels = await db.select().from(channels);
  console.log(`Found ${allChannels.length} channels.`);

  for (const chan of allChannels) {
    console.log(`Attempting to delete channel: ${chan.name} (${chan.id})...`);
    try {
      const res = await db.delete(channels).where(eq(channels.id, chan.id)).returning();
      console.log(`Successfully deleted channel ${chan.name}!`, res);
    } catch (err: any) {
      console.error(`Failed to delete channel ${chan.name}: ${err.message}`);
    }
  }
}

testDeleteOperations()
  .catch(console.error)
  .finally(async () => {
    await closeDatabaseConnection();
  });
