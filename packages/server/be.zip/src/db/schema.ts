﻿import { relations, sql } from "drizzle-orm";
import {
  bigint,
  boolean,
  integer,
  real,
  jsonb,
  pgEnum,
  pgTable,
  primaryKey,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

import type { MentionMetadata } from "../types/mention.types.js";
import type { SubtaskDefinition } from "../types/task.types.js";
import type { InstructionPatch, PermissionPatch } from "../types/runtime.types.js";

const runtimeOverrideTypeEnum = pgEnum("runtime_override_type", ["runtime_patch", "temp_permission", "context_inject"]);
const runtimeStatusEnum = pgEnum("runtime_status", ["idle", "working", "paused", "offline"]);

const providerEngineEnum = pgEnum("provider_engine", ["google", "openai", "anthropic", "ollama", "custom"]);
const agentStatusEnum = pgEnum("agent_status", ["idle", "working", "paused", "offline"]);
const memorySharingPolicyEnum = pgEnum("memory_sharing_policy", ["none", "horizontal", "vertical", "full"]);
const l3SubtypeEnum = pgEnum("l3_subtype", ["worker", "supervisor"]);
const channelTypeEnum = pgEnum("channel_type", ["standard", "pair_private", "archived"]);
const messageAuthorTypeEnum = pgEnum("message_author_type", ["user", "agent", "system"]);
const spawnFailurePolicyEnum = pgEnum("spawn_failure_policy", ["retry", "escalate"]);
const spawnStatusEnum = pgEnum("spawn_status", ["pending", "in_progress", "completed", "failed"]);
const toolDangerLevelEnum = pgEnum("tool_danger_level", ["low", "medium", "high"]);
const workspaceStatusEnum = pgEnum("workspace_status", ["CREATED", "INITIALIZING", "ACTIVE", "PAUSED", "TERMINATED", "ARCHIVED"]);
const workspaceScopeEnum = pgEnum("workspace_scope", ["private", "shared", "readonly", "ephemeral"]);
const artifactTypeEnum = pgEnum("artifact_type", ["reasoning_trace", "execution_log", "analysis_report", "generated_component", "task_result", "runtime_snapshot"]);
const workspaceNodeTypeEnum = pgEnum("workspace_node_type", ["file", "directory"]);

const jsonbArrayDefault = sql`'[]'::jsonb`;
const jsonbObjectDefault = sql`'{}'::jsonb`;

export const modelModules = pgTable("model_modules", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  provider: providerEngineEnum("provider").notNull(),
  modelName: text("model_name").notNull(),
  apiKey: text("api_key"),
  endpointUrl: text("endpoint_url"),
  temperature: real("temperature").notNull(),
  topP: real("top_p").notNull(),
  maxOutputTokens: integer("max_output_tokens").notNull(),
  stopSequences: jsonb("stop_sequences").$type<string[]>().notNull().default(jsonbArrayDefault),
  maxRecentMessages: integer("max_recent_messages").notNull(),
  enableCompression: boolean("enable_compression").notNull().default(true),
  compressionThreshold: integer("compression_threshold").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const instructionModules = pgTable("instruction_modules", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  base: jsonb("base").$type<string[]>().notNull().default(jsonbArrayDefault),
  runtimePatchable: boolean("runtime_patchable").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const toolkitModules = pgTable("toolkit_modules", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  tools: jsonb("tools").$type<string[]>().notNull().default(jsonbArrayDefault),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const constraintsModules = pgTable("constraints_modules", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  rules: jsonb("rules").$type<string[]>().notNull().default(jsonbArrayDefault),
  disallowedActions: jsonb("disallowed_actions").$type<string[]>().notNull().default(jsonbArrayDefault),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const capabilitiesModules = pgTable("capabilities_modules", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  skills: jsonb("skills").$type<string[]>().notNull().default(jsonbArrayDefault),
  functionSchemas: jsonb("function_schemas").$type<Record<string, unknown>[]>().notNull().default(jsonbArrayDefault),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ─── CrowdOS Runtime Tables ──────────────────────────────────────────

export const runtimeOverrides = pgTable("runtime_overrides", {
  id: text("id").primaryKey(),
  targetAgentId: text("target_agent_id").notNull(),
  overrideType: runtimeOverrideTypeEnum("override_type").notNull(),
  instructionPatch: jsonb("instruction_patch").$type<InstructionPatch>(),
  permissionPatch: jsonb("permission_patch").$type<PermissionPatch>(),
  createdBy: text("created_by").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const runtimeStates = pgTable("runtime_states", {
  sessionId: text("session_id").primaryKey(),
  agentId: text("agent_id").notNull(),
  status: runtimeStatusEnum("status").notNull().default("idle"),
  activeTask: text("active_task"),
  activeChannelId: text("active_channel_id"),
  startedAt: timestamp("started_at", { withTimezone: true }),
  overridesApplied: jsonb("overrides_applied").$type<string[]>().notNull().default(jsonbArrayDefault),
  errorInfo: jsonb("error_info").$type<{ code: string; message: string; timestamp: string }>(),
  lastHeartbeat: timestamp("last_heartbeat", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ─── Legacy Model Profiles (kept for backward compatibility) ─────────

export const generationModelProfiles = pgTable("generation_model_profiles", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  provider: providerEngineEnum("provider").notNull(),
  modelName: text("model_name").notNull(),
  apiKey: text("api_key"),
  endpointUrl: text("endpoint_url"),
  temperature: real("temperature").notNull(),
  topP: real("top_p").notNull(),
  maxOutputTokens: integer("max_output_tokens").notNull(),
  stopSequences: jsonb("stop_sequences").$type<string[]>().notNull().default(jsonbArrayDefault),
  maxRecentMessages: integer("max_recent_messages").notNull(),
  enableCompression: boolean("enable_compression").notNull().default(true),
  compressionThreshold: integer("compression_threshold").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const embeddingModelProfiles = pgTable("embedding_model_profiles", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  provider: providerEngineEnum("provider").notNull(),
  modelName: text("model_name").notNull(),
  apiKey: text("api_key"),
  endpointUrl: text("endpoint_url"),
  dimensions: integer("dimensions").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const indexingModelProfiles = pgTable("indexing_model_profiles", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  provider: providerEngineEnum("provider").notNull(),
  modelName: text("model_name").notNull(),
  apiKey: text("api_key"),
  endpointUrl: text("endpoint_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const tools = pgTable("tools", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  handlerId: text("handler_id").notNull(),
  jsonSchema: jsonb("json_schema").$type<Record<string, unknown>>().notNull().default(jsonbObjectDefault),
  dangerLevel: toolDangerLevelEnum("danger_level").notNull(),
  authLevelRequired: integer("auth_level_required").notNull(),
}, (table) => ({
  toolNameIndex: uniqueIndex("tools_name_idx").on(table.name),
}));

export const agents = pgTable("agents", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  title: text("title").notNull(),
  species: text("species"),
  avatar: text("avatar"),
  authorityLevel: integer("authority_level").notNull(),
  l3Subtype: l3SubtypeEnum("l3_subtype"),
  modelModuleId: text("model_module_id").notNull().references(() => modelModules.id),
  instructionModuleId: text("instruction_module_id").notNull().references(() => instructionModules.id),
  toolkitModuleId: text("toolkit_module_id").references(() => toolkitModules.id),
  constraintsModuleId: text("constraints_module_id").references(() => constraintsModules.id),
  capabilitiesModuleId: text("capabilities_module_id").references(() => capabilitiesModules.id),
  memorySharingPolicy: memorySharingPolicyEnum("memory_sharing_policy").notNull(),
  isOmniscient: boolean("is_omniscient").notNull().default(false),
  fallbackAgentId: text("fallback_agent_id"),
  categoryPermissions: jsonb("category_perms").$type<string[]>().notNull().default(jsonbArrayDefault),
  permissions: jsonb("permissions").$type<{ spawnAgents: boolean; patchRuntime: boolean; accessAllChannels: boolean }>().notNull().default(sql`'{"spawnAgents":false,"patchRuntime":false,"accessAllChannels":false}'::jsonb`),
  status: agentStatusEnum("status").notNull().default("offline"),
  isTemplate: boolean("is_template").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
  agentNameIndex: uniqueIndex("agents_name_idx").on(table.name),
}));

export const agentTools = pgTable("agent_tools", {
  agentId: text("agent_id").notNull().references(() => agents.id, { onDelete: "cascade" }),
  toolId: text("tool_id").notNull().references(() => tools.id, { onDelete: "cascade" }),
}, (table) => ({
  pk: primaryKey({ columns: [table.agentId, table.toolId] }),
}));

export const categories = pgTable("categories", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  ownedByAgentId: text("owned_by_agent_id").references(() => agents.id),
  embeddingProfileId: text("embedding_profile_id").references(() => embeddingModelProfiles.id),
  createdBy: text("created_by").notNull(),
  position: integer("position").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const channels = pgTable("channels", {
  id: text("id").primaryKey(),
  categoryId: text("category_id").references(() => categories.id),
  name: text("name").notNull(),
  type: channelTypeEnum("type").notNull().default("standard"),
  createdBy: text("created_by").notNull(),
  position: integer("position").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  archivedAt: timestamp("archived_at", { withTimezone: true }),
});

export const messages = pgTable("messages", {
  id: text("id").primaryKey(),
  channelId: text("channel_id").notNull().references(() => channels.id, { onDelete: "cascade" }),
  authorId: text("author_id").notNull(),
  authorName: text("author_name").notNull(),
  authorLevel: text("author_level").notNull(),
  authorType: messageAuthorTypeEnum("author_type").notNull(),
  content: text("content").notNull(),
  mentions: jsonb("mentions").$type<MentionMetadata[]>().notNull().default(jsonbArrayDefault),
  isInternalMonologue: boolean("is_internal_monologue").notNull().default(false),
  sequenceNumber: integer("sequence_number").notNull(),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
  channelSequenceIndex: uniqueIndex("messages_channel_sequence_idx").on(table.channelId, table.sequenceNumber),
}));

export const spawnRequests = pgTable("spawn_requests", {
  id: text("id").primaryKey(),
  requestedBy: text("requested_by").notNull().references(() => agents.id),
  channelId: text("channel_id").notNull().references(() => channels.id, { onDelete: "cascade" }),
  workerTemplateId: text("worker_template").notNull().references(() => agents.id),
  supervisorTemplateId: text("spv_template").notNull().references(() => agents.id),
  failurePolicy: spawnFailurePolicyEnum("failure_policy").notNull(),
  maxRetries: integer("max_retries").notNull(),
  subtasks: jsonb("subtasks").$type<SubtaskDefinition[]>().notNull().default(jsonbArrayDefault),
  status: spawnStatusEnum("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const taskFiles = pgTable("task_files", {
  id: text("id").primaryKey(),
  spawnRequestId: text("spawn_request_id").notNull().references(() => spawnRequests.id, { onDelete: "cascade" }),
  subtaskId: text("subtask_id").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  workerAgentId: text("worker_agent_id").notNull().references(() => agents.id),
  supervisorAgentId: text("spv_agent_id").notNull().references(() => agents.id),
  status: spawnStatusEnum("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const scheduledTasks = pgTable("scheduled_tasks", {
  id: text("id").primaryKey(),
  cronExpression: text("cron_expression").notNull(),
  channelId: text("channel_id").notNull().references(() => channels.id, { onDelete: "cascade" }),
  targetAgentId: text("target_agent_id").notNull().references(() => agents.id),
  taskPayload: jsonb("task_payload").$type<Record<string, unknown>>().notNull().default(jsonbObjectDefault),
  isActive: boolean("is_active").notNull().default(true),
  nextRun: timestamp("next_run", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const tokenUsageLog = pgTable("token_usage_log", {
  id: text("id").primaryKey(),
  agentId: text("agent_id").notNull().references(() => agents.id),
  channelId: text("channel_id").notNull().references(() => channels.id, { onDelete: "cascade" }),
  modelModuleId: text("model_module_id").references(() => modelModules.id),
  promptTokens: integer("prompt_tokens").notNull(),
  completionTokens: integer("completion_tokens").notNull(),
  totalTokens: integer("total_tokens").notNull(),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
});

export const channelIndex = pgTable("channel_index", {
  channelId: text("channel_id").primaryKey().references(() => channels.id, { onDelete: "cascade" }),
  channelPath: text("channel_path").notNull(),
  topicSummary: text("topic_summary").notNull(),
  lastIndexedAt: timestamp("last_indexed_at", { withTimezone: true }).notNull(),
  messageCountSinceIndex: integer("msg_count_since_index").notNull(),
});

export const compressedSummaries = pgTable("compressed_summaries", {
  id: text("id").primaryKey(),
  channelId: text("channel_id").notNull().references(() => channels.id, { onDelete: "cascade" }),
  summary: text("summary").notNull(),
  coversUpToSeq: integer("covers_up_to_seq").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const workspaceSettings = pgTable("workspace_settings", {
  id: text("id").primaryKey(),
  globalSoftCap: integer("global_soft_cap").notNull().default(1000000),
  perProviderBudget: jsonb("per_provider_budget").$type<Record<string, {
    softCap: number;
    used: number;
    resetPeriod: "daily" | "weekly" | "monthly" | "never";
    lastResetAt: string;
  }>>().notNull().default(sql`'{}'::jsonb`),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});


// ─── Workspace Sandbox Runtime Tables ────────────────────────────────

import type { WorkspacePermissions, RuntimeConstraints, VFSPermissions } from "../types/workspace.types.js";

export const workspaces = pgTable("workspaces", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  ownerId: text("owner_id").notNull(),
  status: workspaceStatusEnum("status").notNull().default("CREATED"),
  rootPath: text("root_path").notNull(),
  permissions: jsonb("permissions").$type<WorkspacePermissions>().notNull().default(sql`'{"network":false,"shell":false,"maxAgents":8}'::jsonb`),
  constraints: jsonb("constraints").$type<RuntimeConstraints>().notNull().default(sql`'{"networkAccess":false,"shellExecution":true,"memoryLimitMb":512,"cpuLimit":1}'::jsonb`),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default(jsonbObjectDefault),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const workspaceNodes = pgTable("workspace_nodes", {
  id: text("id").primaryKey(),
  workspaceId: text("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  path: text("path").notNull(),
  name: text("name").notNull(),
  type: workspaceNodeTypeEnum("type").notNull(),
  mimeType: text("mime_type"),
  size: bigint("size", { mode: "number" }).notNull().default(0),
  checksum: text("checksum"),
  createdBy: text("created_by").notNull(),
  updatedBy: text("updated_by").notNull(),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default(jsonbObjectDefault),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
  pathIndex: uniqueIndex("workspace_nodes_ws_path_idx").on(table.workspaceId, table.path),
}));

export const workspaceEvents = pgTable("workspace_events", {
  id: text("id").primaryKey(),
  workspaceId: text("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  type: text("type").notNull(),
  agentId: text("agent_id"),
  path: text("path"),
  payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default(jsonbObjectDefault),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const workspaceAgents = pgTable("workspace_agents", {
  id: text("id").primaryKey(),
  workspaceId: text("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  agentId: text("agent_id").notNull().references(() => agents.id, { onDelete: "cascade" }),
  scope: workspaceScopeEnum("scope").notNull().default("shared"),
  permissions: jsonb("permissions").$type<VFSPermissions>().notNull().default(sql`'{"read":true,"write":false,"execute":false}'::jsonb`),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const artifacts = pgTable("artifacts", {
  id: text("id").primaryKey(),
  workspaceId: text("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
  producerAgent: text("producer_agent").notNull(),
  artifactType: artifactTypeEnum("artifact_type").notNull(),
  path: text("path"),
  semanticTags: text("semantic_tags").array().notNull().default(sql`'{}'::text[]`),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default(jsonbObjectDefault),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ─── Relations ───────────────────────────────────────────────────────

export const modelModulesRelations = relations(modelModules, ({ many }) => ({
  agents: many(agents, { relationName: "agent_model_module" }),
  tokenLogs: many(tokenUsageLog),
}));

export const instructionModulesRelations = relations(instructionModules, ({ many }) => ({
  agents: many(agents, { relationName: "agent_instruction_module" }),
}));

export const toolkitModulesRelations = relations(toolkitModules, ({ many }) => ({
  agents: many(agents, { relationName: "agent_toolkit_module" }),
}));

export const constraintsModulesRelations = relations(constraintsModules, ({ many }) => ({
  agents: many(agents, { relationName: "agent_constraints_module" }),
}));

export const capabilitiesModulesRelations = relations(capabilitiesModules, ({ many }) => ({
  agents: many(agents, { relationName: "agent_capabilities_module" }),
}));

export const runtimeOverridesRelations = relations(runtimeOverrides, ({ one }) => ({
  targetAgent: one(agents, {
    fields: [runtimeOverrides.targetAgentId],
    references: [agents.id],
  }),
}));

export const runtimeStatesRelations = relations(runtimeStates, ({ one }) => ({
  agent: one(agents, {
    fields: [runtimeStates.agentId],
    references: [agents.id],
  }),
}));

export const generationModelProfilesRelations = relations(generationModelProfiles, ({ many }) => ({
  categories: many(categories),
}));

export const embeddingModelProfilesRelations = relations(embeddingModelProfiles, ({ many }) => ({
  categories: many(categories),
}));

export const agentsRelations = relations(agents, ({ one, many }) => ({
  modelModule: one(modelModules, {
    fields: [agents.modelModuleId],
    references: [modelModules.id],
    relationName: "agent_model_module",
  }),
  instructionModule: one(instructionModules, {
    fields: [agents.instructionModuleId],
    references: [instructionModules.id],
    relationName: "agent_instruction_module",
  }),
  toolkitModule: one(toolkitModules, {
    fields: [agents.toolkitModuleId],
    references: [toolkitModules.id],
    relationName: "agent_toolkit_module",
  }),
  constraintsModule: one(constraintsModules, {
    fields: [agents.constraintsModuleId],
    references: [constraintsModules.id],
    relationName: "agent_constraints_module",
  }),
  capabilitiesModule: one(capabilitiesModules, {
    fields: [agents.capabilitiesModuleId],
    references: [capabilitiesModules.id],
    relationName: "agent_capabilities_module",
  }),
  fallbackAgent: one(agents, {
    fields: [agents.fallbackAgentId],
    references: [agents.id],
    relationName: "agent_fallback",
  }),
  toolLinks: many(agentTools),
  ownedCategories: many(categories),
  runtimeStates: many(runtimeStates),
  runtimeOverrides: many(runtimeOverrides),
  requestedSpawns: many(spawnRequests, { relationName: "spawn_requested_by" }),
  tokenLogs: many(tokenUsageLog),
}));

export const toolsRelations = relations(tools, ({ many }) => ({
  agentLinks: many(agentTools),
}));

export const agentToolsRelations = relations(agentTools, ({ one }) => ({
  agent: one(agents, {
    fields: [agentTools.agentId],
    references: [agents.id],
  }),
  tool: one(tools, {
    fields: [agentTools.toolId],
    references: [tools.id],
  }),
}));

export const categoriesRelations = relations(categories, ({ one, many }) => ({
  owner: one(agents, {
    fields: [categories.ownedByAgentId],
    references: [agents.id],
  }),
  embeddingProfile: one(embeddingModelProfiles, {
    fields: [categories.embeddingProfileId],
    references: [embeddingModelProfiles.id],
  }),
  channels: many(channels),
}));

export const channelsRelations = relations(channels, ({ one, many }) => ({
  category: one(categories, {
    fields: [channels.categoryId],
    references: [categories.id],
  }),
  messages: many(messages),
  spawnRequests: many(spawnRequests),
  scheduledTasks: many(scheduledTasks),
  index: one(channelIndex, {
    fields: [channels.id],
    references: [channelIndex.channelId],
  }),
  summaries: many(compressedSummaries),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  channel: one(channels, {
    fields: [messages.channelId],
    references: [channels.id],
  }),
}));

export const spawnRequestsRelations = relations(spawnRequests, ({ one, many }) => ({
  requester: one(agents, {
    fields: [spawnRequests.requestedBy],
    references: [agents.id],
    relationName: "spawn_requested_by",
  }),
  channel: one(channels, {
    fields: [spawnRequests.channelId],
    references: [channels.id],
  }),
  workerTemplate: one(agents, {
    fields: [spawnRequests.workerTemplateId],
    references: [agents.id],
    relationName: "spawn_worker_template",
  }),
  supervisorTemplate: one(agents, {
    fields: [spawnRequests.supervisorTemplateId],
    references: [agents.id],
    relationName: "spawn_supervisor_template",
  }),
  taskFiles: many(taskFiles),
}));

export const taskFilesRelations = relations(taskFiles, ({ one }) => ({
  spawnRequest: one(spawnRequests, {
    fields: [taskFiles.spawnRequestId],
    references: [spawnRequests.id],
  }),
  workerAgent: one(agents, {
    fields: [taskFiles.workerAgentId],
    references: [agents.id],
    relationName: "task_worker_agent",
  }),
  supervisorAgent: one(agents, {
    fields: [taskFiles.supervisorAgentId],
    references: [agents.id],
    relationName: "task_supervisor_agent",
  }),
}));

export const scheduledTasksRelations = relations(scheduledTasks, ({ one }) => ({
  channel: one(channels, {
    fields: [scheduledTasks.channelId],
    references: [channels.id],
  }),
  targetAgent: one(agents, {
    fields: [scheduledTasks.targetAgentId],
    references: [agents.id],
  }),
}));

export const tokenUsageLogRelations = relations(tokenUsageLog, ({ one }) => ({
  agent: one(agents, {
    fields: [tokenUsageLog.agentId],
    references: [agents.id],
  }),
  channel: one(channels, {
    fields: [tokenUsageLog.channelId],
    references: [channels.id],
  }),
  modelModule: one(modelModules, {
    fields: [tokenUsageLog.modelModuleId],
    references: [modelModules.id],
  }),
}));

export const channelIndexRelations = relations(channelIndex, ({ one }) => ({
  channel: one(channels, {
    fields: [channelIndex.channelId],
    references: [channels.id],
  }),
}));

export const compressedSummariesRelations = relations(compressedSummaries, ({ one }) => ({
  channel: one(channels, {
    fields: [compressedSummaries.channelId],
    references: [channels.id],
  }),
}));

// ─── Workspace Sandbox Relations ─────────────────────────────────────

export const workspacesRelations = relations(workspaces, ({ many }) => ({
  nodes: many(workspaceNodes),
  events: many(workspaceEvents),
  agentSessions: many(workspaceAgents),
  artifacts: many(artifacts),
}));

export const workspaceNodesRelations = relations(workspaceNodes, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [workspaceNodes.workspaceId],
    references: [workspaces.id],
  }),
}));

export const workspaceEventsRelations = relations(workspaceEvents, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [workspaceEvents.workspaceId],
    references: [workspaces.id],
  }),
}));

export const workspaceAgentsRelations = relations(workspaceAgents, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [workspaceAgents.workspaceId],
    references: [workspaces.id],
  }),
  agent: one(agents, {
    fields: [workspaceAgents.agentId],
    references: [agents.id],
  }),
}));

export const artifactsRelations = relations(artifacts, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [artifacts.workspaceId],
    references: [workspaces.id],
  }),
}));
