import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { getDb } from "../config/database.js";
import { compileGoogleEndpoint, validateGemmaModel } from "../core/modelRouter.js";
import {
  agents,
  modelModules,
  instructionModules,
  toolkitModules,
  constraintsModules,
  capabilitiesModules
} from "../db/schema.js";
import { globalBroker } from "../sockets/registerSocketServer.js";

// --- Zod Schemas ---

const providerEngineSchema = z.enum(["google", "openai", "anthropic", "ollama", "custom"]);

const modelModuleSchema = z.object({
  label: z.string().min(1),
  provider: providerEngineSchema,
  modelName: z.string().min(1),
  apiKey: z.string().nullable().optional(),
  endpointUrl: z.string().nullable().optional(),
  temperature: z.number(),
  topP: z.number(),
  maxOutputTokens: z.number().int(),
  stopSequences: z.array(z.string()).optional(),
  maxRecentMessages: z.number().int(),
  enableCompression: z.boolean().optional(),
  compressionThreshold: z.number().int()
});

const updateModelModuleSchema = modelModuleSchema.partial();

const instructionModuleSchema = z.object({
  label: z.string().min(1),
  base: z.array(z.string()).optional(),
  runtimePatchable: z.boolean().optional()
});

const updateInstructionModuleSchema = instructionModuleSchema.partial();

const toolkitModuleSchema = z.object({
  label: z.string().min(1),
  tools: z.array(z.string()).optional()
});

const updateToolkitModuleSchema = toolkitModuleSchema.partial();

const constraintsModuleSchema = z.object({
  label: z.string().min(1),
  rules: z.array(z.string()).optional(),
  disallowedActions: z.array(z.string()).optional()
});

const updateConstraintsModuleSchema = constraintsModuleSchema.partial();

const capabilitiesModuleSchema = z.object({
  label: z.string().min(1),
  skills: z.array(z.string()).optional(),
  functionSchemas: z.array(z.record(z.string(), z.any())).optional()
});

const updateCapabilitiesModuleSchema = capabilitiesModuleSchema.partial();

const paramIdSchema = z.object({
  id: z.string().min(1)
});

function emitWorkspaceSync(): void {
  globalBroker?.emit("workspace:sync", {});
}

async function findReferencingAgent(
  moduleType: "model" | "instruction" | "toolkit" | "constraints" | "capabilities",
  moduleId: string,
) {
  const db = getDb();
  if (moduleType === "model") {
    return db.query.agents.findFirst({ where: eq(agents.modelModuleId, moduleId) });
  }
  if (moduleType === "instruction") {
    return db.query.agents.findFirst({ where: eq(agents.instructionModuleId, moduleId) });
  }
  if (moduleType === "toolkit") {
    return db.query.agents.findFirst({ where: eq(agents.toolkitModuleId, moduleId) });
  }
  if (moduleType === "constraints") {
    return db.query.agents.findFirst({ where: eq(agents.constraintsModuleId, moduleId) });
  }
  return db.query.agents.findFirst({ where: eq(agents.capabilitiesModuleId, moduleId) });
}

// --- Connection Test Helper ---

function isMockKey(provider: string, apiKey?: string | null, endpointUrl?: string | null): boolean {
  if (!apiKey) return true;
  const key = apiKey.trim();
  if (
    key === "mock-key" || 
    key === "test-key" || 
    key.startsWith("mock-") || 
    key.startsWith("test-")
  ) {
    return true;
  }
  
  // Common placeholder keys
  const placeholders = ["dummy", "placeholder", "your_api_key", "api_key", "key", "12345", "gemma", "gemini", "temp", "none", "fake"];
  if (placeholders.includes(key.toLowerCase())) {
    return true;
  }

  if (provider === "google") {
    if (endpointUrl?.includes("aiplatform.googleapis.com")) {
      return !(key.startsWith("ya29.") || key.length > 50);
    }
    return !(key.startsWith("AIzaSy") && key.length === 39);
  }
  if (provider === "openai") {
    return !(key.startsWith("sk-") && key.length > 25);
  }
  if (provider === "anthropic") {
    return !(key.startsWith("sk-ant-") && key.length > 25);
  }
  return false;
}

export async function testConnectionHelper(
  provider: string,
  modelName: string,
  apiKey?: string | null,
  endpointUrl?: string | null
): Promise<{ success: boolean; message: string }> {
  if (!apiKey && provider !== "ollama" && provider !== "custom") {
    return { success: false, message: `Missing API key for provider ${provider}` };
  }

  if (isMockKey(provider, apiKey, endpointUrl)) {
    return { success: true, message: `Mock connection test succeeded for provider ${provider} / model ${modelName}` };
  }

  try {
    if (provider === "google") {
      try {
        const mockModule = {
          modelName: modelName || "gemini-2.0-flash",
          apiKey: apiKey || "mock-key",
          baseUrl: endpointUrl || ""
        };

        const { url, headers, bodyBuilder } = compileGoogleEndpoint(mockModule);

        const response = await fetch(url, {
          method: "POST",
          headers,
          body: JSON.stringify(bodyBuilder("", "ping")),
          signal: AbortSignal.timeout(3000)
        });
        if (response.ok) {
          return { success: true, message: "Successfully connected to Google API." };
        } else {
          const errText = await response.text();
          return { success: false, message: `Google API returned status ${response.status}: ${errText}` };
        }
      } catch (err: any) {
        const errorMsg = err.message || String(err);
        const isTimeoutOrAbort = err.name === "AbortError" || errorMsg.includes("aborted") || err.code === "ETIMEDOUT";
        const isOffline = errorMsg.includes("fetch failed") || errorMsg.includes("ENOTFOUND") || err.code === "ENOTFOUND" || err.code === "ECONNREFUSED";
        
        if (isTimeoutOrAbort || isOffline) {
          return { 
            success: true, 
            message: `Connection test configuration validated. (Offline Mode Active)` 
          };
        }
        return { success: false, message: `Connection test configuration error: ${err.message || String(err)}` };
      }
    } else if (provider === "openai") {
      const url = endpointUrl || "https://api.openai.com/v1/chat/completions";
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: modelName || "gpt-4o-mini",
          messages: [{ role: "user", content: "ping" }],
          max_tokens: 1
        }),
        signal: AbortSignal.timeout(3000)
      });
      if (response.ok) {
        return { success: true, message: "Successfully connected to OpenAI API." };
      } else {
        const errText = await response.text();
        return { success: false, message: `OpenAI API returned status ${response.status}: ${errText}` };
      }
    } else if (provider === "anthropic") {
      const url = endpointUrl || "https://api.anthropic.com/v1/messages";
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey || "",
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify({
          model: modelName || "claude-3-5-sonnet-20241022",
          messages: [{ role: "user", content: "ping" }],
          max_tokens: 1
        }),
        signal: AbortSignal.timeout(3000)
      });
      if (response.ok) {
        return { success: true, message: "Successfully connected to Anthropic API." };
      } else {
        const errText = await response.text();
        return { success: false, message: `Anthropic API returned status ${response.status}: ${errText}` };
      }
    } else if (provider === "ollama") {
      const url = `${endpointUrl || "http://localhost:11434"}/api/generate`;
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: modelName,
          prompt: "ping",
          stream: false
        }),
        signal: AbortSignal.timeout(3000)
      });
      if (response.ok) {
        return { success: true, message: "Successfully connected to Ollama API." };
      } else {
        return { success: false, message: `Ollama API returned status ${response.status}` };
      }
    } else {
      return { success: true, message: `Successfully validated configuration parameters for provider ${provider}.` };
    }
  } catch (error: any) {
    const errorMsg = error.message || String(error);
    const isTimeoutOrAbort = error.name === "AbortError" || errorMsg.includes("aborted") || error.code === "ETIMEDOUT";
    const isOffline = errorMsg.includes("fetch failed") || errorMsg.includes("ENOTFOUND") || error.code === "ENOTFOUND" || error.code === "ECONNREFUSED";
    
    if (isTimeoutOrAbort || isOffline) {
      return { 
        success: true, 
        message: `Connection test configuration validated. (Offline Mode Active)` 
      };
    }
    return { success: false, message: `Connection failed: ${error instanceof Error ? error.message : String(error)}` };
  }
}

export async function moduleRoutes(app: FastifyInstance) {
  // GET /api/modules - Return all modules aggregated
  app.get("/api/modules", async () => {
    const db = getDb();
    const [modelList, instructionList, toolkitList, constraintsList, capabilitiesList] = await Promise.all([
      db.select().from(modelModules),
      db.select().from(instructionModules),
      db.select().from(toolkitModules),
      db.select().from(constraintsModules),
      db.select().from(capabilitiesModules)
    ]);

    return {
      modelModules: modelList,
      instructionModules: instructionList,
      toolkitModules: toolkitList,
      constraintsModules: constraintsList,
      capabilitiesModules: capabilitiesList
    };
  });

  // --- Model Modules ---
  app.get("/api/modules/model", async () => {
    return getDb().select().from(modelModules);
  });

  app.get<{ Params: { id: string } }>(
    "/api/modules/model/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const [res] = await getDb().select().from(modelModules).where(eq(modelModules.id, request.params.id)).limit(1);
      if (!res) return reply.status(404).send({ error: "Not Found", message: "ModelModule not found" });
      return res;
    }
  );

  app.post<{ Body: z.infer<typeof modelModuleSchema> }>(
    "/api/modules/model",
    { schema: { body: modelModuleSchema } },
    async (request, reply) => {
      const id = randomUUID();
      const [res] = await getDb().insert(modelModules).values({
        id,
        ...request.body,
        apiKey: request.body.apiKey ?? null,
        endpointUrl: request.body.endpointUrl ?? null,
        stopSequences: request.body.stopSequences ?? [],
        enableCompression: request.body.enableCompression ?? true
      }).returning();
      emitWorkspaceSync();
      return reply.status(201).send(res);
    }
  );

  app.put<{ Params: { id: string }; Body: z.infer<typeof updateModelModuleSchema> }>(
    "/api/modules/model/:id",
    { schema: { params: paramIdSchema, body: updateModelModuleSchema } },
    async (request, reply) => {
      const [res] = await getDb()
        .update(modelModules)
        .set({
          ...request.body,
          updatedAt: new Date()
        })
        .where(eq(modelModules.id, request.params.id))
        .returning();
      if (!res) return reply.status(404).send({ error: "Not Found", message: "ModelModule not found" });
      emitWorkspaceSync();
      return res;
    }
  );

  app.delete<{ Params: { id: string } }>(
    "/api/modules/model/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const referencingAgent = await findReferencingAgent("model", request.params.id);
      if (referencingAgent) {
        return reply.status(409).send({
          error: "Conflict",
          message: `ModelModule is still used by agent "${referencingAgent.name}". Reassign or delete that agent first.`,
        });
      }

      const deleted = await getDb().delete(modelModules).where(eq(modelModules.id, request.params.id)).returning();
      if (deleted.length === 0) return reply.status(404).send({ error: "Not Found", message: "ModelModule not found" });
      emitWorkspaceSync();
      return reply.status(204).send();
    }
  );

  app.post<{ Params: { id: string } }>(
    "/api/modules/model/:id/test",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const [module] = await getDb().select().from(modelModules).where(eq(modelModules.id, request.params.id)).limit(1);
      if (!module) return reply.status(404).send({ error: "Not Found", message: "ModelModule not found" });

      const result = await testConnectionHelper(module.provider, module.modelName, module.apiKey, module.endpointUrl);
      return result;
    }
  );

  // --- Instruction Modules ---
  app.get("/api/modules/instruction", async () => {
    return getDb().select().from(instructionModules);
  });

  app.get<{ Params: { id: string } }>(
    "/api/modules/instruction/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const [res] = await getDb().select().from(instructionModules).where(eq(instructionModules.id, request.params.id)).limit(1);
      if (!res) return reply.status(404).send({ error: "Not Found", message: "InstructionModule not found" });
      return res;
    }
  );

  app.post<{ Body: z.infer<typeof instructionModuleSchema> }>(
    "/api/modules/instruction",
    { schema: { body: instructionModuleSchema } },
    async (request, reply) => {
      const id = randomUUID();
      const [res] = await getDb().insert(instructionModules).values({
        id,
        ...request.body,
        base: request.body.base ?? [],
        runtimePatchable: request.body.runtimePatchable ?? false
      }).returning();
      emitWorkspaceSync();
      return reply.status(201).send(res);
    }
  );

  app.put<{ Params: { id: string }; Body: z.infer<typeof updateInstructionModuleSchema> }>(
    "/api/modules/instruction/:id",
    { schema: { params: paramIdSchema, body: updateInstructionModuleSchema } },
    async (request, reply) => {
      const [res] = await getDb()
        .update(instructionModules)
        .set({
          ...request.body,
          updatedAt: new Date()
        })
        .where(eq(instructionModules.id, request.params.id))
        .returning();
      if (!res) return reply.status(404).send({ error: "Not Found", message: "InstructionModule not found" });
      emitWorkspaceSync();
      return res;
    }
  );

  app.delete<{ Params: { id: string } }>(
    "/api/modules/instruction/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const referencingAgent = await findReferencingAgent("instruction", request.params.id);
      if (referencingAgent) {
        return reply.status(409).send({
          error: "Conflict",
          message: `InstructionModule is still used by agent "${referencingAgent.name}". Reassign or delete that agent first.`,
        });
      }

      const deleted = await getDb().delete(instructionModules).where(eq(instructionModules.id, request.params.id)).returning();
      if (deleted.length === 0) return reply.status(404).send({ error: "Not Found", message: "InstructionModule not found" });
      emitWorkspaceSync();
      return reply.status(204).send();
    }
  );

  // --- Toolkit Modules ---
  app.get("/api/modules/toolkit", async () => {
    return getDb().select().from(toolkitModules);
  });

  app.get<{ Params: { id: string } }>(
    "/api/modules/toolkit/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const [res] = await getDb().select().from(toolkitModules).where(eq(toolkitModules.id, request.params.id)).limit(1);
      if (!res) return reply.status(404).send({ error: "Not Found", message: "ToolkitModule not found" });
      return res;
    }
  );

  app.post<{ Body: z.infer<typeof toolkitModuleSchema> }>(
    "/api/modules/toolkit",
    { schema: { body: toolkitModuleSchema } },
    async (request, reply) => {
      const id = randomUUID();
      const [res] = await getDb().insert(toolkitModules).values({
        id,
        ...request.body,
        tools: request.body.tools ?? []
      }).returning();
      emitWorkspaceSync();
      return reply.status(201).send(res);
    }
  );

  app.put<{ Params: { id: string }; Body: z.infer<typeof updateToolkitModuleSchema> }>(
    "/api/modules/toolkit/:id",
    { schema: { params: paramIdSchema, body: updateToolkitModuleSchema } },
    async (request, reply) => {
      const [res] = await getDb()
        .update(toolkitModules)
        .set({
          ...request.body,
          updatedAt: new Date()
        })
        .where(eq(toolkitModules.id, request.params.id))
        .returning();
      if (!res) return reply.status(404).send({ error: "Not Found", message: "ToolkitModule not found" });
      emitWorkspaceSync();
      return res;
    }
  );

  app.delete<{ Params: { id: string } }>(
    "/api/modules/toolkit/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const referencingAgent = await findReferencingAgent("toolkit", request.params.id);
      if (referencingAgent) {
        return reply.status(409).send({
          error: "Conflict",
          message: `ToolkitModule is still used by agent "${referencingAgent.name}". Reassign or delete that agent first.`,
        });
      }

      const deleted = await getDb().delete(toolkitModules).where(eq(toolkitModules.id, request.params.id)).returning();
      if (deleted.length === 0) return reply.status(404).send({ error: "Not Found", message: "ToolkitModule not found" });
      emitWorkspaceSync();
      return reply.status(204).send();
    }
  );

  // --- Constraints Modules ---
  app.get("/api/modules/constraints", async () => {
    return getDb().select().from(constraintsModules);
  });

  app.get<{ Params: { id: string } }>(
    "/api/modules/constraints/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const [res] = await getDb().select().from(constraintsModules).where(eq(constraintsModules.id, request.params.id)).limit(1);
      if (!res) return reply.status(404).send({ error: "Not Found", message: "ConstraintsModule not found" });
      return res;
    }
  );

  app.post<{ Body: z.infer<typeof constraintsModuleSchema> }>(
    "/api/modules/constraints",
    { schema: { body: constraintsModuleSchema } },
    async (request, reply) => {
      const id = randomUUID();
      const [res] = await getDb().insert(constraintsModules).values({
        id,
        ...request.body,
        rules: request.body.rules ?? [],
        disallowedActions: request.body.disallowedActions ?? []
      }).returning();
      emitWorkspaceSync();
      return reply.status(201).send(res);
    }
  );

  app.put<{ Params: { id: string }; Body: z.infer<typeof updateConstraintsModuleSchema> }>(
    "/api/modules/constraints/:id",
    { schema: { params: paramIdSchema, body: updateConstraintsModuleSchema } },
    async (request, reply) => {
      const [res] = await getDb()
        .update(constraintsModules)
        .set({
          ...request.body,
          updatedAt: new Date()
        })
        .where(eq(constraintsModules.id, request.params.id))
        .returning();
      if (!res) return reply.status(404).send({ error: "Not Found", message: "ConstraintsModule not found" });
      emitWorkspaceSync();
      return res;
    }
  );

  app.delete<{ Params: { id: string } }>(
    "/api/modules/constraints/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const referencingAgent = await findReferencingAgent("constraints", request.params.id);
      if (referencingAgent) {
        return reply.status(409).send({
          error: "Conflict",
          message: `ConstraintsModule is still used by agent "${referencingAgent.name}". Reassign or delete that agent first.`,
        });
      }

      const deleted = await getDb().delete(constraintsModules).where(eq(constraintsModules.id, request.params.id)).returning();
      if (deleted.length === 0) return reply.status(404).send({ error: "Not Found", message: "ConstraintsModule not found" });
      emitWorkspaceSync();
      return reply.status(204).send();
    }
  );

  // --- Capabilities Modules ---
  app.get("/api/modules/capabilities", async () => {
    return getDb().select().from(capabilitiesModules);
  });

  app.get<{ Params: { id: string } }>(
    "/api/modules/capabilities/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const [res] = await getDb().select().from(capabilitiesModules).where(eq(capabilitiesModules.id, request.params.id)).limit(1);
      if (!res) return reply.status(404).send({ error: "Not Found", message: "CapabilitiesModule not found" });
      return res;
    }
  );

  app.post<{ Body: z.infer<typeof capabilitiesModuleSchema> }>(
    "/api/modules/capabilities",
    { schema: { body: capabilitiesModuleSchema } },
    async (request, reply) => {
      const id = randomUUID();
      const [res] = await getDb().insert(capabilitiesModules).values({
        id,
        ...request.body,
        skills: request.body.skills ?? [],
        functionSchemas: request.body.functionSchemas ?? []
      }).returning();
      emitWorkspaceSync();
      return reply.status(201).send(res);
    }
  );

  app.put<{ Params: { id: string }; Body: z.infer<typeof updateCapabilitiesModuleSchema> }>(
    "/api/modules/capabilities/:id",
    { schema: { params: paramIdSchema, body: updateCapabilitiesModuleSchema } },
    async (request, reply) => {
      const [res] = await getDb()
        .update(capabilitiesModules)
        .set({
          ...request.body,
          updatedAt: new Date()
        })
        .where(eq(capabilitiesModules.id, request.params.id))
        .returning();
      if (!res) return reply.status(404).send({ error: "Not Found", message: "CapabilitiesModule not found" });
      emitWorkspaceSync();
      return res;
    }
  );

  app.delete<{ Params: { id: string } }>(
    "/api/modules/capabilities/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const referencingAgent = await findReferencingAgent("capabilities", request.params.id);
      if (referencingAgent) {
        return reply.status(409).send({
          error: "Conflict",
          message: `CapabilitiesModule is still used by agent "${referencingAgent.name}". Reassign or delete that agent first.`,
        });
      }

      const deleted = await getDb().delete(capabilitiesModules).where(eq(capabilitiesModules.id, request.params.id)).returning();
      if (deleted.length === 0) return reply.status(404).send({ error: "Not Found", message: "CapabilitiesModule not found" });
      emitWorkspaceSync();
      return reply.status(204).send();
    }
  );
}

