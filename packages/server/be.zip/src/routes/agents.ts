import type { FastifyInstance } from "fastify";
import { z } from "zod";

import { AgentRegistry } from "../core/AgentRegistry.js";
import { globalBroker } from "../sockets/registerSocketServer.js";

const authorityLevelSchema = z.union([z.literal(0), z.literal(1), z.literal(2), z.literal(3)]);
const l3SubtypeSchema = z.enum(["worker", "supervisor"]);
const memorySharingPolicySchema = z.enum(["none", "horizontal", "vertical", "full"]);
const agentStatusSchema = z.enum(["idle", "working", "paused", "offline"]);

const permissionsSchema = z
  .object({
    spawnAgents: z.boolean().optional(),
    patchRuntime: z.boolean().optional(),
    accessAllChannels: z.boolean().optional(),
  })
  .optional();

const createAgentSchema = z.object({
  name: z.string().min(1),
  title: z.string().min(1),
  species: z.string().min(1).optional(),
  avatar: z.string().min(1).optional(),
  authorityLevel: authorityLevelSchema,
  l3Subtype: l3SubtypeSchema.optional(),
  modelModuleId: z.string().min(1),
  instructionModuleId: z.string().min(1),
  toolkitModuleId: z.string().min(1).optional(),
  constraintsModuleId: z.string().min(1).optional(),
  capabilitiesModuleId: z.string().min(1).optional(),
  memorySharingPolicy: memorySharingPolicySchema,
  isOmniscient: z.boolean().optional(),
  fallbackAgentId: z.string().min(1).optional(),
  categoryPermissions: z.array(z.string().min(1)).optional(),
  permissions: permissionsSchema,
  status: agentStatusSchema.optional(),
  isTemplate: z.boolean().optional(),
});

const updateAgentSchema = z.object({
  name: z.string().min(1).optional(),
  title: z.string().min(1).optional(),
  species: z.string().min(1).nullable().optional(),
  avatar: z.string().min(1).nullable().optional(),
  authorityLevel: authorityLevelSchema.optional(),
  l3Subtype: l3SubtypeSchema.nullable().optional(),
  modelModuleId: z.string().min(1).optional(),
  instructionModuleId: z.string().min(1).optional(),
  toolkitModuleId: z.string().min(1).nullable().optional(),
  constraintsModuleId: z.string().min(1).nullable().optional(),
  capabilitiesModuleId: z.string().min(1).nullable().optional(),
  memorySharingPolicy: memorySharingPolicySchema.optional(),
  isOmniscient: z.boolean().optional(),
  fallbackAgentId: z.string().min(1).nullable().optional(),
  categoryPermissions: z.array(z.string().min(1)).optional(),
  permissions: permissionsSchema,
  status: agentStatusSchema.optional(),
  isTemplate: z.boolean().optional(),
});

const listAgentsQuerySchema = z.object({
  authorityLevel: z.coerce.number().int().min(0).max(3).optional(),
  status: agentStatusSchema.optional(),
  isTemplate: z.coerce.boolean().optional(),
});

const agentParamsSchema = z.object({
  id: z.string().min(1),
});

type ListAgentsQuery = z.infer<typeof listAgentsQuerySchema>;
type AgentParams = z.infer<typeof agentParamsSchema>;
type CreateAgentBody = z.infer<typeof createAgentSchema>;
type UpdateAgentBody = z.infer<typeof updateAgentSchema>;

function emitWorkspaceSync(): void {
  globalBroker?.emit("workspace:sync", {});
}

export async function agentRoutes(app: FastifyInstance) {
  const registry = new AgentRegistry();

  app.get<{ Querystring: ListAgentsQuery }>(
    "/api/agents",
    {
      schema: {
        querystring: listAgentsQuerySchema,
      },
    },
    async (request) =>
      registry.list({
        authorityLevel: request.query.authorityLevel as 0 | 1 | 2 | 3 | undefined,
        status: request.query.status,
        isTemplate: request.query.isTemplate,
      }),
  );

  app.get<{ Params: AgentParams }>(
    "/api/agents/:id",
    {
      schema: {
        params: agentParamsSchema,
      },
    },
    async (request, reply) => {
      const agent = await registry.getById(request.params.id);
      if (!agent) {
        return reply.status(404).send({
          statusCode: 404,
          error: "Not Found",
          message: "Agent not found",
        });
      }

      return agent;
    },
  );

  app.post<{ Body: CreateAgentBody }>(
    "/api/agents",
    {
      schema: {
        body: createAgentSchema,
      },
    },
    async (request, reply) => {
      try {
        const agent = await registry.create(request.body);
        emitWorkspaceSync();
        return reply.status(201).send(agent);
      } catch (error) {
        return reply.status(400).send({
          statusCode: 400,
          error: "Bad Request",
          message: error instanceof Error ? error.message : "Failed to create agent",
        });
      }
    },
  );

  app.put<{ Params: AgentParams; Body: UpdateAgentBody }>(
    "/api/agents/:id",
    {
      schema: {
        params: agentParamsSchema,
        body: updateAgentSchema,
      },
    },
    async (request, reply) => {
      try {
        const updated = await registry.update(request.params.id, request.body);
        if (!updated) {
          return reply.status(404).send({
            statusCode: 404,
            error: "Not Found",
            message: "Agent not found",
          });
        }

        emitWorkspaceSync();
        return updated;
      } catch (error) {
        return reply.status(400).send({
          statusCode: 400,
          error: "Bad Request",
          message: error instanceof Error ? error.message : "Failed to update agent",
        });
      }
    },
  );

  app.delete<{ Params: AgentParams }>(
    "/api/agents/:id",
    {
      schema: {
        params: agentParamsSchema,
      },
    },
    async (request, reply) => {
      const deleted = await registry.delete(request.params.id);
      if (!deleted) {
        return reply.status(404).send({
          statusCode: 404,
          error: "Not Found",
          message: "Agent not found",
        });
      }

      emitWorkspaceSync();
      return reply.status(204).send();
    },
  );
}
