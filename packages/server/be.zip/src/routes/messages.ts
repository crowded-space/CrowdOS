﻿import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { and, eq } from "drizzle-orm";
import { getDb } from "../config/database.js";
import { messages } from "../db/schema.js";

const getMessagesParamsSchema = z.object({
  channelId: z.string().min(1),
});

const getMessagesQuerySchema = z.object({
  includeMonologue: z.coerce.boolean().optional().default(false),
});

export async function messageRoutes(app: FastifyInstance) {
  // GET /api/channels/:channelId/messages - Retrieve message logs for a channel
  app.get<{ Params: { channelId: string }; Querystring: { includeMonologue?: boolean } }>(
    "/api/channels/:channelId/messages",
    {
      schema: {
        params: getMessagesParamsSchema,
        querystring: getMessagesQuerySchema,
      },
    },
    async (request) => {
      const db = getDb();
      const { channelId } = request.params;
      const includeMonologue = request.query.includeMonologue ?? false;

      const conditions = [eq(messages.channelId, channelId)];
      if (!includeMonologue) {
        conditions.push(eq(messages.isInternalMonologue, false));
      }

      const list = await db.query.messages.findMany({
        where: and(...conditions),
        orderBy: (table, { asc }) => [asc(table.sequenceNumber)],
      });

      return list;
    }
  );
}
