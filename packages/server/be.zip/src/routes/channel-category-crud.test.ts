import { afterAll, beforeAll, describe, expect, it } from "vitest";
import Fastify from "fastify";
import { eq } from "drizzle-orm";
import { getDb, closeDatabaseConnection } from "../config/database.js";
import { setupErrorHandler } from "../core/errors.js";
import { validatorCompiler } from "../core/validation.js";
import { categories, channels } from "../db/schema.js";
import { registerRoutes } from "./index.js";

describe("Category and Channel CRUD route synchronization", () => {
  let app: any;
  const createdCategoryIds: string[] = [];
  const createdChannelIds: string[] = [];

  beforeAll(async () => {
    app = Fastify();
    app.setValidatorCompiler(validatorCompiler);
    setupErrorHandler(app);
    await app.register(registerRoutes);
    await app.ready();
  });

  afterAll(async () => {
    const db = getDb();
    for (const id of createdChannelIds) {
      await db.delete(channels).where(eq(channels.id, id));
    }
    for (const id of createdCategoryIds) {
      await db.delete(categories).where(eq(categories.id, id));
    }
    await app.close();
    await closeDatabaseConnection();
  });

  it("should create, update, archive, restore, and delete a channel", async () => {
    const createCategory = await app.inject({
      method: "POST",
      url: "/api/categories",
      payload: {
        name: "Route Sync Test",
        createdBy: "test",
        position: 90
      }
    });
    expect(createCategory.statusCode).toBe(201);
    const category = JSON.parse(createCategory.body);
    createdCategoryIds.push(category.id);

    const createChannel = await app.inject({
      method: "POST",
      url: "/api/channels",
      payload: {
        categoryId: category.id,
        name: "sync-crud",
        createdBy: "test",
        position: 0
      }
    });
    expect(createChannel.statusCode).toBe(201);
    const channel = JSON.parse(createChannel.body);
    createdChannelIds.push(channel.id);

    const updateChannel = await app.inject({
      method: "PATCH",
      url: `/api/channels/${channel.id}`,
      payload: {
        name: "sync-crud-renamed",
        position: 4
      }
    });
    expect(updateChannel.statusCode).toBe(200);
    expect(JSON.parse(updateChannel.body).position).toBe(4);

    const archiveChannel = await app.inject({
      method: "PATCH",
      url: `/api/channels/${channel.id}`,
      payload: {
        type: "archived"
      }
    });
    expect(archiveChannel.statusCode).toBe(200);
    expect(JSON.parse(archiveChannel.body).type).toBe("archived");
    expect(JSON.parse(archiveChannel.body).archivedAt).toBeTruthy();

    const restoreChannel = await app.inject({
      method: "PATCH",
      url: `/api/channels/${channel.id}`,
      payload: {
        type: "standard"
      }
    });
    expect(restoreChannel.statusCode).toBe(200);
    expect(JSON.parse(restoreChannel.body).type).toBe("standard");
    expect(JSON.parse(restoreChannel.body).archivedAt).toBeNull();

    const deleteChannel = await app.inject({
      method: "DELETE",
      url: `/api/channels/${channel.id}`
    });
    expect(deleteChannel.statusCode).toBe(204);
    createdChannelIds.splice(createdChannelIds.indexOf(channel.id), 1);
  });

  it("should delete child channels before deleting a category", async () => {
    const createCategory = await app.inject({
      method: "POST",
      url: "/api/categories",
      payload: {
        name: "Route Cascade Test",
        createdBy: "test",
        position: 91
      }
    });
    expect(createCategory.statusCode).toBe(201);
    const category = JSON.parse(createCategory.body);
    createdCategoryIds.push(category.id);

    const createChannel = await app.inject({
      method: "POST",
      url: "/api/channels",
      payload: {
        categoryId: category.id,
        name: "cascade-child",
        createdBy: "test",
        position: 0
      }
    });
    expect(createChannel.statusCode).toBe(201);
    const channel = JSON.parse(createChannel.body);
    createdChannelIds.push(channel.id);

    const deleteCategory = await app.inject({
      method: "DELETE",
      url: `/api/categories/${category.id}`
    });
    expect(deleteCategory.statusCode).toBe(204);
    createdCategoryIds.splice(createdCategoryIds.indexOf(category.id), 1);

    const channelList = await app.inject({
      method: "GET",
      url: "/api/channels"
    });
    expect(JSON.parse(channelList.body).some((item: any) => item.id === channel.id)).toBe(false);
    createdChannelIds.splice(createdChannelIds.indexOf(channel.id), 1);
  });

  it("should reject channels created under a missing category", async () => {
    const response = await app.inject({
      method: "POST",
      url: "/api/channels",
      payload: {
        categoryId: "missing-category-id",
        name: "invalid-channel",
        createdBy: "test",
        position: 0
      }
    });

    expect(response.statusCode).toBe(400);
    expect(JSON.parse(response.body).message).toContain("Category not found");
  });

  it("should protect the top-level general channel from hard delete", async () => {
    const createGeneral = await app.inject({
      method: "POST",
      url: "/api/channels",
      payload: {
        categoryId: null,
        name: "general",
        createdBy: "test",
        position: 999
      }
    });
    expect(createGeneral.statusCode).toBe(201);
    const general = JSON.parse(createGeneral.body);
    createdChannelIds.push(general.id);

    const deleteGeneral = await app.inject({
      method: "DELETE",
      url: `/api/channels/${general.id}`
    });
    expect(deleteGeneral.statusCode).toBe(409);
    expect(JSON.parse(deleteGeneral.body).message).toContain("cannot be deleted");
  });
});
