import type { FastifyInstance, FastifyReply, FastifyRequest } from "fastify";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { getDb } from "../config/database.js";
import { categories, channels } from "../db/schema.js";
import { globalBroker } from "../sockets/registerSocketServer.js";

const channelTypeSchema = z.enum(["standard", "pair_private", "archived"]);

const createChannelSchema = z.object({
  categoryId: z.string().nullable().optional(),
  name: z.string().min(1),
  type: channelTypeSchema.default("standard"),
  createdBy: z.string().min(1),
  position: z.number().int().default(0),
});

const updateChannelSchema = z.object({
  categoryId: z.string().nullable().optional(),
  name: z.string().optional(),
  type: channelTypeSchema.optional(),
  position: z.number().int().optional(),
});

const paramIdSchema = z.object({
  id: z.string().min(1),
});

function emitWorkspaceSync(): void {
  globalBroker?.emit("workspace:sync", {});
}

async function categoryExists(categoryId: string): Promise<boolean> {
  const db = getDb();
  const category = await db.query.categories.findFirst({
    where: eq(categories.id, categoryId),
  });
  return Boolean(category);
}

export async function channelRoutes(app: FastifyInstance) {
  // GET /api/channels - List all channels
  app.get("/api/channels", async () => {
    const db = getDb();
    const list = await db.query.channels.findMany({
      orderBy: (table, { asc }) => [asc(table.position)],
    });
    return list;
  });

  // POST /api/channels - Create a channel under a category
  app.post<{ Body: z.infer<typeof createChannelSchema> }>(
    "/api/channels",
    { schema: { body: createChannelSchema } },
    async (request, reply) => {
      const db = getDb();
      if (request.body.categoryId && !(await categoryExists(request.body.categoryId))) {
        return reply.status(400).send({
          error: "Bad Request",
          message: `Category not found: ${request.body.categoryId}`,
        });
      }

      const id = randomUUID();
      const [res] = await db
        .insert(channels)
        .values({
          id,
          categoryId: request.body.categoryId ?? null,
          name: request.body.name,
          type: request.body.type,
          createdBy: request.body.createdBy,
          position: request.body.position,
        })
        .returning();
      emitWorkspaceSync();
      return reply.status(201).send(res);
    }
  );

  async function updateChannel(
    request: FastifyRequest<{ Params: { id: string }; Body: z.infer<typeof updateChannelSchema> }>,
    reply: FastifyReply,
  ) {
    const db = getDb();
    const { id } = request.params;
    const existing = await db.query.channels.findFirst({
      where: eq(channels.id, id),
    });

    if (!existing) {
      return reply.status(404).send({ error: "Not Found", message: "Channel not found" });
    }

    if (request.body.categoryId && !(await categoryExists(request.body.categoryId))) {
      return reply.status(400).send({
        error: "Bad Request",
        message: `Category not found: ${request.body.categoryId}`,
      });
    }

    const updateData: Partial<typeof channels.$inferInsert> = {};
    if (request.body.categoryId !== undefined) updateData.categoryId = request.body.categoryId;
    if (request.body.name !== undefined) updateData.name = request.body.name;
    if (request.body.position !== undefined) updateData.position = request.body.position;
    if (request.body.type !== undefined) {
      updateData.type = request.body.type;
      updateData.archivedAt = request.body.type === "archived" ? new Date() : null;
    }

    const [updated] = await db
      .update(channels)
      .set(updateData)
      .where(eq(channels.id, id))
      .returning();

    emitWorkspaceSync();
    return updated;
  }

  // PATCH /api/channels/:id - Update channel parameters (archive, rename, position, category)
  app.patch<{ Params: { id: string }; Body: z.infer<typeof updateChannelSchema> }>(
    "/api/channels/:id",
    { schema: { params: paramIdSchema, body: updateChannelSchema } },
    updateChannel,
  );

  // PUT alias keeps the route aligned with the project API table.
  app.put<{ Params: { id: string }; Body: z.infer<typeof updateChannelSchema> }>(
    "/api/channels/:id",
    { schema: { params: paramIdSchema, body: updateChannelSchema } },
    updateChannel,
  );

  // DELETE /api/channels/:id - Delete a channel
  app.delete<{ Params: { id: string } }>(
    "/api/channels/:id",
    { schema: { params: paramIdSchema } },
    async (request, reply) => {
      const db = getDb();
      const existing = await db.query.channels.findFirst({
        where: eq(channels.id, request.params.id),
      });

      if (!existing) {
        return reply.status(404).send({ error: "Not Found", message: "Channel not found" });
      }

      if (existing.categoryId === null && existing.name.toLowerCase() === "general") {
        return reply.status(409).send({
          error: "Conflict",
          message: "The top-level #general channel cannot be deleted.",
        });
      }

      const deleted = await db
        .delete(channels)
        .where(eq(channels.id, request.params.id))
        .returning();
      if (deleted.length === 0) return reply.status(404).send({ error: "Not Found", message: "Channel not found" });

      emitWorkspaceSync();
      return reply.status(204).send();
    }
  );
}
