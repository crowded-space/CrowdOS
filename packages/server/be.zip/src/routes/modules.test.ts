﻿import { afterAll, beforeAll, describe, expect, it } from "vitest";
import Fastify from "fastify";
import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { getDb, closeDatabaseConnection } from "../config/database.js";
import { validatorCompiler } from "../core/validation.js";
import { setupErrorHandler } from "../core/errors.js";
import { registerRoutes } from "./index.js";
import {
  modelModules,
  instructionModules,
  toolkitModules,
  constraintsModules,
  capabilitiesModules,
  generationModelProfiles,
  embeddingModelProfiles,
  indexingModelProfiles,
  workspaceSettings,
  agents
} from "../db/schema.js";

describe("Modules, Providers & Workspace Settings API Routes Integration Tests", () => {
  let app: any;

  // Keep track of created IDs for cleanup
  const createdModelIds: string[] = [];
  const createdInstructionIds: string[] = [];
  const createdToolkitIds: string[] = [];
  const createdConstraintsIds: string[] = [];
  const createdCapabilitiesIds: string[] = [];
  const createdGenProfileIds: string[] = [];
  const createdEmbProfileIds: string[] = [];
  const createdIdxProfileIds: string[] = [];
  const createdAgentIds: string[] = [];

  beforeAll(async () => {
    app = Fastify();
    app.setValidatorCompiler(validatorCompiler);
    setupErrorHandler(app);
    await app.register(registerRoutes);
    await app.ready();
  });

  afterAll(async () => {
    const db = getDb();
    // Cleanup database entries
    for (const id of createdAgentIds) {
      await db.delete(agents).where(eq(agents.id, id));
    }
    for (const id of createdModelIds) {
      await db.delete(modelModules).where(eq(modelModules.id, id));
    }
    for (const id of createdInstructionIds) {
      await db.delete(instructionModules).where(eq(instructionModules.id, id));
    }
    for (const id of createdToolkitIds) {
      await db.delete(toolkitModules).where(eq(toolkitModules.id, id));
    }
    for (const id of createdConstraintsIds) {
      await db.delete(constraintsModules).where(eq(constraintsModules.id, id));
    }
    for (const id of createdCapabilitiesIds) {
      await db.delete(capabilitiesModules).where(eq(capabilitiesModules.id, id));
    }
    for (const id of createdGenProfileIds) {
      await db.delete(generationModelProfiles).where(eq(generationModelProfiles.id, id));
    }
    for (const id of createdEmbProfileIds) {
      await db.delete(embeddingModelProfiles).where(eq(embeddingModelProfiles.id, id));
    }
    for (const id of createdIdxProfileIds) {
      await db.delete(indexingModelProfiles).where(eq(indexingModelProfiles.id, id));
    }

    // Close fastify instance
    await app.close();
    // Close DB pool
    await closeDatabaseConnection();
  });

  // â”€â”€â”€ 1. Aggregated Modules Endpoint â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  it("should get all modules aggregated via GET /api/modules", async () => {
    const response = await app.inject({
      method: "GET",
      url: "/api/modules"
    });

    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body);
    expect(body).toHaveProperty("modelModules");
    expect(body).toHaveProperty("instructionModules");
    expect(body).toHaveProperty("toolkitModules");
    expect(body).toHaveProperty("constraintsModules");
    expect(body).toHaveProperty("capabilitiesModules");
  });

  // â”€â”€â”€ 2. ModelModules CRUD â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  it("should perform full CRUD on ModelModules and test connection", async () => {
    // Create
    const createPayload = {
      label: "Test Route Model",
      provider: "google",
      modelName: "gemini-2.0-flash",
      apiKey: "mock-key-1234",
      temperature: 0.8,
      topP: 0.9,
      maxOutputTokens: 1024,
      stopSequences: ["\n"],
      maxRecentMessages: 20,
      enableCompression: false,
      compressionThreshold: 100
    };

    const createRes = await app.inject({
      method: "POST",
      url: "/api/modules/model",
      payload: createPayload
    });

    expect(createRes.statusCode).toBe(201);
    const created = JSON.parse(createRes.body);
    expect(created.id).toBeDefined();
    expect(created.label).toBe(createPayload.label);
    createdModelIds.push(created.id);

    // Read list
    const listRes = await app.inject({
      method: "GET",
      url: "/api/modules/model"
    });
    expect(listRes.statusCode).toBe(200);
    const list = JSON.parse(listRes.body);
    expect(list.some((m: any) => m.id === created.id)).toBe(true);

    // Read by id
    const getRes = await app.inject({
      method: "GET",
      url: `/api/modules/model/${created.id}`
    });
    expect(getRes.statusCode).toBe(200);
    expect(JSON.parse(getRes.body).label).toBe(createPayload.label);

    // Update
    const updatePayload = {
      label: "Updated Test Route Model",
      temperature: 0.1
    };
    const updateRes = await app.inject({
      method: "PUT",
      url: `/api/modules/model/${created.id}`,
      payload: updatePayload
    });
    expect(updateRes.statusCode).toBe(200);
    const updated = JSON.parse(updateRes.body);
    expect(updated.label).toBe(updatePayload.label);
    expect(updated.temperature).toBe(updatePayload.temperature);

    // Test Connection
    const testRes = await app.inject({
      method: "POST",
      url: `/api/modules/model/${created.id}/test`
    });
    expect(testRes.statusCode).toBe(200);
    const testResult = JSON.parse(testRes.body);
    expect(testResult.success).toBe(true);

    // Delete
    const deleteRes = await app.inject({
      method: "DELETE",
      url: `/api/modules/model/${created.id}`
    });
    expect(deleteRes.statusCode).toBe(204);

    // Read again to verify deletion
    const getDeletedRes = await app.inject({
      method: "GET",
      url: `/api/modules/model/${created.id}`
    });
    expect(getDeletedRes.statusCode).toBe(404);
  });

  it("should return 409 when deleting a ModelModule still referenced by an agent", async () => {
    const createModel = await app.inject({
      method: "POST",
      url: "/api/modules/model",
      payload: {
        label: "Referenced Route Model",
        provider: "google",
        modelName: "gemini-2.0-flash",
        apiKey: "mock-key",
        temperature: 0.7,
        topP: 0.9,
        maxOutputTokens: 1024,
        maxRecentMessages: 20,
        compressionThreshold: 100
      }
    });
    expect(createModel.statusCode).toBe(201);
    const model = JSON.parse(createModel.body);
    createdModelIds.push(model.id);

    const createInstruction = await app.inject({
      method: "POST",
      url: "/api/modules/instruction",
      payload: {
        label: "Referenced Route Instruction",
        base: ["Reference guard test instruction"],
        runtimePatchable: true
      }
    });
    expect(createInstruction.statusCode).toBe(201);
    const instruction = JSON.parse(createInstruction.body);
    createdInstructionIds.push(instruction.id);

    const agentId = randomUUID();
    createdAgentIds.push(agentId);
    await getDb().insert(agents).values({
      id: agentId,
      name: `module-delete-guard-${agentId.slice(0, 8)}`,
      title: "Module Delete Guard",
      species: "Test",
      authorityLevel: 2,
      modelModuleId: model.id,
      instructionModuleId: instruction.id,
      memorySharingPolicy: "none",
      permissions: {
        spawnAgents: false,
        patchRuntime: false,
        accessAllChannels: false
      },
      status: "idle",
      isTemplate: false
    });

    const deleteRes = await app.inject({
      method: "DELETE",
      url: `/api/modules/model/${model.id}`
    });
    expect(deleteRes.statusCode).toBe(409);
    expect(JSON.parse(deleteRes.body).message).toContain("still used by agent");
  });

  // â”€â”€â”€ 3. InstructionModules CRUD â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  it("should perform full CRUD on InstructionModules", async () => {
    // Create
    const createPayload = {
      label: "Test Route Instruction",
      base: ["System instruction line 1"],
      runtimePatchable: true
    };

    const createRes = await app.inject({
      method: "POST",
      url: "/api/modules/instruction",
      payload: createPayload
    });

    expect(createRes.statusCode).toBe(201);
    const created = JSON.parse(createRes.body);
    expect(created.id).toBeDefined();
    expect(created.label).toBe(createPayload.label);
    createdInstructionIds.push(created.id);

    // Read List
    const listRes = await app.inject({
      method: "GET",
      url: "/api/modules/instruction"
    });
    expect(listRes.statusCode).toBe(200);

    // Read By Id
    const getRes = await app.inject({
      method: "GET",
      url: `/api/modules/instruction/${created.id}`
    });
    expect(getRes.statusCode).toBe(200);
    expect(JSON.parse(getRes.body).label).toBe(createPayload.label);

    // Update
    const updatePayload = {
      label: "Updated Test Route Instruction"
    };
    const updateRes = await app.inject({
      method: "PUT",
      url: `/api/modules/instruction/${created.id}`,
      payload: updatePayload
    });
    expect(updateRes.statusCode).toBe(200);
    expect(JSON.parse(updateRes.body).label).toBe(updatePayload.label);

    // Delete
    const deleteRes = await app.inject({
      method: "DELETE",
      url: `/api/modules/instruction/${created.id}`
    });
    expect(deleteRes.statusCode).toBe(204);
  });

  // â”€â”€â”€ 4. ToolkitModules CRUD â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  it("should perform full CRUD on ToolkitModules", async () => {
    // Create
    const createPayload = {
      label: "Test Route Toolkit",
      tools: ["view_file", "run_command"]
    };

    const createRes = await app.inject({
      method: "POST",
      url: "/api/modules/toolkit",
      payload: createPayload
    });

    expect(createRes.statusCode).toBe(201);
    const created = JSON.parse(createRes.body);
    createdToolkitIds.push(created.id);

    // Read List
    const listRes = await app.inject({
      method: "GET",
      url: "/api/modules/toolkit"
    });
    expect(listRes.statusCode).toBe(200);

    // Read By Id
    const getRes = await app.inject({
      method: "GET",
      url: `/api/modules/toolkit/${created.id}`
    });
    expect(getRes.statusCode).toBe(200);

    // Update
    const updateRes = await app.inject({
      method: "PUT",
      url: `/api/modules/toolkit/${created.id}`,
      payload: { label: "Updated Test Route Toolkit" }
    });
    expect(updateRes.statusCode).toBe(200);

    // Delete
    const deleteRes = await app.inject({
      method: "DELETE",
      url: `/api/modules/toolkit/${created.id}`
    });
    expect(deleteRes.statusCode).toBe(204);
  });

  // â”€â”€â”€ 5. ConstraintsModules CRUD â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  it("should perform full CRUD on ConstraintsModules", async () => {
    const createPayload = {
      label: "Test Constraints",
      rules: ["Do not delete filesystem"],
      disallowedActions: ["rm -rf"]
    };

    const createRes = await app.inject({
      method: "POST",
      url: "/api/modules/constraints",
      payload: createPayload
    });

    expect(createRes.statusCode).toBe(201);
    const created = JSON.parse(createRes.body);
    createdConstraintsIds.push(created.id);

    const getRes = await app.inject({
      method: "GET",
      url: `/api/modules/constraints/${created.id}`
    });
    expect(getRes.statusCode).toBe(200);

    const updateRes = await app.inject({
      method: "PUT",
      url: `/api/modules/constraints/${created.id}`,
      payload: { label: "Updated Constraints" }
    });
    expect(updateRes.statusCode).toBe(200);

    const deleteRes = await app.inject({
      method: "DELETE",
      url: `/api/modules/constraints/${created.id}`
    });
    expect(deleteRes.statusCode).toBe(204);
  });

  // â”€â”€â”€ 6. CapabilitiesModules CRUD â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  it("should perform full CRUD on CapabilitiesModules", async () => {
    const createPayload = {
      label: "Test Capabilities",
      skills: ["typescript", "fullstack"],
      functionSchemas: [{ name: "foo", description: "bar" }]
    };

    const createRes = await app.inject({
      method: "POST",
      url: "/api/modules/capabilities",
      payload: createPayload
    });

    expect(createRes.statusCode).toBe(201);
    const created = JSON.parse(createRes.body);
    createdCapabilitiesIds.push(created.id);

    const getRes = await app.inject({
      method: "GET",
      url: `/api/modules/capabilities/${created.id}`
    });
    expect(getRes.statusCode).toBe(200);

    const updateRes = await app.inject({
      method: "PUT",
      url: `/api/modules/capabilities/${created.id}`,
      payload: { label: "Updated Capabilities" }
    });
    expect(updateRes.statusCode).toBe(200);

    const deleteRes = await app.inject({
      method: "DELETE",
      url: `/api/modules/capabilities/${created.id}`
    });
    expect(deleteRes.statusCode).toBe(204);
  });

  // â”€â”€â”€ 7. Providers Aggregation and CRUD â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  it("should get all profiles aggregated via GET /api/providers", async () => {
    const response = await app.inject({
      method: "GET",
      url: "/api/providers"
    });
    expect(response.statusCode).toBe(200);
    const body = JSON.parse(response.body);
    expect(body).toHaveProperty("generationModelProfiles");
    expect(body).toHaveProperty("embeddingModelProfiles");
    expect(body).toHaveProperty("indexingModelProfiles");
  });

  it("should CRUD generation, embedding and indexing profiles", async () => {
    // Legacy Generation Profile
    const genPayload = {
      label: "Gen Profile Test",
      provider: "openai",
      modelName: "gpt-4o",
      apiKey: "mock-key",
      temperature: 0.7,
      topP: 0.95,
      maxOutputTokens: 2048,
      maxRecentMessages: 10,
      compressionThreshold: 100
    };
    const createGen = await app.inject({
      method: "POST",
      url: "/api/providers/generation",
      payload: genPayload
    });
    expect(createGen.statusCode).toBe(201);
    const genProfile = JSON.parse(createGen.body);
    createdGenProfileIds.push(genProfile.id);

    // Test Gen Profile Connection
    const testGen = await app.inject({
      method: "POST",
      url: `/api/providers/generation/${genProfile.id}/test`
    });
    expect(testGen.statusCode).toBe(200);
    expect(JSON.parse(testGen.body).success).toBe(true);

    // Embedding Profile
    const embPayload = {
      label: "Emb Profile Test",
      provider: "google",
      modelName: "text-embedding-004",
      apiKey: "mock-key",
      dimensions: 768
    };
    const createEmb = await app.inject({
      method: "POST",
      url: "/api/providers/embedding",
      payload: embPayload
    });
    expect(createEmb.statusCode).toBe(201);
    const embProfile = JSON.parse(createEmb.body);
    createdEmbProfileIds.push(embProfile.id);

    // Indexing Profile
    const idxPayload = {
      label: "Idx Profile Test",
      provider: "google",
      modelName: "gemini-2.0-flash",
      apiKey: "mock-key"
    };
    const createIdx = await app.inject({
      method: "POST",
      url: "/api/providers/indexing",
      payload: idxPayload
    });
    expect(createIdx.statusCode).toBe(201);
    const idxProfile = JSON.parse(createIdx.body);
    createdIdxProfileIds.push(idxProfile.id);

    // Delete all
    await app.inject({ method: "DELETE", url: `/api/providers/generation/${genProfile.id}` });
    await app.inject({ method: "DELETE", url: `/api/providers/embedding/${embProfile.id}` });
    await app.inject({ method: "DELETE", url: `/api/providers/indexing/${idxProfile.id}` });
  });

  // â”€â”€â”€ 8. Workspace Settings and Budgets â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  it("should get and update general workspace settings", async () => {
    // GET Settings
    const getRes = await app.inject({
      method: "GET",
      url: "/api/workspace/settings"
    });
    expect(getRes.statusCode).toBe(200);
    const originalSettings = JSON.parse(getRes.body);

    // PUT Settings
    const updateRes = await app.inject({
      method: "PUT",
      url: "/api/workspace/settings",
      payload: { globalSoftCap: 5000000 }
    });
    expect(updateRes.statusCode).toBe(200);
    expect(JSON.parse(updateRes.body).globalSoftCap).toBe(5000000);

    // Restore Original globalSoftCap
    await app.inject({
      method: "PUT",
      url: "/api/workspace/settings",
      payload: { globalSoftCap: originalSettings.globalSoftCap }
    });
  });

  it("should get, update, and reset workspace budgets", async () => {
    // GET Budget
    const getRes = await app.inject({
      method: "GET",
      url: "/api/workspace/budget"
    });
    expect(getRes.statusCode).toBe(200);
    const body = JSON.parse(getRes.body);
    expect(body).toHaveProperty("globalSoftCap");
    expect(body).toHaveProperty("perProviderBudget");

    // PUT Budget
    const updatePayload = {
      globalSoftCap: 4000000,
      perProviderBudget: {
        openai: {
          softCap: 2000000,
          used: 150000,
          resetPeriod: "monthly"
        }
      }
    };
    const updateRes = await app.inject({
      method: "PUT",
      url: "/api/workspace/budget",
      payload: updatePayload
    });
    expect(updateRes.statusCode).toBe(200);
    const updated = JSON.parse(updateRes.body);
    expect(updated.globalSoftCap).toBe(4000000);
    expect(updated.perProviderBudget.openai.softCap).toBe(2000000);
    expect(updated.perProviderBudget.openai.used).toBe(150000);

    // POST Reset Budget
    const resetRes = await app.inject({
      method: "POST",
      url: "/api/workspace/budget/reset"
    });
    expect(resetRes.statusCode).toBe(200);
    const resetBody = JSON.parse(resetRes.body);
    expect(resetBody.perProviderBudget.openai.used).toBe(0);
  });

  it("should fail validation if workspace database POST payload is incorrect", async () => {
    const res = await app.inject({
      method: "POST",
      url: "/api/workspace/database",
      payload: {}
    });
    expect(res.statusCode).toBe(400); // Validation error
  });

  it("should fail gracefully if workspace databaseUrl is invalid", async () => {
    const res = await app.inject({
      method: "POST",
      url: "/api/workspace/database",
      payload: { databaseUrl: "postgresql://non_existent_user:wrong_password@localhost:5432/non_existent_db" }
    });
    expect(res.statusCode).toBe(400);
    expect(JSON.parse(res.body).success).toBe(false);
  });
});

