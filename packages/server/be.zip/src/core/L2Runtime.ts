import { randomUUID } from "node:crypto";
import { eq, and } from "drizzle-orm";

import { getDb } from "../config/database.js";
import { MemoryBuilder } from "./MemoryBuilder.js";
import {
  agents,
  channels,
  messages,
  modelModules,
} from "../db/schema.js";
import type { EventBroker } from "./EventBroker.js";
import type { AgentProfile } from "../types/agent.types.js";
import type { ChannelMessage } from "../types/message.types.js";
import { AgentSpawnManager } from "./AgentSpawnManager.js";
import type { SubtaskDefinition } from "../types/task.types.js";
import { TokenTracker } from "./TokenTracker.js";
import { LoopArbiter } from "./LoopArbiter.js";

async function getNextSequenceNumber(channelId: string): Promise<number> {
  const db = getDb();
  const lastMessage = await db.query.messages.findFirst({
    where: eq(messages.channelId, channelId),
    orderBy: (table, { desc }) => [desc(table.sequenceNumber)],
  });
  return lastMessage ? lastMessage.sequenceNumber + 1 : 1;
}

export class L2Runtime {
  private memoryBuilder: MemoryBuilder;

  constructor() {
    this.memoryBuilder = new MemoryBuilder();
  }

  async execute(broker: EventBroker, channelId: string, l2Agent: AgentProfile, userMsgContent: string): Promise<void> {
    const db = getDb();

    // 1. Set L2 status to working & thinking
    await db.update(agents).set({ status: "working" }).where(eq(agents.id, l2Agent.id));
    broker.emit("agent:status", { agentId: l2Agent.id, status: "working" });
    broker.emit(
      "agent:thinking",
      { agentId: l2Agent.id, channelId },
      { channelId },
    );

    const contentLower = userMsgContent.toLowerCase();

    // Determine if spawning L3 pairs is requested
    const shouldSpawn =
      contentLower.includes("spawn") ||
      contentLower.includes("dispatch") ||
      contentLower.includes("parallel") ||
      contentLower.includes("subtask") ||
      contentLower.includes("l3") ||
      contentLower.includes("worker") ||
      contentLower.includes("run");

    if (!shouldSpawn) {
      // Direct Coordination Reply
      const chunks = [
        `Hello Operator! I am @${l2Agent.name}, your Level 2 ${l2Agent.title || "Coordinator"}. `,
        `I received your request in this operational channel. `,
        `Operational status is online. If you need me to coordinate subtask executions, please instruct me to 'spawn' or 'dispatch' L3 Workers, and I will spin up parallel Worker-Supervisor pairs immediately.`
      ];

      chunks.forEach((chunk, index) => {
        setTimeout(() => {
          broker.emit("message:stream", { channelId, agentId: l2Agent.id, chunk }, { channelId });
        }, 150 * (index + 1));
      });

      setTimeout(async () => {
        const nextSeq = await getNextSequenceNumber(channelId);
        const l2Msg: ChannelMessage = {
          id: `msg-${Date.now()}-l2-direct`,
          channelId,
          authorId: l2Agent.id,
          authorName: l2Agent.name,
          authorLevel: l2Agent.authorityLevel as any,
          authorType: "agent",
          content: chunks.join(""),
          mentions: [],
          isInternalMonologue: false,
          sequenceNumber: nextSeq,
          timestamp: new Date(),
        };

        await db.insert(messages).values({
          ...l2Msg,
          authorLevel: String(l2Msg.authorLevel),
        });
        broker.emit("message:new", l2Msg, { channelId });

        // Token tracking & Loop check
        const promptTokens = Math.ceil(userMsgContent.length / 4);
        const completionTokens = Math.ceil(l2Msg.content.length / 4);
        const budgetExceeded = await TokenTracker.trackUsage(broker, l2Agent, channelId, l2Agent.modelModuleId, promptTokens, completionTokens);
        if (!budgetExceeded) {
          await LoopArbiter.checkLoop(broker, l2Agent, channelId, l2Msg.content);
        }

        await db.update(agents).set({ status: "idle" }).where(eq(agents.id, l2Agent.id));
        broker.emit("agent:status", { agentId: l2Agent.id, status: "idle" });
      }, 150 * chunks.length + 200);

    } else {
      // L3 Orchestrated Spawning Dispatch Path
      // Step 1: Stream decomposing CoT thoughts
      const cotDecompose = [
        `\n[L2 Coordinator @${l2Agent.name}] Acknowledged L3 spawning instructions. Decomposing operator goal into parallel subtasks...\n`,
        `Formulating subtask definitions:\n`,
        `  - Subtask 1: Parse schema rules and generate data seed file\n`,
        `  - Subtask 2: Standardize stylesheet templates and color layouts (Injecting failure test)\n`,
        `Initializing L3 worker-supervisor dispatch sequences...\n`
      ];

      cotDecompose.forEach((chunk, index) => {
        setTimeout(() => {
          broker.emit("message:stream", { channelId, agentId: l2Agent.id, chunk }, { channelId });
        }, 150 * (index + 1));
      });

      const dispatchDelay = 150 * cotDecompose.length + 300;
      setTimeout(async () => {
        try {
          // Define subtasks
          // Subtask 2 includes "error" to elegantly demonstrate retry / supervisor policy!
          const subtasks: SubtaskDefinition[] = [
            {
              id: "task_seed_001",
              title: "Parse schema rules & seed database",
              instructions: "Read the PostgreSQL Drizzle schema and compile safe auto-seed scripts inside the sandboxed workspace. Verify correct fields.",
              priority: "high"
            },
            {
              id: "task_theme_002",
              title: "Modernize stylesheet color patterns",
              instructions: "Standardize client design CSS variables and harmonic palettes. Simulate an error block on first run to test supervisor feedback retry policy.",
              priority: "medium"
            }
          ];

          // Auto-seed L3 templates if not present to ensure out-of-the-box verification
          const workerTemplateId = "l3-worker-template";
          const supervisorTemplateId = "l3-spv-template";

          broker.emit("message:stream", {
            channelId,
            agentId: l2Agent.id,
            chunk: `\n[L2 Coordinator @${l2Agent.name}] Triggering AgentSpawnManager. Spawning L3 pairs parallel execution loop...\n`
          }, { channelId });

          // Dispatch the agent
          const report = await AgentSpawnManager.dispatchAgent(broker, l2Agent.id, channelId, {
            workerTemplateId,
            supervisorTemplateId,
            subtasks,
            failurePolicy: "retry",
            maxRetries: 2,
          });

          // Compile Merged Report Card
          let reportContent = `
### 📊 [L2 Merged Batch Report Card]
Successfully compiled outcomes from L3 parallel worker-supervisor coordinates:

| Subtask ID | Title | Status | Retries | Verdict |
|---|---|---|---|---|
`;

          report.items.forEach((item) => {
            const statusIcon = item.status === "completed" ? "✅" : "❌";
            reportContent += `| ${item.subtaskId} | ${item.title} | ${statusIcon} ${item.status.toUpperCase()} | ${item.retryCount} | **${item.verdict.toUpperCase()}** |\n`;
          });

          reportContent += `\n\n#### Detailed Subtask Output Logs:\n`;
          report.items.forEach((item) => {
            reportContent += `\n--- \n**Subtask ${item.subtaskId}**: ${item.title}\n* **Worker Output Summary**:\n${item.workerOutput}\n* **Supervisor Evaluation Summary**:\n${item.supervisorEvaluation}\n`;
          });

          broker.emit("message:stream", { channelId, agentId: l2Agent.id, chunk: reportContent }, { channelId });

          const nextSeq = await getNextSequenceNumber(channelId);
          const reportMsg: ChannelMessage = {
            id: `msg-
-${Date.now()}-l2-report`,
            channelId,
            authorId: l2Agent.id,
            authorName: l2Agent.name,
            authorLevel: l2Agent.authorityLevel as any,
            authorType: "agent",
            content: reportContent,
            mentions: [],
            isInternalMonologue: false,
            sequenceNumber: nextSeq,
            timestamp: new Date(),
          };

          await db.insert(messages).values({
            ...reportMsg,
            authorLevel: String(reportMsg.authorLevel),
          });
          broker.emit("message:new", reportMsg, { channelId });

          // Token tracking & Loop check
          const promptTokens = Math.ceil(userMsgContent.length / 4);
          const completionTokens = Math.ceil(reportMsg.content.length / 4);
          const budgetExceeded = await TokenTracker.trackUsage(broker, l2Agent, channelId, l2Agent.modelModuleId, promptTokens, completionTokens);
          if (!budgetExceeded) {
            await LoopArbiter.checkLoop(broker, l2Agent, channelId, reportMsg.content);
          }

          await db.update(agents).set({ status: "idle" }).where(eq(agents.id, l2Agent.id));
          broker.emit("agent:status", { agentId: l2Agent.id, status: "idle" });

        } catch (err: any) {
          console.error("[L2Runtime] Dispatch failed:", err);
          const errorMsg = `\n[L2 Coordinator @${l2Agent.name}] Execution error during L3 spawning coordinate: ${err.message || String(err)}`;
          broker.emit("message:stream", { channelId, agentId: l2Agent.id, chunk: errorMsg }, { channelId });

          const nextSeq = await getNextSequenceNumber(channelId);
          const errorMsgObj: ChannelMessage = {
            id: `msg-${Date.now()}-l2-error`,
            channelId,
            authorId: l2Agent.id,
            authorName: l2Agent.name,
            authorLevel: l2Agent.authorityLevel as any,
            authorType: "agent",
            content: errorMsg,
            mentions: [],
            isInternalMonologue: false,
            sequenceNumber: nextSeq,
            timestamp: new Date(),
          };

          await db.insert(messages).values({
            ...errorMsgObj,
            authorLevel: String(errorMsgObj.authorLevel),
          });
          broker.emit("message:new", errorMsgObj, { channelId });

          await db.update(agents).set({ status: "idle" }).where(eq(agents.id, l2Agent.id));
          broker.emit("agent:status", { agentId: l2Agent.id, status: "idle" });
        }
      }, dispatchDelay);
    }
  }
}
