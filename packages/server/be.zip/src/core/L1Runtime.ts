import { randomUUID } from "node:crypto";
import { eq, and, inArray } from "drizzle-orm";

import { getDb } from "../config/database.js";
import { MemoryBuilder } from "./MemoryBuilder.js";
import {
  agents,
  channels,
  categories,
  messages,
  modelModules,
  instructionModules,
  toolkitModules,
} from "../db/schema.js";
import type { EventBroker } from "./EventBroker.js";
import type { AgentProfile } from "../types/agent.types.js";
import type { ChannelMessage } from "../types/message.types.js";
import { TokenTracker } from "./TokenTracker.js";
import { LoopArbiter } from "./LoopArbiter.js";
import { compileGoogleEndpoint, isGemmaModel, parseGemmaThoughts } from "./modelRouter.js";

async function getNextSequenceNumber(channelId: string): Promise<number> {
  const db = getDb();
  const lastMessage = await db.query.messages.findFirst({
    where: eq(messages.channelId, channelId),
    orderBy: (table, { desc }) => [desc(table.sequenceNumber)],
  });
  return lastMessage ? lastMessage.sequenceNumber + 1 : 1;
}

export class L1Runtime {
  private memoryBuilder: MemoryBuilder;

  constructor() {
    this.memoryBuilder = new MemoryBuilder();
  }

  async execute(broker: EventBroker, channelId: string, l1Agent: AgentProfile, userMsgContent: string): Promise<void> {
    const db = getDb();

    // 1. Set L1 status to working & thinking
    await db.update(agents).set({ status: "working" }).where(eq(agents.id, l1Agent.id));
    broker.emit("agent:status", { agentId: l1Agent.id, status: "working" });
    broker.emit(
      "agent:thinking",
      { agentId: l1Agent.id, channelId },
      { channelId },
    );

    // 2. Fetch L1's ModelModule
    const modelModule = await db.query.modelModules.findFirst({
      where: eq(modelModules.id, l1Agent.modelModuleId),
    });

    const apiKey = modelModule?.apiKey;
    const provider = modelModule?.provider;
    const modelName = modelModule?.modelName;

    // Check if it's a real API call or if we use mock fallback
    const isMock = !apiKey || apiKey === "mock-key" || apiKey === "test-key" || apiKey.startsWith("mock-");

    // Auto-seed L2 specialists if none exist, ensuring seamless out-of-the-box verification
    await this.ensureL2SpecialistsSeeded(l1Agent);

    if (isMock) {
      await this.executeMockBipolar(broker, channelId, l1Agent, userMsgContent);
    } else {
      await this.executeRealBipolar(broker, channelId, l1Agent, userMsgContent, modelModule);
    }
  }

  private async ensureL2SpecialistsSeeded(l1Agent: AgentProfile): Promise<void> {
    const db = getDb();
    const l2Agents = await db.query.agents.findMany({
      where: and(eq(agents.authorityLevel, 2), eq(agents.isTemplate, false)),
    });

    if (l2Agents.length === 0) {
      console.log("[L1Runtime] Auto-seeding L2 specialists for dynamic verification...");
      // Fetch model/instruction/toolkit of L1 to use as references
      const modelModuleId = l1Agent.modelModuleId;
      const instructionModuleId = l1Agent.instructionModuleId;
      const toolkitModuleId = l1Agent.toolkitModuleId || null;

      // Seed DB Expert
      await db.insert(agents).values({
        id: "agent-l2-db-expert",
        name: "Architect_Raven",
        title: "Database Architect",
        species: "Raven",
        authorityLevel: 2,
        modelModuleId,
        instructionModuleId,
        toolkitModuleId,
        memorySharingPolicy: "none",
        isOmniscient: false,
        status: "idle",
        isTemplate: false,
        permissions: { spawnAgents: false, patchRuntime: false, accessAllChannels: false },
        createdAt: new Date(),
        updatedAt: new Date(),
      });

      // Seed UI Expert
      await db.insert(agents).values({
        id: "agent-l2-ui-expert",
        name: "Designer_Falcon",
        title: "Interface Designer",
        species: "Falcon",
        authorityLevel: 2,
        modelModuleId,
        instructionModuleId,
        toolkitModuleId,
        memorySharingPolicy: "none",
        isOmniscient: false,
        status: "idle",
        isTemplate: false,
        permissions: { spawnAgents: false, patchRuntime: false, accessAllChannels: false },
        createdAt: new Date(),
        updatedAt: new Date(),
      });
      console.log("[L1Runtime] Auto-seeded L2 specialist agents: @Architect_Raven and @Designer_Falcon");
    }
  }

  private async executeMockBipolar(broker: EventBroker, channelId: string, l1Agent: AgentProfile, userMsgContent: string): Promise<void> {
    const contentLower = userMsgContent.toLowerCase();

    // Determine if the request requires routing/dispatch
    const isComplex =
      contentLower.includes("refactor") ||
      contentLower.includes("database") ||
      contentLower.includes("ui") ||
      contentLower.includes("build") ||
      contentLower.includes("dispatch") ||
      contentLower.includes("setup") ||
      contentLower.includes("create") ||
      userMsgContent.split(" ").length > 4;

    if (!isComplex) {
      // Direct Response Path
      const chunks = [
        `Hello Operator! I am @${l1Agent.name}, your L1 Executive Coordinator. `,
        `I received your message. Since this is a simple request, `,
        `I can directly confirm that our CrowdOS workspaces, categories, and channels tree are fully online and synchronized.`
      ];

      chunks.forEach((chunk, index) => {
        setTimeout(() => {
          broker.emit("message:stream", { channelId, agentId: l1Agent.id, chunk }, { channelId });
        }, 150 * (index + 1));
      });

      setTimeout(async () => {
        const nextSeq = await getNextSequenceNumber(channelId);
        const l1Msg: ChannelMessage = {
          id: `msg-${Date.now()}-l1-direct`,
          channelId,
          authorId: l1Agent.id,
          authorName: l1Agent.name,
          authorLevel: l1Agent.authorityLevel as any,
          authorType: "agent",
          content: chunks.join(""),
          mentions: [],
          isInternalMonologue: false,
          sequenceNumber: nextSeq,
          timestamp: new Date(),
        };

        const db = getDb();
        await db.insert(messages).values({
          ...l1Msg,
          authorLevel: String(l1Msg.authorLevel),
        });
        broker.emit("message:new", l1Msg, { channelId });

        // Token tracking
        const promptTokens = Math.ceil(userMsgContent.length / 4);
        const completionTokens = Math.ceil(l1Msg.content.length / 4);
        const budgetExceeded = await TokenTracker.trackUsage(broker, l1Agent, channelId, l1Agent.modelModuleId, promptTokens, completionTokens);
        if (!budgetExceeded) {
          // Loop arbitration check
          await LoopArbiter.checkLoop(broker, l1Agent, channelId, l1Msg.content);
        }

        await db.update(agents).set({ status: "idle" }).where(eq(agents.id, l1Agent.id));
        broker.emit("agent:status", { agentId: l1Agent.id, status: "idle" });
      }, 150 * chunks.length + 200);

    } else {
      // Bipolar Consciousness Dispatch Path
      // Step 1: Kesadaran 1 (Task Decomposer) Streams CoT thoughts
      const cotDecompose = [
        `\\n[Kesadaran 1: Task Decomposer] Received operator request: "\${userMsgContent}"\\n`,
        `Decomposing request into specialized, decoupled subtasks:\\n`,
        `  - Subtask 1: Refactor database layers & verify PostgreSQL pools\\n`,
        `  - Subtask 2: Modernize frontend stylesheet layouts & layout grids\\n`
      ];

      cotDecompose.forEach((chunk, index) => {
        setTimeout(() => {
          broker.emit("message:stream", { channelId, agentId: l1Agent.id, chunk }, { channelId });
        }, 150 * (index + 1));
      });

      // Step 2: Kesadaran 2 (Technical Orchestrator) scans and dispatches
      const orchestratorDelay = 150 * cotDecompose.length + 300;
      setTimeout(async () => {
        broker.emit("message:stream", {
          channelId,
          agentId: l1Agent.id,
          chunk: `\\n[Kesadaran 2: Technical Orchestrator] Accessing Agent Registry & mapping specialities...\\n`
        }, { channelId });

        const db = getDb();
        const allAgents = await db.query.agents.findMany({
          where: eq(agents.isTemplate, false),
        });

        // Resolve specialist agents
        const dbAgent = allAgents.find(a => a.name.includes("Raven") || a.name.includes("Architect")) || allAgents[0];
        const uiAgent = allAgents.find(a => a.name.includes("Falcon") || a.name.includes("Designer")) || allAgents[0];

        // Create category and channels dynamically
        const categoryId = `cat-dis-${Date.now()}`;
        await db.insert(categories).values({
          id: categoryId,
          name: "PROJECT DISPATCH",
          ownedByAgentId: l1Agent.id,
          embeddingProfileId: null,
          createdBy: "system",
          position: 10,
          createdAt: new Date(),
        });

        const ch1Id = `ch-db-${Date.now()}`;
        const ch2Id = `ch-ui-${Date.now()}`;

        await db.insert(channels).values({
          id: ch1Id,
          categoryId,
          name: "refactor-db",
          type: "standard",
          createdBy: "system",
          position: 1,
          createdAt: new Date(),
        });

        await db.insert(channels).values({
          id: ch2Id,
          categoryId,
          name: "ui-overhaul",
          type: "standard",
          createdBy: "system",
          position: 2,
          createdAt: new Date(),
        });

        // Trigger workspaces refresh
        broker.emit("workspace:sync", {}, { channelId });

        // Trigger L2 replies and greetings inside new channels
        setTimeout(async () => {
          await this.triggerL2Welcome(broker, ch1Id, dbAgent, "Refactor database layers & verify PostgreSQL pools");
          await this.triggerL2Welcome(broker, ch2Id, uiAgent, "Modernize frontend stylesheet layouts & layout grids");
        }, 500);

        // Compile and send L1 Merge Report Card
        setTimeout(async () => {
          const reportContent = `
[Kesadaran 1 & 2 Merge Report Card]
I have successfully decomposed your task and dispatched specialist L2 agents to target workspaces:
* **Subtask 1 (Database Refactor)**: Routed to @\${dbAgent.name} in #refactor-db.
* **Subtask 2 (UI Overhaul)**: Routed to @\${uiAgent.name} in #ui-overhaul.

Please review the progress in their respective channels. Operations channels have been synchronized.
`;
          broker.emit("message:stream", { channelId, agentId: l1Agent.id, chunk: reportContent }, { channelId });

          const nextSeq = await getNextSequenceNumber(channelId);
          const reportMsg: ChannelMessage = {
            id: `msg-${Date.now()}-l1-report`,
            channelId,
            authorId: l1Agent.id,
            authorName: l1Agent.name,
            authorLevel: l1Agent.authorityLevel as any,
            authorType: "agent",
            content: reportContent,
            mentions: [],
            isInternalMonologue: false,
            sequenceNumber: nextSeq,
            timestamp: new Date(),
          };

          await db.insert(messages).values({
            ...reportMsg,
            authorLevel: String(reportMsg.authorLevel),
          });
          broker.emit("message:new", reportMsg, { channelId });

          // Token tracking
          const promptTokens = Math.ceil(userMsgContent.length / 4);
          const completionTokens = Math.ceil(reportMsg.content.length / 4);
          const budgetExceeded = await TokenTracker.trackUsage(broker, l1Agent, channelId, l1Agent.modelModuleId, promptTokens, completionTokens);
          if (!budgetExceeded) {
            // Loop arbitration check
            await LoopArbiter.checkLoop(broker, l1Agent, channelId, reportMsg.content);
          }

          await db.update(agents).set({ status: "idle" }).where(eq(agents.id, l1Agent.id));
          broker.emit("agent:status", { agentId: l1Agent.id, status: "idle" });
        }, 1000);

      }, orchestratorDelay);
    }
  }

  private async triggerL2Welcome(broker: EventBroker, channelId: string, agent: any, taskDesc: string): Promise<void> {
    const db = getDb();
    
    // Set L2 status to thinking
    await db.update(agents).set({ status: "working" }).where(eq(agents.id, agent.id));
    broker.emit("agent:status", { agentId: agent.id, status: "working" });
    broker.emit("agent:thinking", { agentId: agent.id, channelId }, { channelId });

    setTimeout(async () => {
      const welcomeContent = `Hello! I am @${agent.name}, your Level 2 Coordinator. I have been assigned to coordinate this workspace target: **${taskDesc}**. Active state online.`;
      
      const nextSeq = await getNextSequenceNumber(channelId);
      const l2Welcome: ChannelMessage = {
        id: `msg-${Date.now()}-l2-welcome-${agent.id}`,
        channelId,
        authorId: agent.id,
        authorName: agent.name,
        authorLevel: agent.authorityLevel as any,
        authorType: "agent",
        content: welcomeContent,
        mentions: [],
        isInternalMonologue: false,
        sequenceNumber: nextSeq,
        timestamp: new Date(),
      };

      await db.insert(messages).values({
        ...l2Welcome,
        authorLevel: String(l2Welcome.authorLevel),
      });
      broker.emit("message:new", l2Welcome, { channelId });

      await db.update(agents).set({ status: "idle" }).where(eq(agents.id, agent.id));
      broker.emit("agent:status", { agentId: agent.id, status: "idle" });
    }, 1200);
  }

  private async executeRealBipolar(
    broker: EventBroker,
    channelId: string,
    l1Agent: AgentProfile,
    userMsgContent: string,
    modelModule: any
  ): Promise<void> {
    try {
      console.log(`[L1Runtime] Launching real LLM call via provider ${modelModule.provider}...`);
      const builderResult = await this.memoryBuilder.buildPrompt({
        agentId: l1Agent.id,
        channelId,
        currentMessage: userMsgContent,
      });

      if (modelModule.provider === "google") {
        const modelName = modelModule.modelName || "gemini-2.0-flash";
        const { url, headers, bodyBuilder } = compileGoogleEndpoint(modelModule);

        const response = await fetch(url, {
          method: "POST",
          headers,
          body: JSON.stringify(bodyBuilder(builderResult.systemPrompt, builderResult.userPrompt)),
        });

        if (response.ok) {
          const json = await response.json();
          const textResponse = json.candidates?.[0]?.content?.parts?.[0]?.text || "";
          
          if (textResponse) {
            let parsedText = textResponse;
            let thoughts = "";

            if (isGemmaModel(modelName)) {
              const parsed = parseGemmaThoughts(textResponse);
              thoughts = parsed.thoughts;
              parsedText = parsed.answer;
            }

            const db = getDb();
            let nextSeq = await getNextSequenceNumber(channelId);

            // If thoughts were parsed from Gemma 4 reasoning channel delimiters, save them as internal monologue first
            if (thoughts) {
              const thoughtsMsg: ChannelMessage = {
                id: `msg-${Date.now()}-l1-thoughts`,
                channelId,
                authorId: l1Agent.id,
                authorName: l1Agent.name,
                authorLevel: l1Agent.authorityLevel as any,
                authorType: "agent",
                content: thoughts,
                mentions: [],
                isInternalMonologue: true,
                sequenceNumber: nextSeq,
                timestamp: new Date(),
              };
              await db.insert(messages).values({
                ...thoughtsMsg,
                authorLevel: String(thoughtsMsg.authorLevel),
              });
              broker.emit("message:new", thoughtsMsg, { channelId });
              nextSeq += 1;
            }

            // Stream and save the clean final answer
            broker.emit("message:stream", { channelId, agentId: l1Agent.id, chunk: parsedText }, { channelId });
            
            const l1Msg: ChannelMessage = {
              id: `msg-${Date.now()}-l1-real`,
              channelId,
              authorId: l1Agent.id,
              authorName: l1Agent.name,
              authorLevel: l1Agent.authorityLevel as any,
              authorType: "agent",
              content: parsedText,
              mentions: [],
              isInternalMonologue: false,
              sequenceNumber: nextSeq,
              timestamp: new Date(),
            };

            await db.insert(messages).values({
              ...l1Msg,
              authorLevel: String(l1Msg.authorLevel),
            });
            broker.emit("message:new", l1Msg, { channelId });

            // Token tracking
            const promptTokens = Math.ceil((builderResult.systemPrompt.length + builderResult.userPrompt.length) / 4);
            const completionTokens = Math.ceil(textResponse.length / 4);
            const budgetExceeded = await TokenTracker.trackUsage(broker, l1Agent, channelId, l1Agent.modelModuleId, promptTokens, completionTokens);
            if (!budgetExceeded) {
              // Loop arbitration check
              await LoopArbiter.checkLoop(broker, l1Agent, channelId, parsedText);
            }

            await db.update(agents).set({ status: "idle" }).where(eq(agents.id, l1Agent.id));
            broker.emit("agent:status", { agentId: l1Agent.id, status: "idle" });
            return;
          }
        }
      }
      
      console.warn("[L1Runtime] Provider not Google or API error. Falling back to Mock Bipolar executor.");
      await this.executeMockBipolar(broker, channelId, l1Agent, userMsgContent);

    } catch (err) {
      console.error("[L1Runtime] Real LLM execution error:", err);
      await this.executeMockBipolar(broker, channelId, l1Agent, userMsgContent);
    }
  }
}
