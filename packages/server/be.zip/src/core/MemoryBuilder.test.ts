﻿import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { getDb, closeDatabaseConnection } from "../config/database.js";
import { MemoryBuilder } from "./MemoryBuilder.js";
import { formatMessageForAgent } from "./PromptFormatter.js";
import {
  modelModules,
  instructionModules,
  toolkitModules,
  tools,
  agents,
  categories,
  channels,
  messages,
  taskFiles,
  runtimeOverrides,
  compressedSummaries,
  spawnRequests
} from "../db/schema.js";
import { eq, inArray } from "drizzle-orm";

describe("MemoryBuilder and Prompt Assembly Integration Tests", () => {
  const db = getDb();
  const builder = new MemoryBuilder();

  // Temporary IDs to clean up
  const tempModelId = randomUUID();
  const tempInstructionId = randomUUID();
  const tempToolkitId = randomUUID();
  const tempToolId = randomUUID();

  const l1AgentId = randomUUID();
  const l2AgentId = randomUUID();
  const l3WorkerId = randomUUID();
  const l3SupervisorId = randomUUID();

  const categoryId = randomUUID();
  const standardChannelId = randomUUID();
  const privateChannelId = randomUUID();

  const spawnRequestId = randomUUID();
  const taskFileId = randomUUID();
  const overrideId = randomUUID();

  beforeAll(async () => {
    // 1. Create a model module
    await db.insert(modelModules).values({
      id: tempModelId,
      label: "Test Model",
      provider: "google",
      modelName: "gemini-2.0-flash",
      temperature: 0.5,
      topP: 0.9,
      maxOutputTokens: 1024,
      stopSequences: ["\n\n"],
      maxRecentMessages: 3,
      enableCompression: true,
      compressionThreshold: 5,
    });

    // 2. Create instruction module
    await db.insert(instructionModules).values({
      id: tempInstructionId,
      label: "Test Instructions",
      base: ["System base prompt instructions."],
      runtimePatchable: true,
    });

    // 3. Create tool definition
    await db.insert(tools).values({
      id: tempToolId,
      name: "run_code",
      description: "Execute Javascript sandbox",
      handlerId: "run_code_handler",
      jsonSchema: { type: "object", properties: { code: { type: "string" } } },
      dangerLevel: "low",
      authLevelRequired: 3,
    });

    // 4. Create toolkit module
    await db.insert(toolkitModules).values({
      id: tempToolkitId,
      label: "Test Toolkit",
      tools: [tempToolId],
    });

    // 5. Create L1, L2, L3 Agents
    await db.insert(agents).values({
      id: l1AgentId,
      name: "l1-ceo",
      title: "L1 CEO",
      authorityLevel: 1,
      modelModuleId: tempModelId,
      instructionModuleId: tempInstructionId,
      toolkitModuleId: tempToolkitId,
      memorySharingPolicy: "full",
      isTemplate: false,
    });

    await db.insert(agents).values({
      id: l2AgentId,
      name: "l2-manager",
      title: "L2 Manager",
      authorityLevel: 2,
      modelModuleId: tempModelId,
      instructionModuleId: tempInstructionId,
      toolkitModuleId: tempToolkitId,
      memorySharingPolicy: "vertical",
      isTemplate: false,
    });

    await db.insert(agents).values({
      id: l3WorkerId,
      name: "l3-worker",
      title: "L3 Worker",
      authorityLevel: 3,
      l3Subtype: "worker",
      modelModuleId: tempModelId,
      instructionModuleId: tempInstructionId,
      toolkitModuleId: tempToolkitId,
      memorySharingPolicy: "none",
      isTemplate: false,
    });

    await db.insert(agents).values({
      id: l3SupervisorId,
      name: "l3-supervisor",
      title: "L3 Supervisor",
      authorityLevel: 3,
      l3Subtype: "supervisor",
      modelModuleId: tempModelId,
      instructionModuleId: tempInstructionId,
      toolkitModuleId: tempToolkitId,
      memorySharingPolicy: "none",
      isTemplate: false,
    });

    // 6. Create Categories and Channels
    await db.insert(categories).values({
      id: categoryId,
      name: "Test Category",
      createdBy: "test",
      position: 0,
    });

    await db.insert(channels).values({
      id: standardChannelId,
      categoryId: categoryId,
      name: "general-debug",
      type: "standard",
      createdBy: "test",
      position: 0,
    });

    await db.insert(channels).values({
      id: privateChannelId,
      categoryId: categoryId,
      name: "worker-private",
      type: "pair_private",
      createdBy: "test",
      position: 1,
    });

    // 6.5 Create Spawn Request (FK requirement for task file)
    await db.insert(spawnRequests).values({
      id: spawnRequestId,
      requestedBy: l1AgentId,
      channelId: standardChannelId,
      workerTemplateId: l3WorkerId,
      supervisorTemplateId: l3SupervisorId,
      failurePolicy: "retry",
      maxRetries: 3,
      status: "pending",
    });

    // 7. Create Task File for L3 Workers
    await db.insert(taskFiles).values({
      id: taskFileId,
      spawnRequestId: spawnRequestId,
      subtaskId: "subtask-1",
      title: "Task Title A",
      content: "Complete unit tests for MemoryBuilder pipeline.",
      workerAgentId: l3WorkerId,
      supervisorAgentId: l3SupervisorId,
      status: "pending",
    });
  });

  afterAll(async () => {
    // 1. Clean up task files and spawn requests and overrides
    await db.delete(taskFiles).where(eq(taskFiles.id, taskFileId));
    await db.delete(spawnRequests).where(eq(spawnRequests.id, spawnRequestId));
    await db.delete(runtimeOverrides).where(eq(runtimeOverrides.id, overrideId));
    
    // 2. Clean up messages and compressed summaries
    await db.delete(messages).where(
      inArray(messages.channelId, [standardChannelId, privateChannelId])
    );
    await db.delete(compressedSummaries).where(
      inArray(compressedSummaries.channelId, [standardChannelId, privateChannelId])
    );

    // 3. Clean up channels and category
    await db.delete(channels).where(
      inArray(channels.id, [standardChannelId, privateChannelId])
    );
    await db.delete(categories).where(eq(categories.id, categoryId));

    // 4. Clean up agents
    await db.delete(agents).where(
      inArray(agents.id, [l1AgentId, l2AgentId, l3WorkerId, l3SupervisorId])
    );

    // 5. Clean up modules and tools
    await db.delete(toolkitModules).where(eq(toolkitModules.id, tempToolkitId));
    await db.delete(tools).where(eq(tools.id, tempToolId));
    await db.delete(instructionModules).where(eq(instructionModules.id, tempInstructionId));
    await db.delete(modelModules).where(eq(modelModules.id, tempModelId));

    await closeDatabaseConnection();
  });

  describe("PromptFormatter Unit Tests", () => {
    it("should format normal messages into XML structure", () => {
      const msg = {
        authorName: "l1-ceo",
        authorLevel: 1,
        content: "Draft the execution blueprint.",
      };
      const formatted = formatMessageForAgent(msg);
      expect(formatted).toBe(
        `<message from="l1-ceo" level="1">\nDraft the execution blueprint.\n</message>`
      );
    });

    it("should escape special XML characters inside attributes", () => {
      const msg = {
        authorName: 'Agent "Special" & Co.',
        authorLevel: "L2 Manager",
        content: "Safe check.",
      };
      const formatted = formatMessageForAgent(msg);
      expect(formatted).toBe(
        `<message from="Agent &quot;Special&quot; &amp; Co." level="L2 Manager">\nSafe check.\n</message>`
      );
    });

    it("should inject mention and flag attributes if recipient matches mention targets", () => {
      const msg = {
        authorName: "l1-ceo",
        authorLevel: 1,
        content: "Please help, @l2-manager!",
        mentions: [
          {
            type: "agent" as const,
            targetId: l2AgentId,
            targetName: "@l2-manager",
            position: 13,
            flag: "attention_boost" as const,
          },
        ],
      };
      
      const formatted = formatMessageForAgent(msg, "l2-manager");
      expect(formatted).toBe(
        `<message from="l1-ceo" level="1" mention="@l2-manager" flag="attention_boost">\nPlease help, @l2-manager!\n</message>`
      );
    });
  });

  describe("MemoryBuilder Prompt Assembly Pipeline Tests", () => {
    it("should assemble a complete L1 CEO prompt with correct order", async () => {
      // Seed a user message
      await db.insert(messages).values({
        id: randomUUID(),
        channelId: standardChannelId,
        authorId: "user-id",
        authorName: "Stakeholder",
        authorLevel: "stakeholder",
        authorType: "user",
        content: "Fix the budget breakdown.",
        sequenceNumber: 1,
      });

      const result = await builder.buildPrompt({
        agentId: l1AgentId,
        channelId: standardChannelId,
        currentMessage: "L1 responding to user request.",
      });

      expect(result.systemPrompt).toContain("System base prompt instructions.");
      expect(result.userPrompt).toContain("Kamu adalah Level 1 CEO Agent.");
      expect(result.userPrompt).toContain("run_code");
      expect(result.userPrompt).toContain("Fix the budget breakdown.");
      expect(result.userPrompt).toContain("L1 responding to user request.");
      expect(result.modelParameters.temperature).toBe(0.5);
    });

    it("should apply active runtime overrides to system prompts", async () => {
      await db.insert(runtimeOverrides).values({
        id: overrideId,
        targetAgentId: l1AgentId,
        overrideType: "runtime_patch",
        instructionPatch: {
          append: ["Override instructions appended."],
          replace: ["Overridden base instruction."],
        },
        createdBy: "user",
      });

      const result = await builder.buildPrompt({
        agentId: l1AgentId,
        channelId: standardChannelId,
      });

      expect(result.systemPrompt).toContain("Overridden base instruction.");
      expect(result.systemPrompt).toContain("[RUNTIME OVERRIDE PATCH]");
      expect(result.systemPrompt).toContain("Override instructions appended.");
    });

    it("should restrict Shared Memory contents using the Visibility Matrix", async () => {
      // Clear previous messages
      await db.delete(messages).where(eq(messages.channelId, standardChannelId));

      // L2 has vertical visibility (can see level 1 and 3, not other level 2 or users unless mentioned)
      await db.insert(messages).values([
        {
          id: randomUUID(),
          channelId: standardChannelId,
          authorId: "user-1",
          authorName: "User",
          authorLevel: "stakeholder",
          authorType: "user" as const,
          content: "Hello User",
          sequenceNumber: 1,
        },
        {
          id: randomUUID(),
          channelId: standardChannelId,
          authorId: l1AgentId,
          authorName: "l1-ceo",
          authorLevel: "1",
          authorType: "agent" as const,
          content: "Delegating task to manager.",
          sequenceNumber: 2,
        },
        {
          id: randomUUID(),
          channelId: standardChannelId,
          authorId: "l2-other",
          authorName: "l2-peer",
          authorLevel: "2",
          authorType: "agent" as const,
          content: "Peer manager chatter.",
          sequenceNumber: 3,
        },
      ]);

      const result = await builder.buildPrompt({
        agentId: l2AgentId,
        channelId: standardChannelId,
      });

      // Under vertical sharing policy:
      // - CEO message (level 1) is visible to L2 (level 2) -> included!
      // - User message is visible to L2 -> included!
      // - L2 Peer chatter (level 2) is NOT visible to L2 Manager (vertical only) -> excluded!
      expect(result.userPrompt).toContain("Delegating task to manager.");
      expect(result.userPrompt).toContain("Hello User");
      expect(result.userPrompt).not.toContain("Peer manager chatter.");
    });

    it("should inject Pinned Task File details for L3 worker/supervisor", async () => {
      const resultWorker = await builder.buildPrompt({
        agentId: l3WorkerId,
        channelId: privateChannelId,
      });

      expect(resultWorker.userPrompt).toContain("Task Title A");
      expect(resultWorker.userPrompt).toContain("Complete unit tests for MemoryBuilder pipeline.");
      expect(resultWorker.userPrompt).toContain("Kamu adalah Level 3 Worker.");

      const resultSupervisor = await builder.buildPrompt({
        agentId: l3SupervisorId,
        channelId: privateChannelId,
      });

      expect(resultSupervisor.userPrompt).toContain("Task Title A");
      expect(resultSupervisor.userPrompt).toContain("Complete unit tests for MemoryBuilder pipeline.");
      expect(resultSupervisor.userPrompt).toContain("Kamu adalah Level 3 Supervisor.");
    });

    it("should compress and cache history using summaries when total count exceeds threshold", async () => {
      // Clear previous messages
      await db.delete(messages).where(eq(messages.channelId, standardChannelId));
      await db.delete(compressedSummaries).where(eq(compressedSummaries.channelId, standardChannelId));

      // Model configuration: threshold = 5, maxRecent = 3
      // Insert 6 messages
      const msgs = Array.from({ length: 6 }).map((_, idx) => ({
        id: randomUUID(),
        channelId: standardChannelId,
        authorId: l1AgentId,
        authorName: "l1-ceo",
        authorLevel: "1",
        authorType: "agent" as const,
        content: `Message step ${idx + 1}`,
        sequenceNumber: idx + 1,
      }));

      await db.insert(messages).values(msgs);

      // Verify prompt assembly triggering compression caching
      const mockSummarizer = async (messages: any[], prevSummary?: string) => {
        return `Mock summary up to ${messages[messages.length - 1].sequenceNumber}. Previous: ${prevSummary ?? "none"}`;
      };

      const result = await builder.buildPrompt({
        agentId: l1AgentId,
        channelId: standardChannelId,
        summarizer: mockSummarizer,
      });

      // Total messages is 6 (which exceeds threshold 5)
      // Compression target: total (6) - maxRecent (3) = 3 messages.
      // So messages up to sequence number 3 should be compressed.
      expect(result.userPrompt).toContain("Mock summary up to 3. Previous: none");
      expect(result.userPrompt).toContain("Message step 4");
      expect(result.userPrompt).toContain("Message step 5");
      expect(result.userPrompt).toContain("Message step 6");
      expect(result.userPrompt).not.toContain("Message step 1");

      // Verify that summary is cached in DB
      const dbSummary = await db.query.compressedSummaries.findFirst({
        where: eq(compressedSummaries.channelId, standardChannelId),
      });

      expect(dbSummary).toBeDefined();
      expect(dbSummary!.coversUpToSeq).toBe(3);
      expect(dbSummary!.summary).toContain("Mock summary up to 3");
    });

    it("should execute custom tokenCounter hook and return correct token counts in results", async () => {
      let customCounterCalled = false;
      const customCounter = (text: string) => {
        customCounterCalled = true;
        return text.split(/\s+/).filter(Boolean).length;
      };

      const result = await builder.buildPrompt({
        agentId: l1AgentId,
        channelId: standardChannelId,
        currentMessage: "Test custom token counter hook.",
        tokenCounter: customCounter,
      });

      expect(customCounterCalled).toBe(true);
      expect(result.estimatedTokens).toBeDefined();
      expect(result.estimatedTokens.systemPromptTokens).toBeGreaterThan(0);
      expect(result.estimatedTokens.userPromptTokens).toBeGreaterThan(0);
      expect(result.estimatedTokens.totalTokens).toBe(
        result.estimatedTokens.systemPromptTokens + result.estimatedTokens.userPromptTokens
      );
    });

    it("should fallback to default character-based token estimator if custom hook is not provided", async () => {
      const result = await builder.buildPrompt({
        agentId: l1AgentId,
        channelId: standardChannelId,
        currentMessage: "Test default estimator.",
      });

      expect(result.estimatedTokens).toBeDefined();
      expect(result.estimatedTokens.systemPromptTokens).toBe(Math.ceil(result.systemPrompt.length / 4));
      expect(result.estimatedTokens.userPromptTokens).toBe(Math.ceil(result.userPrompt.length / 4));
      expect(result.estimatedTokens.totalTokens).toBe(
        result.estimatedTokens.systemPromptTokens + result.estimatedTokens.userPromptTokens
      );
    });
  });
});
