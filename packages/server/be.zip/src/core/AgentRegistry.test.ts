import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { getDb, closeDatabaseConnection } from "../config/database.js";
import { AgentRegistry } from "./AgentRegistry.js";
import { modelModules, instructionModules, agents } from "../db/schema.js";
import { eq } from "drizzle-orm";

describe("AgentRegistry Integration Tests", () => {
  const db = getDb();
  const registry = new AgentRegistry();

  const tempModelModuleId = randomUUID();
  const tempInstructionModuleId = randomUUID();
  let createdAgentId: string;

  beforeAll(async () => {
    // 1. Create a temporary model module
    await db.insert(modelModules).values({
      id: tempModelModuleId,
      label: "Test Model Module",
      provider: "google",
      modelName: "gemini-2.0-flash",
      temperature: 0.7,
      topP: 0.95,
      maxOutputTokens: 2048,
      maxRecentMessages: 10,
      compressionThreshold: 50,
    });

    // 2. Create a temporary instruction module
    await db.insert(instructionModules).values({
      id: tempInstructionModuleId,
      label: "Test Instruction Module",
      base: ["Test instruction 1"],
      runtimePatchable: true,
    });
  });

  afterAll(async () => {
    // Clean up created agents
    if (createdAgentId) {
      await db.delete(agents).where(eq(agents.id, createdAgentId));
    }
    // Clean up temporary modules
    await db.delete(modelModules).where(eq(modelModules.id, tempModelModuleId));
    await db.delete(instructionModules).where(eq(instructionModules.id, tempInstructionModuleId));

    // Close db connection to let Vitest finish nicely
    await closeDatabaseConnection();
  });

  it("should create a new agent profile", async () => {
    const newAgent = await registry.create({
      name: "test-agent",
      title: "Test Agent",
      species: "Test Species",
      authorityLevel: 2,
      modelModuleId: tempModelModuleId,
      instructionModuleId: tempInstructionModuleId,
      memorySharingPolicy: "none",
      status: "idle",
      isTemplate: false,
      permissions: {
        spawnAgents: false,
        patchRuntime: false,
        accessAllChannels: false,
      },
    });

    expect(newAgent).toBeDefined();
    expect(newAgent.id).toBeDefined();
    createdAgentId = newAgent.id;
    expect(newAgent.name).toBe("test-agent");
    expect(newAgent.title).toBe("Test Agent");
    expect(newAgent.species).toBe("Test Species");
    expect(newAgent.authorityLevel).toBe(2);
    expect(newAgent.modelModuleId).toBe(tempModelModuleId);
    expect(newAgent.instructionModuleId).toBe(tempInstructionModuleId);
  });

  it("should get an agent profile by id", async () => {
    const fetched = await registry.getById(createdAgentId);
    expect(fetched).not.toBeNull();
    expect(fetched!.id).toBe(createdAgentId);
    expect(fetched!.name).toBe("test-agent");
  });

  it("should update an agent profile", async () => {
    const updated = await registry.update(createdAgentId, {
      title: "Updated Test Agent",
      status: "working",
    });

    expect(updated).not.toBeNull();
    expect(updated!.title).toBe("Updated Test Agent");
    expect(updated!.status).toBe("working");

    // Verify change is persisted
    const fetched = await registry.getById(createdAgentId);
    expect(fetched!.title).toBe("Updated Test Agent");
    expect(fetched!.status).toBe("working");
  });

  it("should list agent profiles with filters", async () => {
    const list = await registry.list({
      authorityLevel: 2,
      status: "working",
    });

    expect(list.length).toBeGreaterThanOrEqual(1);
    const agent = list.find((a) => a.id === createdAgentId);
    expect(agent).toBeDefined();
    expect(agent!.name).toBe("test-agent");
  });

  it("should delete an agent profile", async () => {
    const deleted = await registry.delete(createdAgentId);
    expect(deleted).toBe(true);

    const fetched = await registry.getById(createdAgentId);
    expect(fetched).toBeNull();
    createdAgentId = "";
  });
});
