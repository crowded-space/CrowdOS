import path from "node:path";

const WORKSPACE_DIR = "c:/Users/Asus/Documents/GitHub/.ThisCrowd";

export class Guard {
  /**
   * Validates if a path stays safely inside the workspace directory
   */
  static validatePath(targetPath: string): string {
    // Resolve absolute path
    const absolutePath = path.resolve(WORKSPACE_DIR, targetPath);

    // Prevent directory traversal
    if (!absolutePath.toLowerCase().startsWith(WORKSPACE_DIR.toLowerCase())) {
      throw new Error(`Access Denied: Path "${targetPath}" breaks out of workspace directory.`);
    }

    // Blacklist sensitive files
    const filename = path.basename(absolutePath).toLowerCase();
    const blacklistedFiles = [".env", "credentials.json", "package-lock.json", ".git"];
    if (blacklistedFiles.some(bf => filename === bf || absolutePath.toLowerCase().includes(`/${bf}/`))) {
      throw new Error(`Access Denied: File "${filename}" is in the system blacklist.`);
    }

    return absolutePath;
  }

  /**
   * Validates if a bash command is safe to execute
   */
  static validateCommand(command: string): void {
    const cmdLower = command.toLowerCase();

    // Static dangerous blacklist
    const blacklist = [
      "rm -rf", "shutdown", "format", "drop database", "drop table", "truncate",
      "del /s", "rd /s", "mkfs", "dd ", "chmod -r", "chown -r"
    ];

    if (blacklist.some(term => cmdLower.includes(term))) {
      throw new Error(`Safety Alert: Command contains dangerous blocked instruction.`);
    }
  }

  /**
   * Validates if command is in safe whitelist
   */
  static isCommandWhitelisted(command: string): boolean {
    const whitelist = [
      "npm run test", "node -v", "git status", "npm run build", "ls", "dir", "echo"
    ];
    const cmdLower = command.toLowerCase().trim();
    return whitelist.some(term => cmdLower.startsWith(term));
  }
}
