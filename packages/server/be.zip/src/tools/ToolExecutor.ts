import { getDb } from "../config/database.js";
import { agents, toolkitModules } from "../db/schema.js";
import { eq } from "drizzle-orm";
import { Guard } from "./safety/Guard.js";
import { toolRegistry } from "./registry.js";

export class ToolExecutor {
  async execute(agentId: string, toolId: string, args: any): Promise<{ success: boolean; output: string; error?: string }> {
    const db = getDb();
    const startTime = Date.now();

    try {
      // 1. Fetch Agent Identity
      const agent = await db.query.agents.findFirst({
        where: eq(agents.id, agentId),
      });

      if (!agent) {
        throw new Error(`Agent not found with id: ${agentId}`);
      }

      // 2. Fetch Toolkit Module
      if (!agent.toolkitModuleId) {
        throw new Error(`ToolkitModule authorization failed: No toolkit module assigned to @${agent.name}.`);
      }

      const toolkit = await db.query.toolkitModules.findFirst({
        where: eq(toolkitModules.id, agent.toolkitModuleId),
      });

      if (!toolkit) {
        throw new Error(`ToolkitModule not found with id: ${agent.toolkitModuleId}`);
      }

      // 3. Authorize Tool (union authorization check)
      const allowedTools = toolkit.tools;
      if (!allowedTools.includes(toolId)) {
        throw new Error(`ToolkitModule security breach: Tool "${toolId}" is not authorized for @${agent.name}. Please enable it in their ToolkitModule.`);
      }

      // 4. Retrieve tool from central registry
      const toolDef = toolRegistry.get(toolId);
      if (!toolDef) {
        throw new Error(`System Error: Tool "${toolId}" not found in central tool registry.`);
      }

      // Enforce authLevelRequired (L0 check)
      if (toolDef.authLevelRequired !== undefined) {
        if (agent.authorityLevel > toolDef.authLevelRequired && !agent.isOmniscient) {
          throw new Error(`ToolkitModule security breach: Tool "${toolId}" requires Level ${toolDef.authLevelRequired} authority. @${agent.name} is Level ${agent.authorityLevel} (Non-Omniscient).`);
        }
      }

      // 5. Run Safety Guards
      if (toolId === "execute_bash") {
        Guard.validateCommand(args.command);
      } else if (toolId === "execute_safe") {
        if (!Guard.isCommandWhitelisted(args.command)) {
          throw new Error(`Safety Alert: Command "${args.command}" is not in the system safe whitelist.`);
        }
      }

      // 6. Execute Tool Handler
      console.log(`[ToolExecutor] [${agent.name}] Calling tool "${toolId}"...`);
      const result = await toolDef.handler(args);
      const durationMs = Date.now() - startTime;

      console.log(`[ToolExecutor] [${agent.name}] Tool "${toolId}" finished in ${durationMs}ms (success: ${result.success})`);
      return result;

    } catch (err: any) {
      const durationMs = Date.now() - startTime;
      console.warn(`[ToolExecutor] Security Blocked / Execution failed for tool "${toolId}" in ${durationMs}ms: ${err.message || err}`);
      return {
        success: false,
        output: "",
        error: err.message || String(err),
      };
    }
  }
}
