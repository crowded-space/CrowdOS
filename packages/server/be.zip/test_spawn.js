import { eq } from "drizzle-orm";
import { getDb } from "./dist/config/database.js";
import { EventBroker } from "./dist/core/EventBroker.js";
import { L2Runtime } from "./dist/core/L2Runtime.js";
import { agents, channels } from "./dist/db/schema.js";

async function runTest() {
  console.log("=== STARTING FEATURE 12 INTEGRATION TEST ===");
  const db = getDb();

  // 1. Get or create a channel
  let ch = await db.query.channels.findFirst({
    where: eq(channels.name, "general"),
  });
  if (!ch) {
    console.log("Creating temporary channel...");
    ch = {
      id: "ch-test",
      categoryId: null,
      name: "general",
      type: "standard",
      createdBy: "system",
      position: 0,
      createdAt: new Date(),
    };
    await db.insert(channels).values(ch);
  }

  // 2. Get or create L2 Coordinator Agent
  let l2Agent = await db.query.agents.findFirst({
    where: eq(agents.authorityLevel, 2),
  });

  if (!l2Agent) {
    console.log("Creating mock Level 2 Coordinator Agent...");
    // Find some model/instruction modules
    const model = await db.query.modelModules.findFirst();
    const inst = await db.query.instructionModules.findFirst();

    l2Agent = {
      id: "agent-l2-test",
      name: "Architect_Raven",
      title: "Database Architect",
      species: "Raven",
      authorityLevel: 2,
      modelModuleId: model?.id || "fallback-model",
      instructionModuleId: inst?.id || "fallback-instruction",
      memorySharingPolicy: "none",
      isOmniscient: false,
      status: "idle",
      isTemplate: false,
      permissions: { spawnAgents: false, patchRuntime: false, accessAllChannels: false },
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    await db.insert(agents).values(l2Agent);
  }

  console.log(`Using L2 Coordinator: @${l2Agent.name} (ID: ${l2Agent.id})`);
  console.log(`Using Channel: #${ch.name} (ID: ${ch.id})`);

  // 3. Setup EventBroker with realtime listeners
  const broker = new EventBroker();

  broker.onAny((event) => {
    console.log(`[EVENT] [${event.type}]`, JSON.stringify(event.payload, null, 2));
  });

  // 4. Instantiate L2Runtime and trigger dispatch command!
  const l2Runtime = new L2Runtime();

  console.log("\n--- Dispatching Spawning Command ---");
  await l2Runtime.execute(
    broker,
    ch.id,
    l2Agent,
    "Please spawn L3 Worker and Supervisor pairs to compile our frontend stylesheet patterns and verify database seed files."
  );

  console.log("\n=== INTEGRATION TEST COMPLETED successfully ===");
}

runTest().catch((err) => {
  console.error("Test failed:", err);
  process.exit(1);
});
