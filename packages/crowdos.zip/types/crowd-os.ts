export type AgentStatus = 'active' | 'idle' | 'thinking' | 'delegating' | 'executing' | 'sleeping';
export type AgentLevel = 0 | 1 | 2 | 3; // L0 (Omniscient), L1 (Admin), L2 (Coordinator), L3 (Worker)

export interface Agent {
  id: string;
  name: string;
  species: string; // e.g. "Raven", "Crow", "Falcon" (species instead of role)
  level: AgentLevel;
  status: AgentStatus;
  avatar?: string;
  instructionModuleId?: string;
  modelModuleId?: string;
  toolkitModuleId?: string;
  parentId?: string; // Links to parent agent for hierarchy
  roleId?: string;
  createdAt: string;
  lastActive: string;
  description?: string;
}

export type MessageType = 'human' | 'agent' | 'system' | 'governance' | 'delegation' | 'tool_execution';

export interface DelegationInfo {
  id: string;
  fromAgentId: string;
  fromAgentName: string;
  toAgentId: string;
  toAgentName: string;
  task: string;
  status: 'pending' | 'executing' | 'completed' | 'failed';
  tokens: number;
  cost: number;
}

export interface ToolExecution {
  name: string;
  input: string; // JSON string input
  output?: string; // Result output
  durationMs: number;
  status: 'success' | 'error';
}

export interface Attachment {
  id: string;
  name: string;
  type: string; // e.g., 'image/png' or 'application/pdf'
  url: string;  // Data URL or object URL
  size?: number;
}

export interface Message {
  id: string;
  type: MessageType;
  content: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  channelId: string;
  timestamp: string;
  mentions?: string[];
  delegationInfo?: DelegationInfo;
  toolExecution?: ToolExecution;
  metadata?: Record<string, any>;
  attachments?: Attachment[];
}

export type ProviderType = 'google' | 'openai' | 'anthropic';

export interface ModelProfile {
  id: string;
  label: string;
  provider: ProviderType;
  modelName: string;
  apiKey?: string;
  baseUrl?: string;
  apiKeyConfigured: boolean;
  createdAt: string;
  updatedAt?: string;
}

export interface Channel {
  id: string;
  name: string;
  description: string;
  unreadCount: number;
  hasMention: boolean;
}

export interface Category {
  id: string;
  name: string;
  collapsed: boolean;
  channels: Channel[];
}

export interface Workspace {
  id: string;
  name: string;
  icon: string; // Emoji or simple initial
  dbUrl?: string;
  categories: Category[];
  createdAt: string;
}

// Cognitive Assembly Modules (Target modular architecture)
export interface InstructionModule {
  id: string;
  name: string;
  description?: string;
  systemPrompt: string;
  persona?: string;
  rules?: string[];
  sandboxPath?: string;
  modelProfileId?: string;
  createdAt: string;
}

export interface ModelModule {
  id: string;
  name: string;
  description?: string;
  modelProfileId: string; // Links to a ModelProfile
  temperature?: number; // 0.0 - 2.0
  maxTokens?: number;
  topP?: number;
  createdAt: string;
}

export interface ToolkitModule {
  id: string;
  name: string;
  description?: string;
  enabledToolIds: string[];
  sandboxConfig?: Record<string, any>;
  createdAt: string;
}

export interface RuntimeOverride {
  id: string;
  agentId: string;
  type: 'instruction' | 'model' | 'toolkit';
  patch: Record<string, any>;
  reason?: string;
  expiresAt?: string;
  active: boolean;
  createdAt: string;
}

export interface Tool {
  id: string;
  name: string;
  category: string;
  description: string;
  enabled: boolean;
  usageCount: number;
}

export interface Role {
  id: string;
  name: string;
  color: string; // oklch expression or hex
  permissions: string[];
}
