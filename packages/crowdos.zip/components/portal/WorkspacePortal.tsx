import React, { useState } from 'react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { Sparkles, Terminal, Cpu, Database, Network, Key, ArrowRight, Play, ChevronRight } from 'lucide-react';
import CrowIcon, { mapEmojiToCrowVariant } from '@/components/ui/crow-icon';

export default function WorkspacePortal() {
  const { createWorkspace, workspaces, enterWorkspace } = useCrowdOSStore();
  
  const [activeTab, setActiveTab] = useState<'create' | 'join'>('create');

  // Create Fields
  const [workspaceName, setWorkspaceName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('crow-white-rounded');
  const [databaseUrl, setDatabaseUrl] = useState('');

  // Join Fields
  const [joinUrl, setJoinUrl] = useState('');
  const [joinStatus, setJoinStatus] = useState<'idle' | 'testing' | 'success' | 'failed'>('idle');
  const [logText, setLogText] = useState<string[]>([]);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!workspaceName.trim()) return;

    createWorkspace(
      workspaceName,
      databaseUrl || 'spanner://corp-prod.google.sql/db_sandbox',
      selectedIcon
    );
  };

  const handleJoinTest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinUrl.trim()) return;

    setJoinStatus('testing');
    setLogText(['Starting handshake connection to: ' + joinUrl]);

    setTimeout(() => {
      setLogText(prev => [...prev, 'Resolving spanner coordinates...']);
      
      setTimeout(() => {
        setLogText(prev => [...prev, 'Verification SUCCESS. Initializing workspaces...']);
        setJoinStatus('success');

        // Automatically enter default or first workspace
        setTimeout(() => {
          if (workspaces.length > 0) {
            enterWorkspace(workspaces[0].id);
          } else {
            createWorkspace('Shared Corporate Slag', joinUrl, 'crow-rose-governance');
          }
        }, 800);

      }, 800);
    }, 600);
  };

  const icons = [
    'crow-white-rounded',
    'crow-dark-rounded',
    'crow-indigo-circle',
    'crow-amber-cyber',
    'crow-cyan-radar',
    'crow-rose-governance',
    'crow-matrix-terminal',
    'crow-cosmos'
  ];

  return (
    <div 
      className="fixed inset-0 bg-brand-bg flex items-center justify-center p-4 font-sans select-none overflow-y-auto"
      id="workspace-portal"
    >
      {/* Background ambient light */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] bg-indigo-500/10 blur-[130px] rounded-full shrink-0 pointer-events-none" />

      {/* Main card */}
      <div className="w-full max-w-md bg-brand-card border border-brand-border-muted rounded-xl overflow-hidden shadow-2xl p-6.5 space-y-6 relative flex flex-col items-center">
        
        {/* Brand Logo - Stacked variant from asset sheet */}
        <div className="text-center space-y-3.5 select-none flex flex-col items-center">
          <img src="/horizontal_logo_dark.png" alt="Crowd OS Logo" className="h-10 object-contain w-auto mb-2" />
          <div>
            <p className="text-[9.5px] font-mono tracking-[0.22em] text-zinc-500 uppercase mt-1 animate-pulse-slow">
              INTELLIGENCE . COORDINATION . IMPACT
            </p>
            <p className="text-xs text-zinc-500 mt-2 max-w-xs leading-normal">
              Autonomous cognitive agent orchestration workspace. Build, test, and dispatch corporate swarms.
            </p>
          </div>
        </div>

        {/* Dynamic Tab Toggles */}
        <div className="w-full grid grid-cols-2 p-1 bg-brand-bg border border-brand-border rounded-lg">
          <button
            onClick={() => setActiveTab('create')}
            className={`py-1.5 text-xs font-semibold rounded-md transition select-none cursor-pointer focus:outline-none ${
              activeTab === 'create' 
                ? 'bg-brand-border-muted text-zinc-100 font-medium' 
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            Create Workspace
          </button>
          <button
            onClick={() => setActiveTab('join')}
            className={`py-1.5 text-xs font-semibold rounded-md transition select-none cursor-pointer focus:outline-none ${
              activeTab === 'join' 
                ? 'bg-brand-border-muted text-zinc-100 font-medium' 
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            Join Live Spanner
          </button>
        </div>

        {/* Tab content forms */}
        {activeTab === 'create' ? (
          <form onSubmit={handleCreate} className="w-full space-y-4 text-xs font-sans leading-snug select-text">
            
            {/* Name */}
            <div className="space-y-1.5 text-left">
              <label className="text-zinc-550 font-bold font-mono text-[10px] uppercase tracking-wide">Workspace Brand Name</label>
              <input
                required
                type="text"
                value={workspaceName}
                onChange={(e) => setWorkspaceName(e.target.value)}
                placeholder="e.g. Swarm Research Core"
                className="w-full bg-brand-sidebar border border-brand-border focus:border-brand-border-muted focus:ring-1 focus:ring-brand-border-muted/40 rounded px-2.5 py-2 text-xs text-zinc-100 focus:outline-none placeholder-zinc-650"
              />
            </div>

            {/* Icon selection grid */}
            <div className="space-y-1.5 text-left select-none">
              <label className="text-zinc-550 font-bold font-mono text-[10px] uppercase tracking-wide">Launcher Symbol</label>
              <div className="grid grid-cols-4 gap-2 pt-0.5">
                {icons.map(ic => (
                  <button
                    key={ic}
                    type="button"
                    onClick={() => setSelectedIcon(ic)}
                    className={`h-11 bg-brand-sidebar rounded border transition cursor-pointer focus:outline-none flex justify-center items-center overflow-hidden ${
                      selectedIcon === ic 
                        ? 'border-indigo-500 bg-indigo-500/10 shadow-[0_0_10px_oklch(0.62_0.15_250/0.25)]' 
                        : 'border-brand-border hover:border-brand-border-muted hover:bg-brand-card/60'
                    }`}
                  >
                    <CrowIcon variant={ic} className="w-8 h-8 rounded bg-transparent border-0 shadow-none" iconSize={70} />
                  </button>
                ))}
              </div>
            </div>

            {/* Database fallback url */}
            <div className="space-y-1.5 text-left">
              <label className="text-zinc-550 font-bold font-mono text-[10px] uppercase tracking-wide">Spanner Database URL proxy (Optional)</label>
              <input
                type="text"
                value={databaseUrl}
                onChange={(e) => setDatabaseUrl(e.target.value)}
                placeholder="spanner://corp-prod.google.sql/db_148"
                className="w-full bg-brand-sidebar border border-brand-border focus:border-brand-border-muted focus:ring-1 focus:ring-brand-border-muted/40 rounded px-2.5 py-2 text-xs font-mono text-zinc-100 focus:outline-none placeholder-zinc-750"
              />
            </div>

            <button
              type="submit"
              disabled={!workspaceName.trim()}
              className={`w-full py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition select-none tracking-tight leading-none ${
                workspaceName.trim() 
                  ? 'bg-indigo-500 text-white font-medium hover:bg-indigo-650 shadow-[0_4px_12px_rgba(99,102,241,0.3)]' 
                  : 'bg-brand-sidebar text-zinc-600 border border-brand-border-muted/45 cursor-not-allowed'
              }`}
            >
              <Play size={11} />
              <span>Instantiate Swarm Space</span>
            </button>
          </form>
        ) : (
          /* TAB: JOIN SPANNER ENDPOINT */
          <form onSubmit={handleJoinTest} className="w-full space-y-4 text-xs font-sans leading-snug select-text">
            <div className="space-y-1.5 text-left">
              <label className="text-zinc-550 font-bold font-mono text-[10px] uppercase tracking-wide">Active Connection String</label>
              <input
                required
                type="text"
                value={joinUrl}
                onChange={(e) => setJoinUrl(e.target.value)}
                placeholder="spanner://corp-prod.google.sql/db_148"
                className="w-full bg-brand-sidebar border border-brand-border focus:border-brand-border-muted focus:ring-1 focus:ring-brand-border-muted/40 rounded px-2.5 py-2 text-xs font-mono text-zinc-100 focus:outline-none placeholder-zinc-750"
              />
            </div>

            <button
              type="submit"
              disabled={!joinUrl.trim() || joinStatus === 'testing'}
              className={`w-full py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition select-none leading-none tracking-tight ${
                joinUrl.trim() && joinStatus !== 'testing'
                  ? 'bg-indigo-500 text-white font-medium hover:bg-indigo-650 shadow-[0_4px_12px_rgba(99,102,241,0.3)]' 
                  : 'bg-brand-sidebar text-zinc-650 border border-brand-border-muted/45 cursor-not-allowed'
              }`}
            >
              <span>{joinStatus === 'testing' ? 'Testing Handshake...' : 'Verify & Mount Session'}</span>
            </button>

            {/* Terminal connect animation */}
            {logText.length > 0 && (
              <div className="bg-brand-bg border border-brand-border rounded-md p-3 font-mono text-[10px] text-zinc-400 space-y-1 text-left max-h-24 overflow-y-auto">
                <div className="text-zinc-650 font-bold flex items-center gap-1 select-none">
                  <Terminal size={10} />
                  <span>CONNECTION LOGS</span>
                </div>
                {logText.map((log, lidx) => (
                  <div key={lidx} className="whitespace-pre">
                    <span className="text-indigo-400 mr-1.5">&gt;</span>
                    <span>{log}</span>
                  </div>
                ))}
              </div>
            )}
          </form>
        )}

        {/* Existing local spaces if any */}
        {workspaces.length > 0 && (
          <div className="w-full border-t border-brand-border/60 pt-4.5 space-y-2 select-none">
            <h3 className="text-[9px] font-mono tracking-wider font-bold text-zinc-550 text-left uppercase">
              Or Choose Active Local Session ({workspaces.length})
            </h3>
            <div className="space-y-1 max-h-24 overflow-y-auto pr-1">
              {workspaces.map(ws => (
                <button
                  key={ws.id}
                  onClick={() => enterWorkspace(ws.id)}
                  className="w-full flex items-center justify-between p-2 hover:bg-brand-sidebar border border-brand-border rounded-lg text-zinc-300 text-left transition text-xs font-sans cursor-pointer focus:outline-none"
                >
                  <div className="flex items-center gap-2 truncate">
                    <CrowIcon variant={ws.icon} className="w-6 h-6 rounded bg-transparent border-0 shrink-0" iconSize={65} />
                    <span className="font-semibold truncate">{ws.name}</span>
                  </div>
                  <ChevronRight size={13} className="text-zinc-600 shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
