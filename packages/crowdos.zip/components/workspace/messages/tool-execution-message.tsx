import { useState } from 'react';
import { Settings, ChevronDown, ChevronUp, Cpu, Timer } from 'lucide-react';
import { ToolExecution } from '@/types/crowd-os';

interface ToolExecutionMessageProps {
  toolExecution?: ToolExecution;
  timestamp: string;
}

export default function ToolExecutionMessage({ toolExecution, timestamp }: ToolExecutionMessageProps) {
  const [expanded, setExpanded] = useState(false);
  if (!toolExecution) return null;

  const { name, input, output, durationMs, status } = toolExecution;
  const timeStr = new Date(timestamp).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

  const isSuccess = status === 'success';

  return (
    <div 
      id="tool-execution-message"
      className="max-w-xl mx-auto border border-zinc-800 bg-zinc-950/40 rounded-lg overflow-hidden my-2 font-mono text-xs"
    >
      {/* Header clickable to expand */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between p-3 bg-zinc-900/40 hover:bg-zinc-900/70 transition border-b border-zinc-900 text-left cursor-pointer focus:outline-none"
      >
        <div className="flex items-center gap-2">
          <Settings size={13} className={`animate-spin text-zinc-400 ${isSuccess ? 'text-teal-400' : 'text-rose-400'}`} style={{ animationDuration: '4s' }} />
          <div>
            <span className="font-semibold text-zinc-300">TOOL CALL:</span>
            <span className="ml-1.5 px-1.5 py-0.5 rounded bg-zinc-950 text-zinc-100 border border-zinc-800 font-mono text-[10px]">
              {name}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 text-[10px] text-zinc-500 font-mono">
            <Timer size={10} />
            <span>{durationMs}ms</span>
          </span>
          <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${isSuccess ? 'bg-teal-500/10 text-teal-400' : 'bg-rose-500/10 text-rose-400'}`}>
            {status.toUpperCase()}
          </span>
          {expanded ? <ChevronUp size={14} className="text-zinc-500" /> : <ChevronDown size={14} className="text-zinc-500" />}
        </div>
      </button>

      {/* Expanded parameter trees */}
      {expanded && (
        <div className="p-3 bg-zinc-950/80 space-y-3 border-t border-zinc-900 text-zinc-400 select-text selection:bg-indigo-500/30">
          <div>
            <span className="text-[10px] text-zinc-500 font-bold flex items-center gap-1 mb-1">
              <Cpu size={10} />
              <span>INPUT SCHEMATICS:</span>
            </span>
            <pre className="p-2.5 rounded bg-zinc-900/60 font-mono text-[10px] overflow-x-auto text-zinc-300 pointer-events-auto">
              {input}
            </pre>
          </div>

          {output && (
            <div>
              <span className="text-[10px] text-zinc-500 font-bold flex items-center gap-1 mb-1">
                <span>SYSTEM OUTFALL:</span>
              </span>
              <pre className="p-2.5 rounded bg-zinc-900 text-teal-300/95 font-mono text-[10px] overflow-x-auto border border-zinc-900 pointer-events-auto leading-normal">
                {output}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
