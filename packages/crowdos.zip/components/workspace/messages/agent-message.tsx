import { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import MentionParser from './mention-parser';
import AttachmentsView from './attachments-view';
import { AgentLevel, Attachment } from '@/types/crowd-os';
import { useCrowdOSStore } from '@/stores/crowd-os-store';

interface AgentMessageProps {
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  content: string;
  timestamp: string;
  metadata?: Record<string, any>;
  level?: AgentLevel;
  attachments?: Attachment[];
}

export default function AgentMessage({
  authorId,
  authorName,
  authorAvatar = '🤖',
  content,
  timestamp,
  metadata,
  level = 3,
  attachments
}: AgentMessageProps) {
  const [monologueExpanded, setMonologueExpanded] = useState(false);
  const { openAgentProfileModal } = useCrowdOSStore();
  const timeStr = new Date(timestamp).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

  // Level roles styling
  const levelMeta = {
    0: { label: 'L0 Omniscient', border: 'border-cyan-500/50', badgeBg: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30' },
    1: { label: 'L1 Admin', border: 'border-rose-500/50', badgeBg: 'bg-rose-500/10 text-rose-300 border-rose-500/30' },
    2: { label: 'L2 Coordinator', border: 'border-indigo-500/50', badgeBg: 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30' },
    3: { label: 'L3 Worker', border: 'border-emerald-500/50', badgeBg: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' }
  }[level] || { label: 'L3 Worker', border: 'border-zinc-700', badgeBg: 'bg-zinc-800 text-zinc-300 border-zinc-700' };

  const hasMonologue = !!metadata?.monologue;

  return (
    <div 
      id={`agent-message-${authorId}`}
      className="group flex gap-3 p-4 bg-zinc-900/40 border border-zinc-800/60 rounded-lg hover:bg-zinc-900/70 transition"
    >
      {/* Level-themed avatar border */}
      <button 
        type="button"
        onClick={() => openAgentProfileModal(authorId)}
        className={`flex items-center justify-center w-8 h-8 rounded-full border ${levelMeta.border} bg-zinc-950 text-sm select-none hover:opacity-80 hover:scale-105 active:scale-95 transition cursor-pointer focus:outline-none`}
        title={`View Profile of ${authorName}`}
      >
        {authorAvatar}
      </button>

      <div className="flex-1 min-w-0 space-y-1.5">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => openAgentProfileModal(authorId)}
            className="font-semibold text-zinc-100 text-sm tracking-tight truncate hover:text-indigo-400/90 transition cursor-pointer focus:outline-none text-left"
            title={`View Profile of ${authorName}`}
          >
            {authorName}
          </button>
          <span 
            onClick={() => openAgentProfileModal(authorId)}
            className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded border ${levelMeta.badgeBg} cursor-pointer hover:opacity-85 transition`}
          >
            {levelMeta.label}
          </span>
          <span className="text-[10px] text-zinc-500 font-mono">
            {timeStr}
          </span>
        </div>

        {/* Dynamic Monologue block */}
        {hasMonologue && (
          <div className="mt-1 border border-indigo-500/10 bg-indigo-500/[0.02] rounded-md p-2">
            <button 
              onClick={() => setMonologueExpanded(!monologueExpanded)}
              className="flex items-center gap-1.5 text-[10px] text-indigo-400 font-mono hover:text-indigo-300 transition focus:outline-none"
            >
              {monologueExpanded ? <EyeOff size={12} /> : <Eye size={12} />}
              <span>{monologueExpanded ? 'HIDE INTERNAL MONOLOGUE' : 'SHOW INTERNAL MONOLOGUE'}</span>
            </button>
            {monologueExpanded && (
              <div className="mt-1.5 text-[11px] text-zinc-400 italic font-mono leading-relaxed border-t border-indigo-500/10 pt-1.5 pl-2 border-l-2 border-indigo-500/30">
                {metadata.monologue}
              </div>
            )}
          </div>
        )}

        <div className="text-sm text-zinc-300 leading-relaxed font-sans">
          <MentionParser text={content} />
        </div>

        {/* Render Attachments */}
        <AttachmentsView attachments={attachments} />
      </div>
    </div>
  );
}
