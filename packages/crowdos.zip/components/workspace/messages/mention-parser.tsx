import React from 'react';

interface MentionParserProps {
  text: string;
}

export default function MentionParser({ text }: MentionParserProps) {
  if (!text) return null;

  // Pattern to extract strings like @Someone or @Some_Someone
  const pattern = /(@[A-Za-z0-9_-]+)/g;
  
  const parts = text.split(pattern);
  if (parts.length === 1) {
    return <span>{text}</span>;
  }

  return (
    <span id="mention-parsed">
      {parts.map((part, idx) => {
        if (!part) return null;
        if (part.startsWith('@')) {
          const isUser = part.includes('Juan') || part.includes('User');
          const style = isUser 
            ? 'bg-amber-400/10 text-amber-300 border-amber-400/20' 
            : 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20';

          return (
            <span 
              key={idx} 
              className={`inline-flex items-center px-1.5 py-0.5 rounded border text-xs font-mono font-medium mx-0.5 ${style}`}
            >
              {part}
            </span>
          );
        }
        return <span key={idx}>{part}</span>;
      })}
    </span>
  );
}
