import React from 'react';
import { Message, AgentLevel } from '@/types/crowd-os';
import HumanMessage from './human-message';
import AgentMessage from './agent-message';
import SystemMessage from './system-message';
import DelegationMessage from './delegation-message';
import ToolExecutionMessage from './tool-execution-message';
import { ShieldAlert } from 'lucide-react';

interface MessageRouterProps {
  message: Message;
  agentLevel?: AgentLevel;
  key?: string;
}

export default function MessageRouter({ message, agentLevel = 3 }: MessageRouterProps) {
  switch (message.type) {
    case 'human':
      return (
        <HumanMessage 
          authorName={message.authorName} 
          content={message.content} 
          timestamp={message.timestamp} 
          attachments={message.attachments}
          mentions={message.mentions}
        />
      );
      
    case 'agent':
      return (
        <AgentMessage 
          authorId={message.authorId}
          authorName={message.authorName}
          authorAvatar={message.authorAvatar}
          content={message.content}
          timestamp={message.timestamp}
          metadata={message.metadata}
          level={agentLevel}
          attachments={message.attachments}
        />
      );
      
    case 'system':
      return (
        <SystemMessage 
          content={message.content} 
          timestamp={message.timestamp} 
        />
      );

    case 'delegation':
      return (
        <DelegationMessage 
          delegationInfo={message.delegationInfo} 
          timestamp={message.timestamp} 
        />
      );

    case 'tool_execution':
      return (
        <ToolExecutionMessage 
          toolExecution={message.toolExecution} 
          timestamp={message.timestamp} 
        />
      );

    case 'governance':
      // Render a special safe-audit warning alert
      return (
        <div 
          id="governance-alert"
          className="max-w-xl mx-auto border border-rose-500/25 bg-rose-500/[0.03] p-3 rounded-lg my-2 font-mono text-xs text-rose-300"
        >
          <div className="flex items-center gap-2 mb-1 text-rose-400 font-bold tracking-wide">
            <ShieldAlert size={14} className="shrink-0 animate-bounce" />
            <span>SWARM GOVERNANCE EXCEPTION</span>
          </div>
          <p className="leading-relaxed text-zinc-300 font-sans pl-6">
            {message.content}
          </p>
          <div className="text-right text-[9px] text-zinc-500 mt-2">
            AUDITED AT {new Date(message.timestamp).toLocaleTimeString()}
          </div>
        </div>
      );

    default:
      return null;
  }
}
