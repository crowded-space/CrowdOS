import React, { useState } from 'react';
import { 
  X, Laptop, Users, Shield, ShieldAlert, Cpu, Hammer, Hash, BarChart3, 
  Trash2, Plus, ArrowRight, UserCheck, Play, ToggleLeft, ToggleRight, Radio,
  Layers, Brain, Wrench, Edit, Save, RotateCcw, FileCode, GripVertical, Check
} from 'lucide-react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { AgentLevel, AgentStatus } from '@/types/crowd-os';
import ModelCardsTab from '../settings/model-cards-tab';
import CrowIcon from '@/components/ui/crow-icon';

const ROLE_PERMISSIONS = [
  { id: 'administrator', label: 'Administrator', description: 'Grants all permissions and bypasses channel restrictions.' },
  { id: 'view_channels', label: 'View Channels', description: 'Allows members to view channels by default.' },
  { id: 'manage_channels', label: 'Manage Channels', description: 'Allows members to create, edit, or delete channels.' },
  { id: 'manage_roles', label: 'Manage Roles', description: 'Allows members to create or edit roles lower than their highest role.' },
  { id: 'manage_agents', label: 'Manage Agents', description: 'Allows members to spawn, patch, and deprovision agents.' },
  { id: 'manage_skills', label: 'Manage Skills', description: 'Allows members to create and edit custom skills.' },
  { id: 'manage_tools', label: 'Manage Tools', description: 'Allows members to configure tool access and sandbox permissions.' },
  { id: 'send_messages', label: 'Send Messages', description: 'Allows members to send messages in channels.' },
  { id: 'read_history', label: 'Read Message History', description: 'Allows members to read previous messages.' },
  { id: 'mention_roles', label: 'Mention Everyone and Roles', description: 'Allows members to use @everyone or mention all roles.' }
];

const ROLE_COLORS = [
  '#99AAB5', '#1ABC9C', '#2ECC71', '#3498DB', '#9B59B6', '#E91E63', '#F1C40F', '#E67E22', 
  '#E74C3C', '#95A5A6', '#11806A', '#1F8B4C', '#206694', '#71368A', '#AD1457', '#C27C0E', 
  '#A84300', '#992D22', '#979C9F', '#546E7A', '#1D4E89', '#00B0FF', '#00E5FF', '#1DE9B6', 
  '#00E676', '#76FF03', '#C6FF00', '#FFEA00', '#FFC400', '#FF9100', '#FF3D00', '#F50057'
];

export default function WorkspaceSettingsModal() {
  const { 
    workspaces, 
    activeWorkspaceId, 
    settingsModalOpen, 
    setSettingsModalOpen,
    workspaceSettingsTab,
    setWorkspaceSettingsTab,
    deleteWorkspace,
    agents,
    addAgent,
    deleteAgent,
    roles,
    addRole,
    deleteRole,
    tools,
    toggleToolEnabled,
    instructionModules,
    modelModules,
    toolkitModules,
    addInstructionModule,
    updateInstructionModule,
    deleteInstructionModule,
    addToolkitModule,
    updateToolkitModule,
    deleteToolkitModule,
    updateAgent,
    modelProfiles
  } = useCrowdOSStore();

  const activeWS = workspaces.find(ws => ws.id === activeWorkspaceId);

  // Skills Manager state handles
  const [editingSkillId, setEditingSkillId] = useState<string | null>(null);
  const [skillFormName, setSkillFormName] = useState('');
  const [skillFormDesc, setSkillFormDesc] = useState('');
  const [skillFormPrompt, setSkillFormPrompt] = useState('');
  const [skillFormSandboxPath, setSkillFormSandboxPath] = useState('');
  const [skillFormModelProfileId, setSkillFormModelProfileId] = useState('');
  const [isCreatingSkill, setIsCreatingSkill] = useState(false);

  // Tools Manager state handles
  const [editingToolModuleId, setEditingToolModuleId] = useState<string | null>(null);
  const [toolFormName, setToolFormName] = useState('');
  const [toolFormDesc, setToolFormDesc] = useState('');
  const [toolFormCapabilities, setToolFormCapabilities] = useState<string[]>([]);
  const [toolFormSchema, setToolFormSchema] = useState('');
  const [isCreatingToolModule, setIsCreatingToolModule] = useState(false);

  // Agent Creation form fields
  const [newAgentName, setNewAgentName] = useState('');
  const [newAgentSpecies, setNewAgentSpecies] = useState('Raven');
  const [newAgentLevel, setNewAgentLevel] = useState<AgentLevel>(3);
  const [newAgentParentId, setNewAgentParentId] = useState('');
  const [newAgentDesc, setNewAgentDesc] = useState('');
  const [agentFormOpen, setAgentFormOpen] = useState(false);

  // Agent Edit form fields
  const [editingAgentId, setEditingAgentId] = useState<string | null>(null);
  const [editAgentName, setEditAgentName] = useState('');
  const [editAgentSpecies, setEditAgentSpecies] = useState('Raven');
  const [editAgentLevel, setEditAgentLevel] = useState<AgentLevel>(2);
  const [editAgentDesc, setEditAgentDesc] = useState('');
  const [editAgentInstructionModuleId, setEditAgentInstructionModuleId] = useState('');
  const [editAgentToolkitModuleId, setEditAgentToolkitModuleId] = useState('');
  const [editAgentRoleId, setEditAgentRoleId] = useState('');

  // Roles Management state
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);
  const [draggedRoleId, setDraggedRoleId] = useState<string | null>(null);
  
  // Update the crowdOS store with reorder functionality
  const { reorderRoles, updateRole } = useCrowdOSStore.getState();

  const handleCreateRole = () => {
    addRole({
      name: 'New Role',
      color: ROLE_COLORS[0],
      permissions: ['read_history', 'send_messages']
    });
  };

  const selectedRole = roles.find(r => r.id === selectedRoleId);

  const handleDragStart = (e: React.DragEvent, id: string) => {
    setDraggedRoleId(id);
    e.dataTransfer.effectAllowed = 'move';
    // Small delay to allow the drag image to be generated before styling the original element
    setTimeout(() => {
      const el = document.getElementById(`role-${id}`);
      if (el) el.style.opacity = '0.5';
    }, 0);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    if (!draggedRoleId || draggedRoleId === targetId) {
      if (draggedRoleId) {
        const el = document.getElementById(`role-${draggedRoleId}`);
        if (el) el.style.opacity = '1';
      }
      setDraggedRoleId(null);
      return;
    }

    const draggedIndex = roles.findIndex(r => r.id === draggedRoleId);
    const targetIndex = roles.findIndex(r => r.id === targetId);
    
    if (draggedIndex !== -1 && targetIndex !== -1) {
      reorderRoles(draggedIndex, targetIndex);
    }

    const el = document.getElementById(`role-${draggedRoleId}`);
    if (el) el.style.opacity = '1';
    setDraggedRoleId(null);
  };

  const handleDragEnd = (e: React.DragEvent) => {
    if (draggedRoleId) {
      const el = document.getElementById(`role-${draggedRoleId}`);
      if (el) el.style.opacity = '1';
    }
    setDraggedRoleId(null);
  };

  const togglePermission = (permissionId: string) => {
    if (!selectedRole) return;
    const hasPerm = selectedRole.permissions.includes(permissionId);
    const newPerms = hasPerm 
      ? selectedRole.permissions.filter(p => p !== permissionId)
      : [...selectedRole.permissions, permissionId];
    updateRole(selectedRole.id, { permissions: newPerms });
  };
  const [newChannelName, setNewChannelName] = useState('');
  const [newChannelDesc, setNewChannelDesc] = useState('');
  const [newChannelCategory, setNewChannelCategory] = useState('');

  // Category Creation
  const [newCategoryName, setNewCategoryName] = useState('');

  // Local safety option toggles
  const [humanApproval, setHumanApproval] = useState(true);
  const [rateLimit, setRateLimit] = useState(true);
  const [emergencyKill, setEmergencyKill] = useState(false);

  if (!settingsModalOpen || !activeWS) return null;

  const handleCreateAgent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAgentName.trim()) return;

    // Alphanumeric + underscores validation matching specs (Phase C)
    const sanitizedName = newAgentName.replace(/[^A-Za-z0-9_]/g, '');
    if (!sanitizedName) {
      alert('Name must contain letters, numbers, or underscores.');
      return;
    }

    addAgent({
      name: sanitizedName,
      species: newAgentSpecies,
      level: newAgentLevel,
      status: 'idle',
      avatar: newAgentLevel === 0 ? '🦅' : newAgentLevel === 1 ? '🐦' : newAgentLevel === 2 ? '🦉' : '🤖',
      parentId: newAgentParentId || undefined,
      description: newAgentDesc,
      instructionModuleId: newAgentLevel === 0 ? 'mod-inst-l0' : newAgentLevel === 1 ? 'mod-inst-l1' : newAgentLevel === 2 ? 'mod-inst-l2' : 'mod-inst-l3-coder',
      modelModuleId: 'mod-model-light',
      toolkitModuleId: 'mod-tool-coder'
    });

    // Reset Form
    setNewAgentName('');
    setNewAgentSpecies('Raven');
    setNewAgentLevel(3);
    setNewAgentParentId('');
    setNewAgentDesc('');
    setAgentFormOpen(false);
  };

  const startEditingAgent = (agent: any) => {
    setEditingAgentId(agent.id);
    setEditAgentName(agent.name);
    setEditAgentSpecies(agent.species === 'Raven' || agent.species === 'Crow' ? agent.species : 'Crow'); 
    setEditAgentLevel(agent.level);
    setEditAgentDesc(agent.description || '');
    setEditAgentInstructionModuleId(agent.instructionModuleId || '');
    setEditAgentToolkitModuleId(agent.toolkitModuleId || '');
    setEditAgentRoleId(agent.roleId || '');
  };

  const handleSaveAgent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAgentId) return;

    const sanitizedName = editAgentName.replace(/[^A-Za-z0-9_]/g, '');
    if (!sanitizedName) {
      alert('Name must contain letters, numbers, or underscores.');
      return;
    }
    
    updateAgent(editingAgentId, {
      name: sanitizedName,
      species: editAgentSpecies,
      level: editAgentLevel,
      description: editAgentDesc,
      instructionModuleId: editAgentInstructionModuleId || undefined,
      toolkitModuleId: editAgentToolkitModuleId || undefined,
      roleId: editAgentRoleId || undefined,
      avatar: editAgentLevel === 0 ? '🦅' : editAgentLevel === 1 ? '🐦' : editAgentLevel === 2 ? '🦉' : '🤖',
    });
    setEditingAgentId(null);
  };



  const handleCreateChannel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChannelName.trim()) return;

    const formattedName = newChannelName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9_-]/g, '');
    
    // Push new channel into store workspace categories
    // We update current workspace Categories through custom mutation
    const updatedCategories = activeWS.categories.map(cat => {
      const match = cat.id === (newChannelCategory || cat.id); // add to matching or first
      if (match) {
        return {
          ...cat,
          channels: [
            ...cat.channels,
            {
              id: `ch-custom-${Date.now()}`,
              name: formattedName,
              description: newChannelDesc || 'Operations workspace',
              unreadCount: 0,
              hasMention: false
            }
          ]
        };
      }
      return cat;
    });

    // Directly assign back into workspaces list in store
    const updatedWorkspaces = useCrowdOSStore.getState().workspaces.map(ws => 
      ws.id === activeWorkspaceId ? { ...ws, categories: updatedCategories } : ws
    );
    useCrowdOSStore.setState({ workspaces: updatedWorkspaces });
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('crowdos_workspaces', JSON.stringify(updatedWorkspaces));
    }

    setNewChannelName('');
    setNewChannelDesc('');
  };

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;

    const formattedCatName = newCategoryName.trim();
    const newCategory = {
      id: `cat-custom-${Date.now()}`,
      name: formattedCatName,
      collapsed: false,
      channels: []
    };

    const updatedCategories = [...activeWS.categories, newCategory];

    // Directly assign back into workspaces list in store
    const updatedWorkspaces = useCrowdOSStore.getState().workspaces.map(ws => 
      ws.id === activeWorkspaceId ? { ...ws, categories: updatedCategories } : ws
    );
    useCrowdOSStore.setState({ workspaces: updatedWorkspaces });
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('crowdos_workspaces', JSON.stringify(updatedWorkspaces));
    }

    setNewCategoryName('');
  };

  // Skill Manager Handler helpers
  const startEditingSkill = (skill: any) => {
    setEditingSkillId(skill.id);
    setSkillFormName(skill.name);
    setSkillFormDesc(skill.description || '');
    setSkillFormPrompt(skill.systemPrompt);
    setSkillFormSandboxPath(skill.sandboxPath || `/src/skills/${skill.name.toLowerCase().replace(/\s+/g, '-')}.md`);
    setSkillFormModelProfileId(skill.modelProfileId || 'prof-gemini-flash');
  };

  const handleSaveSkill = (id: string) => {
    updateInstructionModule(id, {
      name: skillFormName,
      description: skillFormDesc,
      systemPrompt: skillFormPrompt,
      sandboxPath: skillFormSandboxPath,
      modelProfileId: skillFormModelProfileId
    });
    setEditingSkillId(null);
  };

  const handleCreateSkillSubmit = () => {
    if (!skillFormName.trim() || !skillFormPrompt.trim()) return;
    addInstructionModule({
      name: skillFormName,
      description: skillFormDesc,
      systemPrompt: skillFormPrompt,
      sandboxPath: skillFormSandboxPath || `/src/skills/${skillFormName.toLowerCase().replace(/\s+/g, '-')}.md`,
      modelProfileId: skillFormModelProfileId || 'prof-gemini-flash',
      persona: 'Expert Consultant',
      rules: []
    });
    setIsCreatingSkill(false);
    // Reset forms
    setSkillFormName('');
    setSkillFormDesc('');
    setSkillFormPrompt('');
    setSkillFormSandboxPath('');
    setSkillFormModelProfileId('');
  };

  // Tool Manager Handler helpers
  const startEditingToolModule = (toolMod: any) => {
    setEditingToolModuleId(toolMod.id);
    setToolFormName(toolMod.name);
    setToolFormDesc(toolMod.description || '');
    setToolFormCapabilities(toolMod.enabledToolIds || []);
    setToolFormSchema(JSON.stringify(toolMod.sandboxConfig || {}, null, 2));
  };

  const handleSaveToolModule = (id: string) => {
    let parsedConfig = {};
    try {
      parsedConfig = JSON.parse(toolFormSchema);
    } catch (err) {
      alert("Invalid JSON schema syntax. Please verify function declarations.");
      return;
    }
    updateToolkitModule(id, {
      name: toolFormName,
      description: toolFormDesc,
      enabledToolIds: toolFormCapabilities,
      sandboxConfig: parsedConfig
    });
    setEditingToolModuleId(null);
  };

  const handleCreateToolModuleSubmit = () => {
    if (!toolFormName.trim()) return;
    let parsedConfig = {};
    if (toolFormSchema.trim()) {
      try {
        parsedConfig = JSON.parse(toolFormSchema);
      } catch (err) {
        alert("Invalid JSON schema syntax. Please verify function declarations.");
        return;
      }
    }
    addToolkitModule({
      name: toolFormName,
      description: toolFormDesc,
      enabledToolIds: toolFormCapabilities,
      sandboxConfig: parsedConfig
    });
    setIsCreatingToolModule(false);
    // Reset fields
    setToolFormName('');
    setToolFormDesc('');
    setToolFormCapabilities([]);
    setToolFormSchema('');
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Laptop },
    { id: 'agents', label: 'Agents Board', icon: Users },
    { id: 'roles', label: 'Permissions & Roles', icon: Shield },
    { id: 'tools', label: 'Security Tools Whitelist', icon: Hammer },
    { id: 'model_cards', label: 'Model Cards Registers', icon: Cpu },
    { id: 'skills_manager', label: 'Skills Manager', icon: Brain },
    { id: 'channels', label: 'Category & Channels', icon: Hash },
    { id: 'safety', label: 'Safety Policies', icon: ShieldAlert }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-10 select-none" id="workspace-settings-modal">
      {/* Black Translucent Backdrop */}
      <div 
        onClick={() => setSettingsModalOpen(false)}
        className="absolute inset-0 bg-black/80 backdrop-blur-xs transition-opacity" 
      />

      {/* Primary Board View */}
      <div className="relative w-full max-w-4xl bg-[#0c0c0e] border border-zinc-900 rounded-xl overflow-hidden shadow-2xl flex flex-col md:flex-row h-[85vh] md:h-[75vh] max-h-[85vh] animate-scale-in">
        
        {/* Left Hand Navigation side panel */}
        <div className="w-full md:w-[200px] bg-[#09090b] border-r border-zinc-900 shrink-0 flex flex-col pt-3 py-2 scrollbar-none border-b md:border-b-0">
          <div className="px-4 pb-2 text-[10px] font-mono tracking-widest font-bold text-zinc-650 flex items-center gap-1 uppercase select-none">
            <Shield size={10} />
            <span>Admin Console</span>
          </div>

          <div className="flex-1 overflow-y-auto px-2 space-y-1">
            {tabs.map(tab => {
              const Icon = tab.icon;
              const active = workspaceSettingsTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setWorkspaceSettingsTab(tab.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-sans tracking-tight text-left rounded-md transition select-none cursor-pointer focus:outline-none ${
                    active 
                      ? 'bg-zinc-800 text-zinc-100 font-medium' 
                      : 'text-zinc-400 hover:bg-zinc-900/40 hover:text-zinc-200'
                  }`}
                >
                  <Icon size={13.5} className={active ? 'text-indigo-400' : 'text-zinc-600'} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <div className="border-t border-zinc-950 p-2 select-none">
            <button
              onClick={() => {
                if (confirm('De-authorize this workspace environment completely? This action is irreversible.')) {
                  deleteWorkspace(activeWS.id);
                  setSettingsModalOpen(false);
                }
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-rose-500/10 text-rose-450 hover:text-rose-400 font-semibold text-xs rounded-md transition focus:outline-none cursor-pointer"
            >
              <Trash2 size={13.5} />
              <span>Delete Workspace</span>
            </button>
          </div>
        </div>

        {/* Right Hand Option content panel */}
        <div className="flex-1 bg-[#0c0c0e] p-6 flex flex-col overflow-hidden min-w-0">
          
          {/* Header */}
          <div className="flex justify-between items-center pb-4 border-b border-zinc-900 mb-5 select-none shrink-0 leading-none">
            <h2 className="text-zinc-200 font-bold text-sm tracking-tight font-sans">
              {tabs.find(t => t.id === workspaceSettingsTab)?.label} Settings
            </h2>
            <button
              onClick={() => setSettingsModalOpen(false)}
              className="w-7 h-7 hover:bg-zinc-900 rounded-full flex items-center justify-center text-zinc-400 hover:text-zinc-100 transition focus:outline-none cursor-pointer"
              title="Close Settings Panel"
            >
              <X size={15} />
            </button>
          </div>

          {/* Settings Tabs Router Area */}
          <div className="flex-1 overflow-y-auto pr-1 scrollbar-thin select-text">
            
            {/* TAB: OVERVIEW */}
            {workspaceSettingsTab === 'overview' && (
              <div className="space-y-4 text-xs font-sans leading-relaxed">
                <div className="flex items-center gap-4 bg-zinc-950/45 p-4 rounded-lg border border-zinc-900 select-none">
                  <CrowIcon variant={activeWS.icon} className="w-14 h-14 rounded-xl border border-zinc-800" iconSize={65} />
                  <div className="space-y-1">
                    <h3 className="font-bold text-zinc-200 text-sm tracking-tight leading-none">{activeWS.name}</h3>
                    <p className="text-[10px] text-zinc-500 font-mono italic">WORKSPACE ID: {activeWS.id}</p>
                    <span className="px-1.5 py-0.2 rounded bg-indigo-500/10 border border-indigo-500/30 text-[9px] font-mono text-indigo-400 uppercase font-semibold inline-block">
                      SPANK SYSTEM ONLINE
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 text-left pt-1 select-none">
                  <div className="bg-zinc-900/20 border border-zinc-900 p-3 rounded-lg leading-tight">
                    <span className="text-zinc-500 font-mono text-[9px] font-bold block mb-1">REGISTERED AGENTS</span>
                    <span className="text-lg font-bold font-mono text-zinc-300">{agents.length} nodes</span>
                  </div>
                  <div className="bg-zinc-900/20 border border-zinc-900 p-3 rounded-lg leading-tight">
                    <span className="text-zinc-500 font-mono text-[9px] font-bold block mb-1">TOTAL CHANNELS</span>
                    <span className="text-lg font-bold font-mono text-zinc-300">5 sectors</span>
                  </div>
                  <div className="bg-zinc-900/20 border border-zinc-900 p-3 rounded-lg leading-tight">
                    <span className="text-zinc-500 font-mono text-[9px] font-bold block mb-1">ACTIVE MONITORS</span>
                    <span className="text-lg font-bold font-mono text-emerald-400">NORMAL BOUND</span>
                  </div>
                </div>

                <div className="space-y-1 bg-zinc-950 p-4 border border-zinc-900 rounded-lg">
                  <h4 className="font-semibold text-zinc-300 text-xs">Administrative Telemetries</h4>
                  <p className="text-zinc-500 leading-normal font-sans">
                    This single-user environment utilizes client-side isolated sandbox caches matching local database rules. It bypasses latency limits for microservice execution chains. You can add, edit, or terminate orchestrator nodes using the respective options above.
                  </p>
                </div>
              </div>
            )}

            {/* TAB: AGENTS */}
            {workspaceSettingsTab === 'agents' && (
              <div className="space-y-4 text-xs font-sans">
                <div className="flex items-center justify-between select-none">
                  <div>
                    <h3 className="font-semibold text-zinc-200">Orchestration Nodes</h3>
                    <p className="text-zinc-500 font-sans">Search and deploy available levels of agent minds inside the virtual environment.</p>
                  </div>
                  {!agentFormOpen && (
                    <button
                      onClick={() => setAgentFormOpen(true)}
                      className="px-2.5 py-1.5 bg-indigo-500 text-white rounded-md font-semibold hover:bg-indigo-650 flex items-center gap-1 transition cursor-pointer focus:outline-none"
                    >
                      <Plus size={13} />
                      <span>Assemble Mind</span>
                    </button>
                  )}
                </div>

                {/* Agent Creation Form */}
                {agentFormOpen && (
                  <form onSubmit={handleCreateAgent} className="bg-zinc-950 border border-zinc-900 p-4 rounded-lg space-y-3.5 select-text animate-fade-in-up">
                    <div className="flex items-center justify-between border-b border-zinc-900 pb-2 select-none">
                      <span className="font-semibold text-zinc-300 font-mono text-[10px]">ASSEMBLING BOT COGNITIVE TARGETS</span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 leading-snug">
                      <div className="space-y-1">
                        <label className="text-zinc-500 font-bold font-mono text-[10px] block">AGENT CODE NAME</label>
                        <input
                          required
                          type="text"
                          value={newAgentName}
                          onChange={(e) => setNewAgentName(e.target.value)}
                          placeholder="alphanumeric_with_underscores"
                          className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1.5 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 focus:outline-none font-mono text-xs text-zinc-100 placeholder-zinc-650"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-zinc-500 font-bold font-mono text-[10px] block">SPECIES</label>
                        <select
                          value={newAgentSpecies}
                          onChange={(e) => setNewAgentSpecies(e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1.5 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 focus:outline-none text-xs text-zinc-205 cursor-pointer"
                        >
                          <option value="Raven">Raven</option>
                          <option value="Crow">Crow</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 leading-snug">
                      <div className="space-y-1">
                        <label className="text-zinc-500 font-bold font-mono text-[10px] block">AUTHORITY TIER</label>
                        <select
                          value={newAgentLevel}
                          onChange={(e) => setNewAgentLevel(parseInt(e.target.value))}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1.5 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 focus:outline-none text-xs text-zinc-205 cursor-pointer"
                        >
                          <option value={0}>L0</option>
                          <option value={1}>L1</option>
                          <option value={2}>L2</option>
                          <option value={3}>L3</option>
                        </select>
                      </div>

                      <div className="space-y-1 animate-fade-in">
                        <label className="text-zinc-500 font-bold font-mono text-[10px] block">SUPERVISING PARENT</label>
                        <select
                          value={newAgentParentId}
                          onChange={(e) => setNewAgentParentId(e.target.value)}
                          className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-1.5 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 focus:outline-none text-xs text-zinc-205 cursor-pointer"
                        >
                          <option value="">None (Top-Level Node)</option>
                          {agents.filter(a => a.level < newAgentLevel).map(ag => (
                            <option key={ag.id} value={ag.id}>{ag.name} (L{ag.level})</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-zinc-500 font-bold font-mono text-[10px] block">DIRECTIVES SUMMARY DESCRIPTION</label>
                      <textarea
                        value={newAgentDesc}
                        onChange={(e) => setNewAgentDesc(e.target.value)}
                        placeholder="Write specific cognitive boundaries or summary task loops here..."
                        className="w-full bg-zinc-900 border border-zinc-800 rounded px-2.5 py-2 text-xs text-zinc-200 focus:outline-none focus:ring-1 focus:ring-zinc-700/45 resize-none placeholder-zinc-600 height-20"
                        rows={2}
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-1 select-none">
                      <button
                        type="button"
                        onClick={() => setAgentFormOpen(false)}
                        className="px-2.5 py-1.5 border border-zinc-800 rounded hover:bg-zinc-900 text-zinc-400 font-semibold cursor-pointer focus:outline-none"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-2.5 py-1.5 bg-indigo-500 text-white rounded font-semibold hover:bg-indigo-650 cursor-pointer"
                      >
                        Launch Assembly
                      </button>
                    </div>
                  </form>
                )}

                {/* Edit Agent Form */}
                {editingAgentId && (
                  <form onSubmit={handleSaveAgent} className="bg-[#101014] border border-indigo-900/60 p-4 rounded-lg space-y-3.5 select-text animate-fade-in">
                    <div className="flex items-center justify-between border-b border-indigo-900/40 pb-2 select-none">
                      <span className="font-semibold text-indigo-400 font-mono text-[10px]">EDITING AGENT NODE</span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 leading-snug">
                      <div className="space-y-1">
                        <label className="text-indigo-300 font-bold font-mono text-[10px] block">AGENT CODE NAME</label>
                        <input
                          required
                          type="text"
                          value={editAgentName}
                          onChange={(e) => setEditAgentName(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 focus:border-indigo-700 focus:ring-1 focus:ring-indigo-700/40 focus:outline-none font-mono text-xs text-zinc-100"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-indigo-300 font-bold font-mono text-[10px] block">SPECIES</label>
                        <select
                          value={editAgentSpecies}
                          onChange={(e) => setEditAgentSpecies(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 focus:border-indigo-700 focus:ring-1 focus:ring-indigo-700/40 focus:outline-none text-xs text-zinc-205 cursor-pointer"
                        >
                          <option value="Raven">Raven</option>
                          <option value="Crow">Crow</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 leading-snug">
                      <div className="space-y-1">
                        <label className="text-indigo-300 font-bold font-mono text-[10px] block">AUTHORITY TIER</label>
                        <select
                          value={editAgentLevel}
                          onChange={(e) => setEditAgentLevel(parseInt(e.target.value))}
                          className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 focus:border-indigo-700 focus:ring-1 focus:ring-indigo-700/40 focus:outline-none text-xs text-zinc-205 cursor-pointer"
                        >
                          <option value={0}>L0</option>
                          <option value={1}>L1</option>
                          <option value={2}>L2</option>
                          <option value={3}>L3</option>
                        </select>
                      </div>

                      <div className="space-y-1 animate-fade-in">
                        <label className="text-indigo-300 font-bold font-mono text-[10px] block">ASSIGN ROLE / PERMISSIONS</label>
                        <select
                          value={editAgentRoleId}
                          onChange={(e) => setEditAgentRoleId(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 focus:border-indigo-700 focus:ring-1 focus:ring-indigo-700/40 focus:outline-none text-xs text-zinc-205 cursor-pointer"
                        >
                          <option value="">No Custom Role</option>
                          {roles.map(r => (
                            <option key={r.id} value={r.id}>{r.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 leading-snug">
                      <div className="space-y-1">
                        <label className="text-indigo-300 font-bold font-mono text-[10px] block">ATTACHED SKILL (INSTRUCTION MODULE)</label>
                        <select
                          value={editAgentInstructionModuleId}
                          onChange={(e) => setEditAgentInstructionModuleId(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 focus:border-indigo-700 focus:ring-1 focus:ring-indigo-700/40 focus:outline-none text-xs text-zinc-205 cursor-pointer"
                        >
                          <option value="">Default Rules</option>
                          {instructionModules.map(m => (
                            <option key={m.id} value={m.id}>{m.name}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-indigo-300 font-bold font-mono text-[10px] block">ATTACHED TOOLKIT</label>
                        <select
                          value={editAgentToolkitModuleId}
                          onChange={(e) => setEditAgentToolkitModuleId(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 focus:border-indigo-700 focus:ring-1 focus:ring-indigo-700/40 focus:outline-none text-xs text-zinc-205 cursor-pointer"
                        >
                          <option value="">No External Tools</option>
                          {toolkitModules.map(m => (
                            <option key={m.id} value={m.id}>{m.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-indigo-300 font-bold font-mono text-[10px] block">INSTRUCTION BOX / DESCRIPTION</label>
                      <textarea
                        value={editAgentDesc}
                        onChange={(e) => setEditAgentDesc(e.target.value)}
                        placeholder="Write detailed cognitive instructions and system directives..."
                        className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-2 text-xs text-zinc-200 focus:outline-none focus:ring-1 focus:ring-indigo-700/45 resize-y min-h-[4rem] placeholder-zinc-600"
                        rows={3}
                      />
                    </div>

                    <div className="flex justify-end gap-2 pt-1 select-none">
                      <button
                        type="button"
                        onClick={() => setEditingAgentId(null)}
                        className="px-2.5 py-1.5 border border-zinc-800 rounded hover:bg-zinc-900 text-zinc-400 font-semibold cursor-pointer focus:outline-none transition"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-2.5 py-1.5 bg-indigo-600 text-white rounded font-semibold hover:bg-indigo-500 cursor-pointer transition shadow-xl"
                      >
                        Save Configuration
                      </button>
                    </div>
                  </form>
                )}

                {/* Agents List Table */}
                <div className="border border-zinc-900 rounded-lg overflow-hidden bg-zinc-950/20">
                  <table className="w-full text-left font-sans select-none border-collapse">
                    <thead>
                      <tr className="bg-zinc-950 border-b border-zinc-900 text-[9.5px] font-mono font-bold text-zinc-550 uppercase">
                        <th className="p-3">Agent</th>
                        <th className="p-3">Species</th>
                        <th className="p-3">Tier</th>
                        <th className="p-3">Status</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-900/40">
                      {agents.map(ag => (
                        <tr key={ag.id} className="hover:bg-zinc-900/10 text-xs">
                          <td className="p-3 font-semibold text-zinc-250 truncate max-w-xs">{ag.name}</td>
                          <td className="p-3 text-mono text-zinc-450">{ag.species}</td>
                          <td className="p-3">
                            <span className="px-1.5 py-0.2 select-none font-mono text-[9px] font-bold rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
                              L{ag.level}
                            </span>
                          </td>
                          <td className="p-3 capitalize text-zinc-400">{ag.status}</td>
                          <td className="p-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => startEditingAgent(ag)}
                                className="text-zinc-400 hover:text-indigo-300 p-1 bg-zinc-950 hover:bg-indigo-900/40 rounded border border-zinc-900 hover:border-indigo-900 transition focus:outline-none cursor-pointer"
                                title="Edit Agent Configuration"
                              >
                                <Edit size={11} />
                              </button>
                              {ag.level > 0 && (
                                <button
                                  onClick={() => {
                                    if (confirm(`Deprovision agent ${ag.name} from the operating pipeline?`)) {
                                      deleteAgent(ag.id);
                                    }
                                  }}
                                  className="text-rose-400 hover:text-rose-300 p-1 bg-zinc-950 hover:bg-rose-950/40 rounded border border-zinc-900 hover:border-rose-900 transition focus:outline-none cursor-pointer"
                                  title="De-Authorize Node"
                                >
                                  <Trash2 size={11} />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB: ROLES */}
            {workspaceSettingsTab === 'roles' && (
              <div className="flex gap-4 h-[500px]">
                {/* Left side: Roles List */}
                <div className="w-1/3 border border-zinc-900 rounded-lg bg-zinc-950/40 flex flex-col">
                  <div className="p-3 border-b border-zinc-900 flex items-center justify-between">
                    <span className="font-semibold text-zinc-300 text-xs uppercase">ROLES hierarchy</span>
                    <button onClick={handleCreateRole} className="p-1 hover:bg-zinc-800 rounded outline-none text-zinc-400 hover:text-zinc-200">
                      <Plus size={14} />
                    </button>
                  </div>
                  <div className="flex-1 overflow-y-auto p-2 space-y-1">
                    {roles.map((r, i) => (
                      <div 
                        key={r.id} 
                        id={`role-${r.id}`}
                        draggable
                        onDragStart={(e) => handleDragStart(e, r.id)}
                        onDragOver={handleDragOver}
                        onDrop={(e) => handleDrop(e, r.id)}
                        onDragEnd={handleDragEnd}
                        onClick={() => setSelectedRoleId(r.id)}
                        className={`flex items-center justify-between gap-2 p-2 rounded cursor-pointer transition ${selectedRoleId === r.id ? 'bg-indigo-900/40 border-[0.5px] border-indigo-700/50' : 'hover:bg-zinc-900 border-[0.5px] border-transparent'}`}
                      >
                        <div className="flex items-center gap-2 overflow-hidden">
                          <GripVertical size={13} className="text-zinc-600 cursor-grab shrink-0" />
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: r.color }} />
                          <span className="text-sm font-medium truncate text-zinc-200">
                            {r.name}
                          </span>
                        </div>
                        {selectedRoleId === r.id && <ArrowRight size={14} className="text-indigo-400 shrink-0" />}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right side: Role Edit Pane */}
                <div className="flex-1 border border-zinc-900 rounded-lg bg-zinc-950/20 flex flex-col overflow-hidden relative">
                  {selectedRole ? (
                    <div className="absolute inset-0 overflow-y-auto">
                      <div className="p-5 border-b border-zinc-900 space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold text-zinc-200 uppercase text-xs">Edit Role</h3>
                          <button
                            onClick={() => {
                              if (confirm(`Delete role ${selectedRole.name}?`)) {
                                deleteRole(selectedRole.id);
                                setSelectedRoleId(null);
                              }
                            }}
                            className="flex items-center gap-1.5 px-2 py-1 text-xs text-rose-400 hover:bg-rose-950/40 rounded transition"
                          >
                            <Trash2 size={12} />
                            <span>Delete</span>
                          </button>
                        </div>
                        
                        <div className="space-y-1.5">
                          <label className="text-xs font-mono font-medium text-zinc-400 uppercase">Role Name</label>
                          <input
                            type="text"
                            value={selectedRole.name}
                            onChange={(e) => updateRole(selectedRole.id, { name: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-sm focus:outline-none focus:border-indigo-600 text-zinc-200"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="text-xs font-mono font-medium text-zinc-400 uppercase">Role Color</label>
                          <div className="grid grid-cols-8 gap-2">
                            {ROLE_COLORS.map(color => (
                              <button
                                key={color}
                                onClick={() => updateRole(selectedRole.id, { color })}
                                className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition ${selectedRole.color === color ? 'border-zinc-200 scale-110' : 'border-transparent hover:scale-110'}`}
                                style={{ backgroundColor: color }}
                              >
                                {selectedRole.color === color && <Check size={14} className="text-black" />}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="p-5 space-y-4">
                        <h4 className="font-semibold text-zinc-200 uppercase text-xs border-b border-zinc-900 pb-2">Role Permissions</h4>
                        <div className="space-y-4">
                          {ROLE_PERMISSIONS.map(perm => {
                            const isGranted = selectedRole.permissions.includes(perm.id) || selectedRole.permissions.includes('all') || selectedRole.permissions.includes('administrator');
                            const isToggled = selectedRole.permissions.includes(perm.id);
                            const disabled = perm.id !== 'administrator' && (selectedRole.permissions.includes('all') || selectedRole.permissions.includes('administrator'));
                            return (
                              <div key={perm.id} className="flex items-start justify-between gap-4 py-2">
                                <div className="space-y-0.5 max-w-[80%]">
                                  <div className={`font-semibold text-sm ${isGranted ? 'text-zinc-200' : 'text-zinc-400'}`}>
                                    {perm.label}
                                  </div>
                                  <div className="text-xs text-zinc-500 leading-tight">
                                    {perm.description}
                                  </div>
                                </div>
                                <button
                                  onClick={() => togglePermission(perm.id)}
                                  disabled={disabled}
                                  className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center justify-center rounded-full transition-colors focus:outline-none ${isToggled ? 'bg-indigo-500' : 'bg-zinc-700'} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                                  role="switch"
                                >
                                  <span className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${isToggled ? 'translate-x-2' : '-translate-x-2'}`} />
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="h-full flex items-center justify-center text-zinc-500 text-sm">
                      Select a role to edit
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB: TOOLS */}
            {workspaceSettingsTab === 'tools' && (
              <div className="space-y-4 text-xs font-sans">
                <div>
                  <h3 className="font-semibold text-zinc-200">Agent Capabilities & Toolkit Module</h3>
                  <p className="text-zinc-500">Toggles authorization variables enabling target components to query system databases or execute untrusted sandboxed binaries.</p>
                </div>

                <div className="space-y-2.5 select-none">
                  {tools.map(t => (
                    <div 
                      key={t.id} 
                      className="bg-zinc-900/35 border border-zinc-900 p-3.5 rounded-lg flex items-center justify-between gap-4 font-sans leading-relaxed"
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-baseline gap-2">
                          <span className="font-semibold text-zinc-200 font-mono tracking-tight">{t.name}</span>
                          <span className="text-[8.5px] font-mono text-zinc-550 bg-zinc-950 border border-zinc-900 rounded px-1 group uppercase inline-block">
                            {t.category}
                          </span>
                        </div>
                        <p className="text-zinc-450 mt-1 truncate max-w-md text-[11px] leading-normal">{t.description}</p>
                      </div>

                      <div className="flex items-center gap-4 shrink-0 font-mono">
                        <span className="text-[10px] text-zinc-500">
                          {t.usageCount.toLocaleString()} Invokes
                        </span>

                        <button
                          onClick={() => toggleToolEnabled(t.id)}
                          className={`p-1 rounded cursor-pointer transition focus:outline-none ${
                            t.enabled 
                              ? 'text-teal-400 font-medium' 
                              : 'text-zinc-600'
                          }`}
                        >
                          {t.enabled ? <ToggleRight size={28} /> : <ToggleLeft size={28} />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: MODEL CARDS */}
            {workspaceSettingsTab === 'model_cards' && (
              <ModelCardsTab />
            )}

            {/* TAB: CHANNELS */}
            {workspaceSettingsTab === 'channels' && (
              <div className="space-y-4 text-xs font-sans">
                <div>
                  <h3 className="font-semibold text-zinc-200">Category & Operational Channels</h3>
                  <p className="text-zinc-500">Scaffold channels inside active categories. Dynamic channels act as isolated session threads.</p>
                </div>

                {/* Create Channel and category forms */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Create Category Form */}
                  <form onSubmit={handleCreateCategory} className="bg-zinc-950 border border-zinc-900 p-4 rounded-lg flex flex-col justify-between space-y-3 animate-fade-in leading-snug select-text">
                    <div className="space-y-3">
                      <span className="text-[10px] font-mono font-bold text-zinc-450 tracking-wider flex items-center gap-1 uppercase select-none">
                        <Layers size={11} /><span>Assemble New Category</span>
                      </span>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 font-bold block mb-1">CATEGORY NAME</label>
                        <input
                          required
                          type="text"
                          value={newCategoryName}
                          onChange={(e) => setNewCategoryName(e.target.value)}
                          placeholder="e.g. Core Cognitive Agents"
                          className="w-full bg-zinc-900 border border-zinc-800 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 rounded px-2.5 py-1.5 font-sans focus:outline-none text-xs text-zinc-200 placeholder-zinc-650"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end select-none pt-3">
                      <button
                        type="submit"
                        className="px-2.5 py-1.5 bg-indigo-500 hover:bg-indigo-650 font-semibold text-white rounded flex items-center gap-1 cursor-pointer focus:outline-none"
                      >
                        <Plus size={13} />
                        <span>Assemble Category</span>
                      </button>
                    </div>
                  </form>

                  {/* Scaffold Operational Channel */}
                  <form onSubmit={handleCreateChannel} className="bg-zinc-950 border border-zinc-900 p-4 rounded-lg space-y-3 animate-fade-in leading-snug select-text">
                    <span className="text-[10px] font-mono font-bold text-zinc-450 tracking-wider flex items-center gap-1 uppercase select-none"><Hash size={11} /><span>Scaffold Operational Channel</span></span>
                    <div className="grid grid-cols-2 gap-3 leading-snug">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 font-bold block mb-1">CHANNEL CODE LABEL</label>
                        <input
                          required
                          type="text"
                          value={newChannelName}
                          onChange={(e) => setNewChannelName(e.target.value)}
                          placeholder="e.g. layout-scaffolding"
                          className="w-full bg-zinc-900 border border-zinc-800 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 rounded px-2.5 py-1.5 font-sans focus:outline-none text-xs text-zinc-200 placeholder-zinc-650"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-zinc-500 font-bold block mb-1">BOUND CATEGORY</label>
                        <select
                          value={newChannelCategory}
                          required
                          onChange={(e) => setNewChannelCategory(e.target.value)}
                          className="bg-zinc-900 border border-zinc-800 text-zinc-250 text-xs rounded px-2.5 py-1.5 focus:outline-none w-full cursor-pointer focus:ring-1 focus:ring-zinc-700/40"
                        >
                          <option value="">Select Target Category...</option>
                          {activeWS.categories.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-zinc-500 font-bold block mb-1">DESCRIPTION</label>
                      <input
                        type="text"
                        value={newChannelDesc}
                        onChange={(e) => setNewChannelDesc(e.target.value)}
                        placeholder="e.g. Scrapes repository structures and tracks layouts"
                        className="w-full bg-zinc-900 border border-zinc-800 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 rounded px-2.5 py-1.5 text-xs text-zinc-250 focus:outline-none placeholder-zinc-650"
                      />
                    </div>

                    <div className="flex justify-end select-none">
                      <button
                        type="submit"
                        className="px-2.5 py-1.5 bg-indigo-500 hover:bg-indigo-650 font-semibold text-white rounded flex items-center gap-1 cursor-pointer focus:outline-none"
                      >
                        <Plus size={13} />
                        <span>Assemble Area</span>
                      </button>
                    </div>
                  </form>
                </div>

                {/* Structured listing */}
                <div className="space-y-3.5 select-none leading-none">
                  {activeWS.categories.map(c => (
                    <div key={c.id} className="space-y-1">
                      <div className="flex items-center justify-between px-1 mb-1">
                        <h4 className="font-mono text-[9.5px] font-bold text-zinc-500 uppercase">
                          {c.name}
                        </h4>
                        {c.name !== '[ADMIN]' && (
                          <button 
                            onClick={() => {
                              if (confirm(`Delete category? Channels inside it will also be removed. Action is irreversible.`)) {
                                useCrowdOSStore.getState().deleteCategory(c.id);
                              }
                            }}
                            className="p-1 hover:bg-rose-950/40 text-rose-450 rounded transition cursor-pointer"
                            title="Delete Category"
                          >
                            <Trash2 size={11.5} />
                          </button>
                        )}
                      </div>
                      <div className="space-y-1">
                        {c.channels.map(ch => (
                          <div key={ch.id} className="p-3 bg-zinc-900/10 border border-zinc-900 rounded-lg flex items-center justify-between gap-3 text-xs pr-4">
                            <div className="flex items-center gap-1.5 min-w-0">
                              <Hash size={13.5} className="text-zinc-650 shrink-0" />
                              <div className="leading-snug">
                                <span className="font-semibold text-zinc-350">{ch.name}</span>
                                <span className="text-[10.5px] text-zinc-500 block leading-normal mt-0.5 font-sans">{ch.description}</span>
                              </div>
                            </div>
                            <span className="text-[10px] text-zinc-600 font-mono">ACTIVE SECTOR</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: SKILLS MANAGER */}
            {workspaceSettingsTab === 'skills_manager' && (
              <div className="space-y-6 text-xs font-sans">
                {/* Board Overview Header */}
                <div className="flex items-center justify-between pb-3 border-b border-zinc-900 select-none">
                  <div>
                    <h3 className="font-semibold text-zinc-200 text-sm tracking-tight flex items-center gap-1.5">
                      <Brain size={15} className="text-zinc-400" />
                      <span>Workspace Skills & Tools Manager</span>
                    </h3>
                    <p className="text-zinc-500 text-[11px] leading-relaxed mt-0.5">Scaffold and wire modular instructions (Skills) and functional capabilities (Tools) to cognitive workspace agents.</p>
                  </div>
                </div>

                {/* Primary split containers mapping Skills & Tools */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                  
                  {/* Container 1: [Skill] */}
                  <div className="space-y-4 bg-zinc-950/30 border border-zinc-900/60 p-4 rounded-xl leading-relaxed flex flex-col">
                    <div className="flex items-center justify-between bg-zinc-950/20 pb-2 border-b border-zinc-900">
                      <div className="flex items-center gap-1.5">
                        <Brain size={13.5} className="text-indigo-400 shrink-0" />
                        <span className="font-bold text-zinc-200 tracking-wider font-mono text-[10px] uppercase">
                          [Skill] Catalog ({instructionModules.length})
                        </span>
                      </div>
                      
                      {!isCreatingSkill && !editingSkillId && (
                        <button
                          onClick={() => {
                            setIsCreatingSkill(true);
                            setSkillFormName('');
                            setSkillFormDesc('');
                            setSkillFormPrompt('# Custom Skill Instructions\n\n- Perform deep evaluation\n- Structure outputs as CJS models');
                            setSkillFormSandboxPath('/src/skills/custom-skill.md');
                            setSkillFormModelProfileId('prof-gemini-flash');
                          }}
                          className="px-2 py-1 text-[10px] font-mono font-bold text-indigo-400 hover:text-indigo-300 border border-indigo-500/20 hover:border-indigo-500/40 bg-indigo-500/[0.03] rounded transition flex items-center gap-0.5"
                        >
                          <Plus size={10} />
                          <span>NEW SKILL</span>
                        </button>
                      )}
                    </div>

                    {/* Skill Create / Edit Forms */}
                    {(isCreatingSkill || editingSkillId) && (
                      <div className="bg-[#0c0c0e] border border-zinc-800 p-3.5 rounded-lg space-y-3 animate-fade-in">
                        <div className="flex items-center justify-between border-b border-zinc-900 pb-1.5 select-none text-[10px] font-mono uppercase">
                          <span className="text-indigo-400 font-bold">
                            {isCreatingSkill ? 'Create New Skill Card' : 'Configure Skill Parameter'}
                          </span>
                          <button 
                            onClick={() => {
                              setIsCreatingSkill(false);
                              setEditingSkillId(null);
                            }}
                            className="text-zinc-500 hover:text-zinc-300 transition"
                          >
                            Cancel
                          </button>
                        </div>
                        
                        <div className="space-y-2.5">
                          <div>
                            <label className="text-[10px] font-bold text-zinc-450 font-mono uppercase block mb-1">SKILL NAME</label>
                            <input 
                              type="text"
                              value={skillFormName}
                              onChange={(e) => setSkillFormName(e.target.value)}
                              placeholder="e.g., Deep Web Research"
                              className="w-full bg-zinc-950 border border-zinc-850 rounded px-2.5 py-1.5 text-zinc-150 text-[11.5px] outline-none focus:border-zinc-700 font-sans"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-bold text-zinc-450 font-mono uppercase block mb-1">DESCRIPTION</label>
                            <input 
                              type="text"
                              value={skillFormDesc}
                              onChange={(e) => setSkillFormDesc(e.target.value)}
                              placeholder="Describe skill directives..."
                              className="w-full bg-zinc-950 border border-zinc-850 rounded px-2.5 py-1.5 text-zinc-150 text-[11.5px] outline-none focus:border-zinc-700 font-sans"
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="text-[10px] font-bold text-zinc-450 font-mono uppercase block mb-1">MODEL PROVIDER</label>
                              <select
                                value={skillFormModelProfileId}
                                onChange={(e) => setSkillFormModelProfileId(e.target.value)}
                                className="w-full bg-zinc-950 border border-zinc-850 rounded px-2 py-1 text-zinc-200 text-[11.5px] outline-none focus:border-zinc-700 font-mono"
                              >
                                {modelProfiles.map(p => (
                                  <option key={p.id} value={p.id}>{p.label}</option>
                                ))}
                              </select>
                            </div>
                            <div>
                              <label className="text-[10px] font-bold text-zinc-450 font-mono uppercase block mb-1">SANDBOX LOCATION</label>
                              <input 
                                type="text"
                                value={skillFormSandboxPath}
                                onChange={(e) => setSkillFormSandboxPath(e.target.value)}
                                placeholder="e.g., /src/skills/research.md"
                                className="w-full bg-zinc-950 border border-zinc-850 rounded px-2.5 py-1 py-1.5 text-zinc-150 text-[11.5px] outline-none focus:border-zinc-700 font-mono"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="text-[10px] font-bold text-zinc-450 font-mono uppercase block mb-1 flex items-center justify-between">
                              <span>MARKDOWN INSTRUCTIONS</span>
                              <span className="text-[9px] text-zinc-550 capitalize normal-case font-normal">Parsed as Markdown format</span>
                            </label>
                            <textarea 
                              value={skillFormPrompt}
                              onChange={(e) => setSkillFormPrompt(e.target.value)}
                              rows={5}
                              placeholder="# Directives..."
                              className="w-full bg-zinc-950 border border-zinc-850 rounded p-2.5 text-zinc-200 font-mono text-[11px] leading-relaxed outline-none focus:border-zinc-700 resize-y"
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-900 shrink-0">
                          <button 
                            onClick={() => {
                              if (editingSkillId) {
                                // Revert to original
                                const orig = instructionModules.find(m => m.id === editingSkillId);
                                if (orig) {
                                  setSkillFormName(orig.name);
                                  setSkillFormDesc(orig.description || '');
                                  setSkillFormPrompt(orig.systemPrompt);
                                  setSkillFormSandboxPath(orig.sandboxPath || `/src/skills/${orig.name.toLowerCase().replace(/\s+/g, '-')}.md`);
                                  setSkillFormModelProfileId(orig.modelProfileId || 'prof-gemini-flash');
                                }
                              } else {
                                setIsCreatingSkill(false);
                              }
                            }}
                            className="px-2.5 py-1 text-[11px] font-mono text-zinc-450 hover:text-zinc-250 hover:bg-zinc-900 border border-zinc-850/30 rounded transition flex items-center gap-1 cursor-pointer"
                          >
                            <RotateCcw size={10} />
                            <span>Revert</span>
                          </button>
                          <button 
                            onClick={() => {
                              if (editingSkillId) {
                                handleSaveSkill(editingSkillId);
                              } else {
                                handleCreateSkillSubmit();
                              }
                            }}
                            className="px-3 py-1 text-[11px] font-mono bg-indigo-600 hover:bg-indigo-500 text-white rounded transition flex items-center gap-1 cursor-pointer font-bold shadow-md"
                          >
                            <Save size={10} />
                            <span>Save Skill</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Skill Cards Lists */}
                    <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-1 scrollbar-thin">
                      {instructionModules.map(skill => (
                        <div 
                          key={skill.id}
                          className={`p-3 rounded-lg border flex flex-col gap-2.5 transition select-none ${
                            editingSkillId === skill.id 
                              ? 'bg-zinc-900/40 border-indigo-500/40' 
                              : 'bg-zinc-900/25 border-zinc-900 hover:bg-zinc-900/35'
                          }`}
                        >
                          <div className="flex items-start justify-between min-w-0 gap-3">
                            <div className="space-y-0.5 min-w-0 leading-snug">
                              <span className="font-semibold text-zinc-200 block text-xs truncate font-mono">
                                {skill.name}
                              </span>
                              {skill.description && (
                                <span className="text-[10.5px] text-zinc-500 block leading-normal">{skill.description}</span>
                              )}
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0 select-none">
                              <button
                                onClick={() => startEditingSkill(skill)}
                                className="p-1 text-zinc-550 hover:text-zinc-350 bg-zinc-950 hover:bg-zinc-900 rounded border border-zinc-900 transition focus:outline-none cursor-pointer"
                                title="Edit Skill Card"
                              >
                                <Edit size={10.5} />
                              </button>
                              
                              <button
                                onClick={() => {
                                  if (confirm(`Delete skill "${skill.name}"? Active agents using this skill will revert to default models.`)) {
                                    deleteInstructionModule(skill.id);
                                  }
                                }}
                                className="p-1 text-zinc-650 hover:text-rose-450 bg-zinc-950 hover:bg-[#1f0f15] rounded border border-zinc-900 transition focus:outline-none cursor-pointer"
                                title="Delete Skill Card"
                              >
                                <Trash2 size={10.5} />
                              </button>
                            </div>
                          </div>

                          {/* Skill Card Custom parameters */}
                          <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-zinc-500 bg-zinc-950/45 border border-zinc-900/80 p-1.5 rounded-md leading-relaxed select-text">
                            <div className="truncate">
                              <span className="text-zinc-650 font-semibold">📁 SANDBOX: </span>
                              <span className="text-zinc-400">{skill.sandboxPath || `/src/skills/${skill.name.toLowerCase().replace(/\s+/g, '-')}.md`}</span>
                            </div>
                            <div className="truncate text-right">
                              <span className="text-zinc-650 font-semibold">⚙️ PROFILE: </span>
                              <span className="text-zinc-400">
                                {modelProfiles.find(p => p.id === skill.modelProfileId)?.label || 'Default flash'}
                              </span>
                            </div>
                          </div>

                          {/* Attached Agents Row */}
                          <div className="pt-1.5 border-t border-zinc-900/40 select-none">
                            <span className="text-[9.5px] font-mono font-bold text-zinc-650 uppercase block mb-1">
                              Linked Sandbox Agents:
                            </span>
                            <div className="flex flex-wrap gap-1.5 items-center">
                              {agents.map(agent => {
                                const isAttached = agent.instructionModuleId === skill.id;
                                return (
                                  <button
                                    key={agent.id}
                                    onClick={() => {
                                      updateAgent(agent.id, { 
                                        instructionModuleId: isAttached ? undefined : skill.id 
                                      });
                                    }}
                                    className={`px-1.5 py-0.5 rounded text-[9px] font-mono transition select-none cursor-pointer border ${
                                      isAttached
                                        ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/35 hover:bg-indigo-500/15'
                                        : 'bg-zinc-950 text-zinc-550 border-zinc-900 hover:text-zinc-400 hover:bg-zinc-900/20'
                                    }`}
                                  >
                                    {isAttached ? '● ' : ''}{agent.name}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                  </div>

                  {/* Container 2: [Tool] */}
                  <div className="space-y-4 bg-zinc-950/30 border border-zinc-900/60 p-4 rounded-xl leading-relaxed flex flex-col">
                    
                    <div className="flex items-center justify-between bg-zinc-950/20 pb-2 border-b border-zinc-900">
                      <div className="flex items-center gap-1.5">
                        <Wrench size={13.5} className="text-teal-400 shrink-0" />
                        <span className="font-bold text-zinc-200 tracking-wider font-mono text-[10px] uppercase">
                          [Tool] Schema Catalog ({toolkitModules.length})
                        </span>
                      </div>
                      
                      {!isCreatingToolModule && !editingToolModuleId && (
                        <button
                          onClick={() => {
                            setIsCreatingToolModule(true);
                            setToolFormName('');
                            setToolFormDesc('');
                            setToolFormCapabilities(['sandbox.exec', 'web.search']);
                            setToolFormSchema(JSON.stringify({
                              "read_sandbox_file": {
                                "description": "Fetch code contents from current sandbox session directory",
                                "parameters": {
                                  "type": "object",
                                  "properties": {
                                    "filePath": { "type": "string" }
                                  },
                                  "required": ["filePath"]
                                }
                              }
                            }, null, 2));
                          }}
                          className="px-2 py-1 text-[10px] font-mono font-bold text-teal-405 hover:text-teal-400 border border-teal-500/20 hover:border-teal-500/40 bg-teal-500/[0.03] rounded transition flex items-center gap-0.5"
                        >
                          <Plus size={10} />
                          <span>NEW TOOL</span>
                        </button>
                      )}
                    </div>

                    {/* Tool Create / Edit Forms */}
                    {(isCreatingToolModule || editingToolModuleId) && (
                      <div className="bg-[#0c0c0e] border border-zinc-800 p-3.5 rounded-lg space-y-3 animate-fade-in">
                        <div className="flex items-center justify-between border-b border-zinc-900 pb-1.5 select-none text-[10px] font-mono uppercase">
                          <span className="text-teal-400 font-bold">
                            {isCreatingToolModule ? 'Create Modular Tool Box' : 'Configure function parameter'}
                          </span>
                          <button 
                            onClick={() => {
                              setIsCreatingToolModule(false);
                              setEditingToolModuleId(null);
                            }}
                            className="text-zinc-500 hover:text-zinc-350 transition animate-fade"
                          >
                            Cancel
                          </button>
                        </div>

                        <div className="space-y-2.5">
                          <div>
                            <label className="text-[10px] font-bold text-zinc-450 font-mono uppercase block mb-1">TOOL BLOCK NAME</label>
                            <input 
                              type="text"
                              value={toolFormName}
                              onChange={(e) => setToolFormName(e.target.value)}
                              placeholder="e.g., Code Verification kit"
                              className="w-full bg-zinc-950 border border-zinc-850 rounded px-2.5 py-1.5 text-zinc-150 text-[11.5px] outline-none focus:border-zinc-700 font-sans"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-bold text-zinc-450 font-mono uppercase block mb-1">DESCRIPTION</label>
                            <input 
                              type="text"
                              value={toolFormDesc}
                              onChange={(e) => setToolFormDesc(e.target.value)}
                              placeholder="e.g. Grants execution schema pipelines..."
                              className="w-full bg-zinc-950 border border-zinc-850 rounded px-2.5 py-1.5 text-zinc-150 text-[11.5px] outline-none focus:border-zinc-700 font-sans"
                            />
                          </div>

                          {/* Capabilities whitelist checkbox stack */}
                          <div>
                            <label className="text-[10px] font-bold text-zinc-450 font-mono uppercase block mb-1">WHITELISTED CAPABILITIES</label>
                            <div className="grid grid-cols-2 gap-1.5 bg-zinc-950 p-2.5 border border-zinc-850 rounded text-[10.5px] select-none text-zinc-400 leading-normal">
                              {['sandbox.exec', 'web.search', 'github.read', 'db.query', 'agent.orchestrate'].map(capId => {
                                const checked = toolFormCapabilities.includes(capId);
                                return (
                                  <label key={capId} className="flex items-center gap-1.5 cursor-pointer hover:text-zinc-200">
                                    <input 
                                      type="checkbox"
                                      checked={checked}
                                      onChange={() => {
                                        setToolFormCapabilities(prev => 
                                          checked 
                                            ? prev.filter(c => c !== capId) 
                                            : [...prev, capId]
                                        );
                                      }}
                                      className="accent-teal-500 cursor-pointer w-3.5 h-3.5 border-zinc-800 bg-zinc-950 text-teal-600 rounded"
                                    />
                                    <span className="font-mono text-[9px] uppercase">{capId}</span>
                                  </label>
                                );
                              })}
                            </div>
                          </div>

                          {/* Function call schema object definition */}
                          <div>
                            <label className="text-[10px] font-bold text-zinc-450 font-mono uppercase block mb-1 flex items-center justify-between">
                              <span>FUNCTION SCHEMAS (JSON)</span>
                              <span className="text-[9.5px] font-mono text-zinc-650 text-right uppercase">JSON SCHEMA</span>
                            </label>
                            <textarea 
                              value={toolFormSchema}
                              onChange={(e) => setToolFormSchema(e.target.value)}
                              rows={5}
                              placeholder="{}"
                              className="w-full bg-zinc-950 border border-zinc-850 rounded p-2.5 text-teal-300 font-mono text-[11px] leading-relaxed outline-none focus:border-zinc-700 resize-y"
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-900 shrink-0">
                          <button 
                            onClick={() => {
                              if (editingToolModuleId) {
                                const orig = toolkitModules.find(t => t.id === editingToolModuleId);
                                if (orig) {
                                  setToolFormName(orig.name);
                                  setToolFormDesc(orig.description || '');
                                  setToolFormCapabilities(orig.enabledToolIds || []);
                                  setToolFormSchema(JSON.stringify(orig.sandboxConfig || {}, null, 2));
                                }
                              } else {
                                setIsCreatingToolModule(false);
                              }
                            }}
                            className="px-2.5 py-1 text-[11px] font-mono text-zinc-450 hover:text-zinc-250 hover:bg-zinc-900 border border-zinc-850/30 rounded transition flex items-center gap-1 cursor-pointer"
                          >
                            <RotateCcw size={10} />
                            <span>Revert</span>
                          </button>
                          <button 
                            onClick={() => {
                              if (editingToolModuleId) {
                                handleSaveToolModule(editingToolModuleId);
                              } else {
                                handleCreateToolModuleSubmit();
                              }
                            }}
                            className="px-3 py-1 text-[11px] font-mono bg-teal-600 hover:bg-teal-500 text-white rounded transition flex items-center gap-1 cursor-pointer font-bold shadow-md"
                          >
                            <Save size={10} />
                            <span>Save Tool</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Tool lists */}
                    <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-1 scrollbar-thin">
                      {toolkitModules.map(toolMod => (
                        <div 
                          key={toolMod.id}
                          className={`p-3 rounded-lg border flex flex-col gap-2.5 transition select-none ${
                            editingToolModuleId === toolMod.id 
                              ? 'bg-zinc-900/40 border-teal-500/40' 
                              : 'bg-zinc-900/25 border-zinc-900 hover:bg-zinc-900/35'
                          }`}
                        >
                          <div className="flex items-start justify-between min-w-0 gap-3">
                            <div className="space-y-0.5 min-w-0 leading-snug">
                              <span className="font-semibold text-zinc-200 block text-xs truncate font-mono">
                                {toolMod.name}
                              </span>
                              {toolMod.description && (
                                <span className="text-[10.5px] text-zinc-500 block leading-normal">{toolMod.description}</span>
                              )}
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                onClick={() => startEditingToolModule(toolMod)}
                                className="p-1 text-zinc-550 hover:text-zinc-350 bg-zinc-950 hover:bg-zinc-900 rounded border border-zinc-900 transition focus:outline-none cursor-pointer"
                                title="Edit Toolkit Schema"
                              >
                                <Edit size={10.5} />
                              </button>
                              
                              <button
                                onClick={() => {
                                  if (confirm(`Delete toolkit "${toolMod.name}"? Active agents utilizing these tools will lose whitelisting variables.`)) {
                                    deleteToolkitModule(toolMod.id);
                                  }
                                }}
                                className="p-1 text-zinc-650 hover:text-rose-450 bg-zinc-950 hover:bg-[#1f0f15] rounded border border-zinc-900 transition focus:outline-none cursor-pointer"
                                title="Delete Toolkit Module"
                              >
                                <Trash2 size={10.5} />
                              </button>
                            </div>
                          </div>

                          {/* Capability pills whitelisted list */}
                          {toolMod.enabledToolIds && toolMod.enabledToolIds.length > 0 && (
                            <div className="flex flex-wrap gap-1 leading-none select-none">
                              {toolMod.enabledToolIds.map(toolId => (
                                <span key={toolId} className="text-[8.5px] font-mono text-zinc-450 bg-zinc-950 px-1.5 py-0.5 border border-zinc-900 rounded select-text">
                                  ⚡ {toolId}
                                </span>
                              ))}
                            </div>
                          )}

                          {/* Attached Agents Row */}
                          <div className="pt-1.5 border-t border-zinc-900/40 select-none">
                            <span className="text-[9.5px] font-mono font-bold text-zinc-650 uppercase block mb-1">
                              Linked Sandbox Agents:
                            </span>
                            <div className="flex flex-wrap gap-1.5 items-center">
                              {agents.map(agent => {
                                const isAttached = agent.toolkitModuleId === toolMod.id;
                                return (
                                  <button
                                    key={agent.id}
                                    onClick={() => {
                                      updateAgent(agent.id, { 
                                        toolkitModuleId: isAttached ? undefined : toolMod.id 
                                      });
                                    }}
                                    className={`px-1.5 py-0.5 rounded text-[9px] font-mono transition select-none cursor-pointer border ${
                                      isAttached
                                        ? 'bg-teal-500/10 text-teal-400 border-teal-500/35 hover:bg-teal-500/15'
                                        : 'bg-zinc-950 text-zinc-550 border-zinc-900 hover:text-zinc-400 hover:bg-zinc-900/20'
                                    }`}
                                  >
                                    {isAttached ? '● ' : ''}{agent.name}
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                        </div>
                      ))}
                    </div>

                  </div>

                </div>
              </div>
            )}

            {/* TAB: SAFETY */}
            {workspaceSettingsTab === 'safety' && (
              <div className="space-y-5 text-xs font-sans select-none leading-relaxed">
                <div>
                  <h3 className="font-semibold text-zinc-200">Swarm Safety & Whitelisting</h3>
                  <p className="text-zinc-500">Configure corporate permission policies, budget bounds, and emergency cutoff overrides.</p>
                </div>

                <div className="space-y-4">
                  {/* General policies */}
                  <div className="space-y-3 bg-zinc-950/40 border border-zinc-900 p-4 rounded-lg">
                    <h4 className="font-semibold text-zinc-300 text-xs flex items-center gap-1">
                      <Shield size={13} className="text-indigo-400" />
                      <span>General Execution Restrictions</span>
                    </h4>

                    <div className="space-y-3 select-none">
                      {/* Form approvals */}
                      <label className="flex items-start gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={humanApproval}
                          onChange={(e) => setHumanApproval(e.target.checked)}
                          className="mt-0.5 cursor-pointer accent-indigo-500"
                        />
                        <div className="leading-snug">
                          <span className="font-semibold text-zinc-250 block">Require Human Approval (L3)</span>
                          <span className="text-[11.5px] text-zinc-500 leading-normal block mt-0.5">Prompt the operator with confirmation panels before L3 workers run sandboxed file modifications.</span>
                        </div>
                      </label>

                      {/* Rate thresholds */}
                      <label className="flex items-start gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={rateLimit}
                          onChange={(e) => setRateLimit(e.target.checked)}
                          className="mt-0.5 cursor-pointer accent-indigo-500"
                        />
                        <div className="leading-snug">
                          <span className="font-semibold text-zinc-250 block">Aggressive Rate Limiter Checks</span>
                          <span className="text-[11.5px] text-zinc-500 leading-normal block mt-0.5">Enforce maximum token rates and budgets spending ceilings to secure workspace models from infinite looping.</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* Operational Kill-Switch trigger */}
                  <div className="bg-rose-500/[0.02] border border-rose-500/20 p-4 rounded-lg space-y-3">
                    <h4 className="font-semibold text-rose-400 text-xs flex items-center gap-1.5">
                      <ShieldAlert size={14} className="animate-pulse" />
                      <span>Operational Swarm Termination Switch</span>
                    </h4>
                    <p className="text-[11.5px] text-zinc-400 leading-normal font-sans">
                      Activating current switch triggers an immediate signal to dispatch servers, forcing a hard-abort on running sub-agent threads and freezing Sandbox processes.
                    </p>
                    <button
                      onClick={() => {
                        setEmergencyKill(!emergencyKill);
                        alert(emergencyKill ? 'Workspace unlocked. Restoring model loops.' : 'EMERGENCY SHUTDOWN SIGNALS SENT. RUNNING WORKERS TERMINATED.');
                      }}
                      className={`px-3 py-1.5 rounded text-xs font-mono font-bold uppercase transition select-none cursor-pointer focus:outline-none ${
                        emergencyKill 
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 hover:bg-emerald-500/15' 
                          : 'bg-rose-500/10 text-rose-450 border border-rose-500/25 hover:bg-rose-500/15'
                      }`}
                    >
                      {emergencyKill ? 'RESTORE SYSTEM SWARM LOOPS' : 'TERMINATE RUNNING COMPUTATIONS'}
                    </button>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>

      </div>
    </div>
  );
}
