import { useState } from 'react';
import { X, MessageSquare, ShieldAlert, Cpu, Hammer, FileText, ArrowUp, ArrowDown } from 'lucide-react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import PresenceIndicator from '../ui/presence-indicator';
import StatusBadge from '../ui/status-badge';

export default function AgentProfileModal() {
  const { 
    selectedAgentId, 
    agentProfileModalOpen, 
    closeAgentProfileModal, 
    agents,
    addMessage,
    activeChannelId,
    instructionModules,
    modelModules,
    toolkitModules
  } = useCrowdOSStore();

  const [dmText, setDmText] = useState('');

  if (!agentProfileModalOpen || !selectedAgentId) return null;

  const agent = agents.find(ag => ag.id === selectedAgentId);
  if (!agent) return null;

  // Level roles styling
  const levelStyles: Record<number, { text: string; bg: string; border: string; banner: string; title: string }> = {
    0: { text: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/30', banner: 'from-cyan-950 to-zinc-950', title: 'L0 Surveillance Monitor' },
    1: { text: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/30', banner: 'from-rose-950 to-zinc-950', title: 'L1 Executive Admin' },
    2: { text: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/30', banner: 'from-indigo-950 to-zinc-950', title: 'L2 Operation Coordinator' },
    3: { text: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/30', banner: 'from-emerald-950 to-zinc-950', title: 'L3 Autonomic Worker' }
  };

  const style = levelStyles[agent.level] || levelStyles[3];

  // Resolve matching modules
  const instModule = instructionModules.find(m => m.id === agent.instructionModuleId);
  const modelModule = modelModules.find(m => m.id === agent.modelModuleId);
  const toolModule = toolkitModules.find(m => m.id === agent.toolkitModuleId);

  // Resolve hierarchy relationships
  const parentAgent = agents.find(p => p.id === agent.parentId);
  const subDrones = agents.filter(d => d.parentId === agent.id);

  const handleSendDM = () => {
    if (!dmText.trim() || !activeChannelId) return;

    // Send direct prompt to current operational main channel with explicit tag @Agent
    addMessage({
      type: 'human',
      content: `@${agent.name} ${dmText}`,
      authorId: 'user-01',
      authorName: 'Juan Hamzah',
      channelId: activeChannelId
    });

    setDmText('');
    closeAgentProfileModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" id="agent-profile-modal">
      {/* Blur Backdrop */}
      <div 
        onClick={closeAgentProfileModal}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" 
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-md bg-[#0c0c0e] border border-zinc-800 rounded-xl overflow-hidden shadow-2xl animate-scale-in flex flex-col max-h-[90vh]">
        {/* Top Banner Gradient */}
        <div className={`h-24 bg-gradient-to-r ${style.banner} relative p-4 flex justify-end shrink-0`}>
          <button
            onClick={closeAgentProfileModal}
            className="w-7 h-7 bg-zinc-950/40 hover:bg-zinc-950/80 rounded-full flex items-center justify-center text-zinc-400 hover:text-zinc-100 transition focus:outline-none cursor-pointer"
          >
            <X size={15} />
          </button>
        </div>

        {/* Floating Avatar cut */}
        <div className="px-6 relative -mt-10 mb-2 shrink-0 select-none">
          <div className={`relative w-20 h-20 rounded-full bg-zinc-950 border-4 border-zinc-950 flex items-center justify-center text-3xl shadow-lg`}>
            {agent.avatar || '🤖'}
            <div className="absolute bottom-0 right-0 p-0.5 bg-zinc-950 rounded-full">
              <PresenceIndicator status={agent.status} size="md" />
            </div>
          </div>
        </div>

        {/* Content body Scroll Panel */}
        <div className="flex-1 overflow-y-auto px-6 pb-6 pt-2 space-y-4">
          {/* Identity details */}
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-zinc-100 font-sans tracking-tight">
                {agent.name}
              </h2>
              <span className={`text-[9px] font-mono uppercase px-1.5 py-0.2 rounded border font-semibold inline-block ${style.bg} ${style.text} ${style.border}`}>
                Level {agent.level}
              </span>
            </div>
            <div className="text-xs font-mono text-zinc-500">
              {style.title} • {agent.species}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <StatusBadge status={agent.status} />
            <span className="text-[10px] font-mono text-zinc-550 select-none">
              Last active: {new Date(agent.lastActive).toLocaleTimeString()}
            </span>
          </div>

          {agent.description && (
            <p className="text-xs text-zinc-400 font-sans leading-relaxed bg-zinc-900/30 p-2.5 rounded border border-zinc-900/60 pl-3">
              {agent.description}
            </p>
          )}

          <div className="border-t border-zinc-900 my-2 shrink-0 pointer-events-none" />

          {/* Module-based Cognitive Assembly summary cards */}
          <div className="space-y-2.5">
            <h3 className="text-[9px] font-mono tracking-widest font-bold text-zinc-550 uppercase">
              Modular Assembly
            </h3>

            {/* Instruction Module */}
            <div className="bg-zinc-950 border border-zinc-900 p-2.5 rounded-lg flex items-start gap-2.5">
              <FileText size={14} className="text-indigo-400 shrink-0 mt-0.5" />
              <div className="text-xs">
                <div className="font-semibold text-zinc-200 font-mono tracking-tight leading-none">
                  {instModule ? instModule.name : 'Standard Directives'}
                </div>
                <div className="text-[10px] text-zinc-500 mt-1 lines-clamp-2">
                  {instModule ? instModule.systemPrompt.slice(0, 100) + '...' : 'System guidance not bound.'}
                </div>
              </div>
            </div>

            {/* Model Module */}
            <div className="bg-zinc-950 border border-zinc-900 p-2.5 rounded-lg flex items-start gap-2.5">
              <Cpu size={14} className="text-cyan-400 shrink-0 mt-0.5" />
              <div className="text-xs">
                <div className="font-semibold text-zinc-200 font-mono tracking-tight leading-none">
                  {modelModule?.name || 'Dual Reasoner Profile'}
                </div>
                <div className="text-[10px] text-cyan-500 font-mono mt-1 uppercase">
                  Gemini-2.5-Pro • Temp {modelModule?.temperature || 0.4}
                </div>
              </div>
            </div>

            {/* Toolkit Module */}
            <div className="bg-zinc-950 border border-zinc-900 p-2.5 rounded-lg flex items-start gap-2.5">
              <Hammer size={14} className="text-emerald-400 shrink-0 mt-0.5" />
              <div className="text-xs">
                <div className="font-semibold text-zinc-200 font-mono tracking-tight leading-none">
                  {toolModule?.name || 'Coder Deck'}
                </div>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {(toolModule?.enabledToolIds || ['web.search', 'sandbox.exec']).map(tid => (
                    <span key={tid} className="text-[9px] font-mono px-1 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
                      {tid}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Hierarchy Branch mapping */}
          {(parentAgent || subDrones.length > 0) && (
            <div className="space-y-2 pt-2 text-xs">
              <h3 className="text-[9px] font-mono tracking-widest font-bold text-zinc-550 uppercase">
                Hierarchy Chain
              </h3>

              {parentAgent && (
                <div className="flex items-center gap-2 bg-zinc-900/10 p-2 rounded text-zinc-350">
                  <ArrowUp size={11.5} className="text-zinc-650" />
                  <span className="text-[10px] text-zinc-500">SUPERVISOR:</span>
                  <span className="font-semibold text-zinc-200 font-sans">{parentAgent.name}</span>
                </div>
              )}

              {subDrones.length > 0 && (
                <div className="flex items-start gap-2 bg-zinc-900/10 p-2 rounded text-zinc-350">
                  <ArrowDown size={11.5} className="text-zinc-650 mt-0.5" />
                  <div className="space-y-1">
                    <span className="text-[10px] text-zinc-500 block">SUBORDINATES:</span>
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      {subDrones.map(sb => (
                        <span key={sb.id} className="text-[10px] bg-zinc-950 border border-zinc-900 px-2 py-0.5 rounded text-zinc-200 font-sans">
                          {sb.name}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* DM Composer footer area */}
        <div className="p-4 bg-zinc-950 border-t border-zinc-900 shrink-0 select-none">
          <div className="bg-zinc-900 border border-zinc-800/80 rounded-lg p-1.5 flex gap-1.5 items-center">
            <MessageSquare size={14} className="text-zinc-500 shrink-0 ml-1.5" />
            <input 
              type="text" 
              value={dmText}
              onChange={(e) => setDmText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSendDM();
              }}
              placeholder={`Send instruction command @${agent.name}`}
              className="w-full bg-transparent border-none text-xs text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-0 py-1"
            />
            <button 
              onClick={handleSendDM}
              disabled={!dmText.trim()}
              className="h-6 w-6 rounded bg-indigo-500 text-white flex items-center justify-center transition disabled:bg-zinc-800 disabled:text-zinc-600 focus:outline-none cursor-pointer"
            >
              <X size={12} className="rotate-45" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
