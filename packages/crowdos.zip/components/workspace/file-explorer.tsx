import React, { useState, useRef, useEffect } from 'react';
import { Folder, FolderOpen, File, FileText, Image as ImageIcon, ChevronRight, ChevronDown, Terminal, FileCode2, Package, Search, Sparkles, Code2, Database, X } from 'lucide-react';

interface FileNode {
  name: string;
  type: 'folder' | 'file';
  ext?: string;
  children?: FileNode[];
}

export const mockFileContent: Record<string, string> = {
  'AgentBubble.tsx': `import React from 'react';\n\nexport const AgentBubble = () => {\n  return (\n    <div className="agent-bubble">\n      <span>Agent!</span>\n    </div>\n  );\n};\n`,
  'WorkspaceSidebar.tsx': `import React from 'react';\nimport { Folder } from 'lucide-react';\n\nexport default function WorkspaceSidebar() {\n  return <aside>Sidebar</aside>;\n}\n`,
  'utils.ts': `export function cn(...classes: string[]) {\n  return classes.filter(Boolean).join(' ');\n}\n`,
  'api.ts': `export const fetchAgent = async () => {\n  const res = await fetch('/api/agent');\n  return res.json();\n};\n`,
  'globals.css': `@tailwind base;\n@tailwind components;\n@tailwind utilities;\n\nbody {\n  @apply bg-zinc-950 text-white;\n}\n`,
  'App.tsx': `import React from 'react';\n\nexport default function App() {\n  return <div>App</div>;\n}\n`,
  'main.tsx': `import React from 'react';\nimport ReactDOM from 'react-dom/client';\nimport App from './App';\n\nReactDOM.createRoot(document.getElementById('root')!).render(<App />);\n`,
  'package.json': `{\n  "name": "crowd-os",\n  "version": "1.0.0",\n  "dependencies": {\n    "react": "^18.2.0"\n  }\n}\n`,
  'vite.config.ts': `import { defineConfig } from 'vite';\nimport react from '@vitejs/plugin-react';\n\nexport default defineConfig({\n  plugins: [react()]\n});\n`,
  'README.md': `# CrowdOS\n\nWelcome to CrowdOS.\n`,
  'logo.svg': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">\n  <circle cx="50" cy="50" r="50" fill="#4f46e5" />\n</svg>\n`,
  'favicon.ico': `Binary content: ...`
};

const mockFileSystem: FileNode[] = [
  {
    name: 'src',
    type: 'folder',
    children: [
      { name: 'components', type: 'folder', children: [
        { name: 'AgentBubble.tsx', type: 'file', ext: 'tsx' },
        { name: 'WorkspaceSidebar.tsx', type: 'file', ext: 'tsx' },
      ]},
      { name: 'lib', type: 'folder', children: [
        { name: 'utils.ts', type: 'file', ext: 'ts' },
        { name: 'api.ts', type: 'file', ext: 'ts' },
      ]},
      { name: 'styles', type: 'folder', children: [
        { name: 'globals.css', type: 'file', ext: 'css' },
      ]},
      { name: 'App.tsx', type: 'file', ext: 'tsx' },
      { name: 'main.tsx', type: 'file', ext: 'tsx' },
    ]
  },
  {
    name: 'public',
    type: 'folder',
    children: [
      { name: 'logo.svg', type: 'file', ext: 'svg' },
      { name: 'favicon.ico', type: 'file', ext: 'ico' },
    ]
  },
  { name: 'package.json', type: 'file', ext: 'json' },
  { name: 'vite.config.ts', type: 'file', ext: 'ts' },
  { name: 'README.md', type: 'file', ext: 'md' },
];

const getFileIcon = (ext?: string) => {
  switch (ext) {
    case 'tsx':
    case 'ts':
      return <FileCode2 size={14} className="text-blue-400" />;
    case 'json':
      return <Package size={14} className="text-yellow-400" />;
    case 'css':
      return <FileCode2 size={14} className="text-pink-400" />;
    case 'svg':
    case 'ico':
    case 'png':
      return <ImageIcon size={14} className="text-purple-400" />;
    case 'md':
      return <FileText size={14} className="text-zinc-400" />;
    default:
      return <File size={14} className="text-zinc-500" />;
  }
};

const highlightSyntax = (code: string) => {
  let h = code.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  
  // comments
  h = h.replace(/(\/\/.*$)/gm, '<<COMMENT>>$1<</COMMENT>>');
  
  // strings
  h = h.replace(/('.*?'|".*?"|`.*?`)/g, '<<STRING>>$1<</STRING>>');
  
  // keywords
  h = h.replace(/\b(import|from|export|const|let|var|async|await|function|return|default|if|else|for|while|switch|case|interface|type)\b/g, '<<KEYWORD>>$1<</KEYWORD>>');
  
  // Custom types / React Components
  h = h.replace(/\b([A-Z][a-zA-Z0-9]*)\b/g, '<<TYPE>>$1<</TYPE>>');
  
  // Numbers
  h = h.replace(/\b([0-9]+)\b/g, '<<NUMBER>>$1<</NUMBER>>');

  return h
    .replace(/<<COMMENT>>/g, '<span class="text-zinc-500 italic">')
    .replace(/<<\/COMMENT>>/g, '</span>')
    .replace(/<<STRING>>/g, '<span class="text-emerald-400">')
    .replace(/<<\/STRING>>/g, '</span>')
    .replace(/<<KEYWORD>>/g, '<span class="text-rose-400 font-semibold">')
    .replace(/<<\/KEYWORD>>/g, '</span>')
    .replace(/<<TYPE>>/g, '<span class="text-indigo-400">')
    .replace(/<<\/TYPE>>/g, '</span>')
    .replace(/<<NUMBER>>/g, '<span class="text-amber-300">')
    .replace(/<<\/NUMBER>>/g, '</span>');
};

export const SimpleSyntaxHighlighter = ({ code, onChange, editable = false }: { code: string, onChange?: (val: string) => void, editable?: boolean }) => {
  const [internalCode, setInternalCode] = useState(code);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const preRef = useRef<HTMLPreElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setInternalCode(code);
  }, [code]);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInternalCode(e.target.value);
    onChange?.(e.target.value);
  };

  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    if (preRef.current) {
      preRef.current.scrollTop = e.currentTarget.scrollTop;
      preRef.current.scrollLeft = e.currentTarget.scrollLeft;
    }
    if (lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = e.currentTarget.scrollTop;
    }
  };

  const lines = internalCode.split('\n');

  if (editable) {
    return (
      <div className="relative h-full w-full flex bg-[#0c0c0e] text-[10px] sm:text-[11px] font-mono leading-relaxed group">
        <div 
          ref={lineNumbersRef}
          className="w-8 shrink-0 text-right pr-2 pl-1 pt-3 text-zinc-700 select-none border-r border-zinc-900/50 mr-2 overflow-hidden" 
        >
          {lines.map((_, i) => (
            <div key={i}>{i + 1}</div>
          ))}
        </div>
        
        <div className="relative flex-1 h-full overflow-hidden">
          <pre 
            ref={preRef}
            className="absolute inset-0 pt-3 pr-3 m-0 whitespace-pre overflow-hidden pointer-events-none select-none text-zinc-300"
            style={{ tabSize: 2 }}
            dangerouslySetInnerHTML={{ __html: highlightSyntax(internalCode) || ' ' }}
          />
          <textarea
            ref={textareaRef}
            spellCheck={false}
            value={internalCode}
            onChange={handleChange}
            onScroll={handleScroll}
            className="absolute inset-0 pt-3 pr-3 m-0 w-full h-full resize-none outline-none bg-transparent whitespace-pre scrollbar-thin text-transparent caret-zinc-200"
            style={{ tabSize: 2 }}
          />
        </div>
      </div>
    );
  }

  return (
    <pre className="text-[10px] sm:text-[11px] font-mono leading-relaxed h-full overflow-auto min-w-0 bg-[#0c0c0e]" style={{ tabSize: 2 }}>
      {lines.map((line, i) => (
        <div key={i} className="flex hover:bg-zinc-900/50">
          <span className="w-8 shrink-0 text-right pr-3 pl-1 text-zinc-700 select-none border-r border-zinc-900/50 mr-3">{i + 1}</span>
          <span className="whitespace-pre text-zinc-300" dangerouslySetInnerHTML={{ __html: highlightSyntax(line) || ' ' }} />
        </div>
      ))}
    </pre>
  );
};

const FileTreeNode: React.FC<{ node: FileNode, level?: number, selectedFile?: string, onSelectFile?: (node: FileNode) => void }> = ({ node, level = 0, selectedFile, onSelectFile }) => {
  const [isOpen, setIsOpen] = useState(node.name === 'src' || node.name === 'components');

  if (node.type === 'folder') {
    return (
      <div className="select-none">
        <div 
          className="flex items-center gap-1.5 py-1 px-2 hover:bg-zinc-900/60 rounded-md cursor-pointer transition text-zinc-300 hover:text-zinc-100"
          style={{ paddingLeft: `${ level * 12 + 8 }px` }}
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <ChevronDown size={14} className="text-zinc-500" /> : <ChevronRight size={14} className="text-zinc-500" />}
          {isOpen ? <FolderOpen size={14} className="text-indigo-400" /> : <Folder size={14} className="text-indigo-400/80" />}
          <span className="text-xs font-medium tracking-tight truncate">{node.name}</span>
        </div>
        {isOpen && node.children && (
          <div className="flex flex-col">
            {node.children.map((child, i) => (
              <FileTreeNode key={i} node={child} level={level + 1} selectedFile={selectedFile} onSelectFile={onSelectFile} />
            ))}
          </div>
        )}
      </div>
    );
  }

  const isSelected = selectedFile === node.name;

  return (
    <div 
      onClick={() => onSelectFile && onSelectFile(node)}
      className={`group flex items-center justify-between py-1 px-2 rounded-md cursor-pointer transition select-none ${
        isSelected 
          ? 'bg-indigo-500/15 text-zinc-200 shadow-sm' 
          : 'hover:bg-zinc-900/60 text-zinc-400 hover:text-zinc-200'
      }`}
      style={{ paddingLeft: `${ level * 12 + 28 }px` }}
    >
      <div className="flex items-center gap-2 min-w-0">
        {getFileIcon(node.ext)}
        <span className={`text-xs tracking-tight truncate font-sans ${isSelected ? 'font-medium' : ''}`}>{node.name}</span>
      </div>
    </div>
  );
};

import { useCrowdOSStore } from '@/stores/crowd-os-store';

export default function FileExplorer() {
  const { selectedSandboxFile, setSelectedSandboxFile } = useCrowdOSStore();

  const handleSelectFile = (node: FileNode) => {
    setSelectedSandboxFile(node.name);
  };

  return (
    <div className="flex flex-col h-full bg-[#0c0c0e]/95">
      {/* Title */}
      <div className="p-3.5 border-b border-zinc-900 flex items-center justify-between shrink-0 select-none">
        <h2 className="text-[10.5px] font-mono tracking-wider font-bold text-zinc-550 flex items-center gap-1.5 uppercase">
          <Terminal size={12} className="text-zinc-550" />
          <span>Workspace Sandbox</span>
        </h2>
        <div className="flex items-center gap-1">
          <button className="text-zinc-500 hover:text-zinc-300 p-1 hover:bg-zinc-800 rounded transition cursor-pointer focus:outline-none">
            <Search size={12} />
          </button>
        </div>
      </div>

      {/* Action Bar */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-zinc-900 bg-zinc-950/50 shrink-0">
        <div className="flex -space-x-1">
          <div className="w-5 h-5 rounded-full bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center z-10" title="Sparrow Runner active">
             <Sparkles size={10} className="text-indigo-400" />
          </div>
          <div className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center" title="Code indexing">
             <Code2 size={10} className="text-emerald-400" />
          </div>
        </div>
        <span className="text-[10px] text-zinc-500 font-mono truncate">2 agents in sandbox</span>
      </div>

      {/* File Tree */}
      <div className="flex-1 overflow-y-auto w-full py-2 px-1 scrollbar-thin">
        {mockFileSystem.map((node, i) => (
          <FileTreeNode key={i} node={node} selectedFile={selectedSandboxFile || undefined} onSelectFile={handleSelectFile} />
        ))}
      </div>
      
      {/* Footer Info */}
      <div className="p-3 border-t border-zinc-900 bg-zinc-950/30 shrink-0">
        <div className="flex items-center justify-between text-[10px] text-zinc-500 font-mono">
          <div className="flex items-center gap-1">
            <Database size={10} />
            <span>24.5 MB</span>
          </div>
          <span>142 files</span>
        </div>
      </div>
    </div>
  );
}
