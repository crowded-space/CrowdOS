import React, { useState } from 'react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { ModelProfile, ProviderType } from '@/types/crowd-os';
import { Plus, Trash2, Eye, EyeOff, CheckCircle2, AlertCircle, RefreshCw, Layers } from 'lucide-react';

export default function ModelCardsTab() {
  const { modelProfiles, addModelProfile, updateModelProfile, deleteModelProfile } = useCrowdOSStore();

  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form Fields
  const [label, setLabel] = useState('');
  const [provider, setProvider] = useState<ProviderType>('google');
  const [modelName, setModelName] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [baseUrl, setBaseUrl] = useState('');

  // UI testing state
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<Record<string, { success: boolean; msg: string }>>({});
  const [showKeyId, setShowKeyId] = useState<string | null>(null);

  const resetForm = () => {
    setLabel('');
    setProvider('google');
    setModelName('');
    setApiKey('');
    setBaseUrl('');
    setEditingId(null);
    setFormOpen(false);
  };

  const handleEdit = (prof: ModelProfile) => {
    setEditingId(prof.id);
    setLabel(prof.label);
    setProvider(prof.provider);
    setModelName(prof.modelName);
    setApiKey(prof.apiKey || '');
    setBaseUrl(prof.baseUrl || '');
    setFormOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!label || !modelName) return;

    if (editingId) {
      updateModelProfile(editingId, {
        label,
        provider,
        modelName,
        apiKey,
        baseUrl,
        apiKeyConfigured: !!apiKey
      });
    } else {
      addModelProfile({
        label,
        provider,
        modelName,
        apiKey,
        baseUrl,
        apiKeyConfigured: !!apiKey
      });
    }

    resetForm();
  };

  const testConnection = (id: string) => {
    setTestingId(id);
    setTestResult(prev => ({ ...prev, [id]: { success: false, msg: '' } }));

    // Simulate key matching server validation
    setTimeout(() => {
      setTestingId(null);
      const target = modelProfiles.find(p => p.id === id);
      const isConfigured = target?.apiKeyConfigured || target?.provider === 'google'; // mock key fallback
      
      if (isConfigured) {
        setTestResult(prev => ({
          ...prev,
          [id]: { success: true, msg: 'API channel verified. Handshake success.' }
        }));
      } else {
        setTestResult(prev => ({
          ...prev,
          [id]: { success: false, msg: 'API Key is missing or invalid. Handshake failed.' }
        }));
      }
    }, 850);
  };

  return (
    <div id="model-cards-tab" className="space-y-4 text-xs">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-zinc-200 font-semibold text-sm tracking-tight mb-0.5">Model Registers</h3>
          <p className="text-zinc-500 font-sans">Provision foundational LLM key vectors bound to target orchestration pipelines.</p>
        </div>
        {!formOpen && (
          <button
            onClick={() => setFormOpen(true)}
            className="px-2.5 py-1.5 rounded-md bg-indigo-500 hover:bg-indigo-650 text-white font-semibold flex items-center gap-1.5 transition select-none cursor-pointer focus:outline-none"
          >
            <Plus size={13} />
            <span>Add Model Profiles</span>
          </button>
        )}
      </div>

      {/* Model Profiles form fields */}
      {formOpen && (
        <form onSubmit={handleSave} className="bg-zinc-950 border border-zinc-900 rounded-lg p-4 space-y-3.5 animate-scale-in">
          <div className="flex items-center justify-between border-b border-zinc-900 pb-2 select-none">
            <span className="font-semibold text-zinc-300 font-mono text-[10.5px]">
              {editingId ? 'REWRITE MODEL CREDENTIAL VECTOR' : 'REGISTER NEW CONTEXT COMPUTE CARD'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 leading-snug">
            {/* Label */}
            <div className="space-y-1">
              <label className="text-zinc-500 block font-bold font-mono text-[10px]">PROFILE LABEL</label>
              <input
                required
                type="text"
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="e.g. Reasoning Apex"
                className="w-full bg-zinc-900 border border-zinc-800 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 rounded px-2.5 py-1.5 text-xs text-zinc-200 focus:outline-none placeholder-zinc-600"
              />
            </div>

            {/* Provider selection */}
            <div className="space-y-1">
              <label className="text-zinc-500 block font-bold font-mono text-[10px]">PROVIDER MATRIX</label>
              <select
                value={provider}
                onChange={(e) => setProvider(e.target.value as ProviderType)}
                className="w-full bg-zinc-900 border border-zinc-800 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 rounded px-2.5 py-1.5 text-xs text-zinc-200 focus:outline-none cursor-pointer"
              >
                <option value="google">Google Gemini API</option>
                <option value="anthropic">Anthropic Claude API</option>
                <option value="openai">OpenAI Matrix API</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 leading-snug">
            {/* Model Name */}
            <div className="space-y-1">
              <label className="text-zinc-500 block font-bold font-mono text-[10px]">EXACT STR MODEL NAME</label>
              <input
                required
                type="text"
                value={modelName}
                onChange={(e) => setModelName(e.target.value)}
                placeholder="e.g. gemini-2.5-pro"
                className="w-full bg-zinc-900 border border-zinc-800 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 rounded px-2.5 py-1.5 font-mono text-xs text-zinc-200 focus:outline-none placeholder-zinc-650"
              />
            </div>

            {/* Custom base URL of API router proxy */}
            <div className="space-y-1">
              <label className="text-zinc-500 block font-bold font-mono text-[10px]">BASE ENDPOINT PROXY (OPTIONAL)</label>
              <input
                type="text"
                value={baseUrl}
                onChange={(e) => setBaseUrl(e.target.value)}
                placeholder="e.g. https://api.openai.com/v1"
                className="w-full bg-zinc-900 border border-zinc-800 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 rounded px-2.5 py-1.5 text-xs text-zinc-200 focus:outline-none placeholder-zinc-650"
              />
            </div>
          </div>

          {/* API Key value Password structure */}
          <div className="space-y-1">
            <label className="text-zinc-500 block font-bold font-mono text-[10px]">API KEY SECRET TOKEN</label>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={editingId ? '••••••••••••••••••••' : 'Enter secret API connection token'}
              className="w-full bg-zinc-900 border border-zinc-800 focus:border-zinc-700 focus:ring-1 focus:ring-zinc-700/40 rounded px-2.5 py-1.5 text-xs text-zinc-200 focus:outline-none placeholder-zinc-600"
            />
          </div>

          <div className="flex justify-end gap-2 pt-1 select-none">
            <button
               type="button"
               onClick={resetForm}
               className="px-2.5 py-1.5 rounded-md border border-zinc-800 hover:bg-zinc-900 text-zinc-400 font-semibold transition select-none cursor-pointer focus:outline-none"
            >
              Cancel
            </button>
            <button
               type="submit"
               className="px-2.5 py-1.5 rounded-md bg-indigo-500 hover:bg-indigo-650 text-white font-semibold transition select-none cursor-pointer focus:outline-none"
            >
              {editingId ? 'Commit Update' : 'Initialize Register'}
            </button>
          </div>
        </form>
      )}

      {/* Profiles Roster List */}
      <div className="space-y-2">
        {modelProfiles.map(prof => {
          const result = testResult[prof.id];
          const isTesting = testingId === prof.id;

          return (
            <div 
              key={prof.id} 
              className="p-3 bg-zinc-900/30 border border-zinc-900 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-sans leading-none hover:border-zinc-800 transition"
              id={`profile-card-${prof.id}`}
            >
              <div className="space-y-1.5 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-zinc-200 text-xs truncate">
                    {prof.label}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-zinc-950 border border-zinc-800 text-[9px] font-mono text-zinc-450 uppercase uppercase">
                    {prof.provider}
                  </span>
                </div>
                <div className="text-[10px] font-mono text-zinc-500 bg-zinc-950 inline-block px-1.5 py-0.5 rounded border border-zinc-900">
                  {prof.modelName}
                </div>
                {prof.baseUrl && (
                  <div className="text-[9px] font-mono text-zinc-550 italic block truncate">
                    Base: {prof.baseUrl}
                  </div>
                )}
              </div>

              {/* Status parameters & actions */}
              <div className="flex flex-wrap items-center gap-2 select-none">
                {result && (
                  <div className={`p-1 px-2.5 rounded text-[10px] font-mono flex items-center gap-1 shrink-0 ${result.success ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20' : 'bg-rose-500/10 text-rose-300 border border-rose-500/20'}`}>
                    {result.success ? <CheckCircle2 size={11} /> : <AlertCircle size={11} />}
                    <span>{result.msg}</span>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => testConnection(prof.id)}
                  disabled={isTesting}
                  className="px-2 py-1 bg-zinc-950 hover:bg-zinc-900 border border-zinc-800 text-zinc-400 font-mono text-[9px] rounded flex items-center gap-1 cursor-pointer focus:outline-none pr-2.5"
                >
                  <RefreshCw size={10} className={isTesting ? 'animate-spin' : ''} />
                  <span>{isTesting ? 'Handshaking...' : 'Test Sync'}</span>
                </button>

                <button
                  onClick={() => handleEdit(prof)}
                  className="px-2 py-1 bg-zinc-950 hover:bg-zinc-900 border border-zinc-800 text-zinc-400 text-[10px] rounded cursor-pointer focus:outline-none"
                >
                  Edit
                </button>

                <button
                  onClick={() => {
                    if (confirm('De-register this computing model card?')) {
                      deleteModelProfile(prof.id);
                    }
                  }}
                  className="p-1 px-1.5 bg-zinc-950 hover:bg-rose-950/40 text-rose-400 border border-zinc-800 rounded hover:border-rose-900 transition cursor-pointer focus:outline-none"
                  title="De-register"
                >
                  <Trash2 size={11.5} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
