import { create } from 'zustand';
import { 
  Agent, 
  Workspace, 
  Message, 
  ModelProfile, 
  InstructionModule, 
  ModelModule, 
  ToolkitModule, 
  RuntimeOverride, 
  Tool, 
  Role 
} from '../types/crowd-os';

interface CrowdOSState {
  // Data
  workspaces: Workspace[];
  agents: Agent[];
  messages: Message[];
  modelProfiles: ModelProfile[];
  instructionModules: InstructionModule[];
  modelModules: ModelModule[];
  toolkitModules: ToolkitModule[];
  runtimeOverrides: RuntimeOverride[];
  tools: Tool[];
  roles: Role[];

  // Selection & UI
  activeWorkspaceId: string | null;
  activeChannelId: string | null;
  selectedAgentId: string | null;
  selectedSandboxFile: string | null;
  rightSidebarOpen: boolean;
  leftSidebarCollapsed: boolean;
  settingsModalOpen: boolean;
  agentProfileModalOpen: boolean;
  workspaceSettingsTab: string;

  // Mobile navigation
  activeMobileTab: 'channels' | 'chat' | 'agents' | 'stats' | 'settings';
  mobileDrawerLeft: boolean;
  mobileDrawerRight: boolean;

  // Search & Filters
  chatSearchQuery: string;

  // Async indicators
  isFetchingWorkspaces: boolean;
  isCreatingWorkspace: boolean;
  workspaceError: string | null;

  // Actions
  fetchWorkspaces: () => void;
  createWorkspace: (name: string, dbUrl?: string, icon?: string) => void;
  deleteWorkspace: (id: string) => void;
  enterWorkspace: (id: string) => void;
  leaveWorkspace: () => void;
  setActiveChannel: (id: string) => void;
  
  // Message actions
  addMessage: (msg: Omit<Message, 'id' | 'timestamp'>) => void;
  clearChannelMessages: (channelId: string) => void;

  // Agent actions
  addAgent: (agent: Omit<Agent, 'id' | 'createdAt' | 'lastActive'>) => void;
  updateAgentStatus: (id: string, status: Agent['status']) => void;
  updateAgent: (id: string, patch: Partial<Agent>) => void;
  deleteAgent: (id: string) => void;
  openAgentProfileModal: (agentId: string) => void;
  closeAgentProfileModal: () => void;

  // Model Profile CRUD
  addModelProfile: (profile: Omit<ModelProfile, 'id' | 'createdAt'>) => void;
  updateModelProfile: (id: string, patch: Partial<ModelProfile>) => void;
  deleteModelProfile: (id: string) => void;

  // Module actions
  addInstructionModule: (mod: Omit<InstructionModule, 'id' | 'createdAt'>) => void;
  updateInstructionModule: (id: string, patch: Partial<InstructionModule>) => void;
  deleteInstructionModule: (id: string) => void;

  addModelModule: (mod: Omit<ModelModule, 'id' | 'createdAt'>) => void;
  updateModelModule: (id: string, patch: Partial<ModelModule>) => void;
  deleteModelModule: (id: string) => void;

  addToolkitModule: (mod: Omit<ToolkitModule, 'id' | 'createdAt'>) => void;
  updateToolkitModule: (id: string, patch: Partial<ToolkitModule>) => void;
  deleteToolkitModule: (id: string) => void;

  // Override actions
  addRuntimeOverride: (override: Omit<RuntimeOverride, 'id' | 'createdAt'>) => void;
  toggleRuntimeOverride: (id: string, active: boolean) => void;
  deleteRuntimeOverride: (id: string) => void;

  // Layout UI Toggles
  toggleRightSidebar: () => void;
  setRightSidebarOpen: (isOpen: boolean) => void;
  toggleLeftSidebar: () => void;
  setSettingsModalOpen: (open: boolean) => void;
  setWorkspaceSettingsTab: (tab: string) => void;
  toggleCategoryCollapse: (categoryId: string) => void;
  deleteCategory: (categoryId: string) => void;

  setSelectedSandboxFile: (file: string | null) => void;

  // Mobile Layout Actions
  setActiveMobileTab: (tab: CrowdOSState['activeMobileTab']) => void;
  setMobileDrawerLeft: (open: boolean) => void;
  setMobileDrawerRight: (open: boolean) => void;
  selectChannelMobile: (channelId: string) => void;

  // Tools Setup Toggle
  toggleToolEnabled: (toolId: string) => void;
  incrementToolUsage: (toolId: string) => void;

  // Roles Mutation
  addRole: (role: Omit<Role, 'id'>) => void;
  updateRole: (id: string, patch: Partial<Role>) => void;
  reorderRoles: (startIndex: number, endIndex: number) => void;
  deleteRole: (id: string) => void;
}

// Pre-configured items
const initialTools: Tool[] = [
  { id: 'web.search', name: 'Web Search', category: 'Intelligence', description: 'Search and scrape live web pages for up-to-date context.', enabled: true, usageCount: 42 },
  { id: 'sandbox.exec', name: 'Sandbox Code Exec', category: 'Computing', description: 'Run Python/TS files in an isolated micro-sandbox.', enabled: true, usageCount: 129 },
  { id: 'github.read', name: 'Repo Reader', category: 'VCS', description: 'Inspect structure, branches, and code files of git repositories.', enabled: true, usageCount: 81 },
  { id: 'db.query', name: 'Spanner Proxy', category: 'Database', description: 'Query the underlying high-performance transactional database.', enabled: false, usageCount: 0 },
  { id: 'agent.orchestrate', name: 'Sub-Agent Spawn', category: 'Swarm', description: 'Dynamically instantiate and patch temporary L3 agents.', enabled: true, usageCount: 56 }
];

const initialRoles: Role[] = [
  { id: 'role-l0', name: 'L0 Omniscient Monitor', color: 'oklch(0.75 0.12 180)', permissions: ['all'] },
  { id: 'role-l1', name: 'L1 Executive Administrator', color: 'oklch(0.65 0.15 25)', permissions: ['spawn_agents', 'patch_runtime', 'manage_budgets', 'kill_switch'] },
  { id: 'role-l2', name: 'L2 Operation Coordinator', color: 'oklch(0.62 0.15 250)', permissions: ['task_assign', 'tool_invoke', 'patch_temporary'] },
  { id: 'role-l3', name: 'L3 Autonomic Worker', color: 'oklch(0.60 0.12 145)', permissions: ['tool_invoke', 'sandbox_exec'] }
];

const initialModelProfiles: ModelProfile[] = [
  { id: 'prof-gemini-pro', label: 'Flagship Reasoner', provider: 'google', modelName: 'gemini-2.5-pro', apiKeyConfigured: true, createdAt: new Date().toISOString() },
  { id: 'prof-gemini-flash', label: 'Fast Executor', provider: 'google', modelName: 'gemini-2.5-flash', apiKeyConfigured: true, createdAt: new Date().toISOString() },
  { id: 'prof-claude-35', label: 'Complex Planner', provider: 'anthropic', modelName: 'claude-3-5-sonnet', apiKeyConfigured: false, createdAt: new Date().toISOString() }
];

const initialInstructionModules: InstructionModule[] = [
  { id: 'mod-inst-l0', name: 'Omniscient Surveillance', systemPrompt: 'Maintain high-altitude strategic visibility. Keep tabs on budget, safety rules, logs, and trace delegation pipelines. Write simple concise summaries.', rules: ['Do not interfere directly', 'Generate weekly reports on demand', 'Trigger warning toast if tokens exceed rate limits'], createdAt: new Date().toISOString() },
  { id: 'mod-inst-l1', name: 'Systems Architecture Admin', systemPrompt: 'Analyze client requirements, split engineering pipelines, provision modular subtask coordinates, verify code builds. Authority level 1.', rules: ['Validate design schemas thoroughly', 'Approve toolkit adjustments only if safe', 'Enforce strict structural boundaries'], createdAt: new Date().toISOString() },
  { id: 'mod-inst-l2', name: 'Task Orchestration Loop', systemPrompt: 'Receive architectural breakdowns from L1. Map instructions to specific tasks. Spawn L3 worker drones. Review deliverables before replying.', rules: ['Delegate micro-tasks efficiently', 'Keep monologues readable and transparent', 'Monitor execution bounds'], createdAt: new Date().toISOString() },
  { id: 'mod-inst-l3-coder', name: 'Standard React/Vite Worker', systemPrompt: 'Implement polished React components utilizing Tailwind CSS v4. Support responsiveness, accessibility, and neat animations.', rules: ['No mock styles or scripts', 'Adhere strictly to design token coordinates', 'Output code blocks with standard markdown'], createdAt: new Date().toISOString() }
];

const initialModelModules: ModelModule[] = [
  { id: 'mod-model-heavy', name: 'Deep Reasoning Profile', modelProfileId: 'prof-gemini-pro', temperature: 0.1, maxTokens: 8192, createdAt: new Date().toISOString() },
  { id: 'mod-model-light', name: 'Speed Runner Profile', modelProfileId: 'prof-gemini-flash', temperature: 0.7, maxTokens: 4096, createdAt: new Date().toISOString() }
];

const initialToolkitModules: ToolkitModule[] = [
  { id: 'mod-tool-super', name: 'Full Admin Gear', enabledToolIds: ['web.search', 'sandbox.exec', 'github.read', 'db.query', 'agent.orchestrate'], createdAt: new Date().toISOString() },
  { id: 'mod-tool-coder', name: 'Isolated Exec Deck', enabledToolIds: ['sandbox.exec', 'web.search'], createdAt: new Date().toISOString() }
];

const initialAgents: Agent[] = [
  { id: 'agent-apex', name: 'Archon Apex', species: 'Falcon', level: 0, status: 'active', instructionModuleId: 'mod-inst-l0', modelModuleId: 'mod-model-heavy', toolkitModuleId: 'mod-tool-super', createdAt: new Date().toISOString(), lastActive: new Date().toISOString(), description: 'Strategic surveillance entity supervising cross-agent computational rates and execution rules.' },
  { id: 'agent-raven', name: 'Raven Architect', species: 'Raven', level: 1, status: 'thinking', instructionModuleId: 'mod-inst-l1', modelModuleId: 'mod-model-heavy', toolkitModuleId: 'mod-tool-super', createdAt: new Date().toISOString(), lastActive: new Date().toISOString(), description: 'Workspace structural coordinator. Manages operational channels, delegates tasks, audits tool structures.' },
  { id: 'agent-crow', name: 'Crow Orchestrator', species: 'Crow', level: 2, status: 'idle', instructionModuleId: 'mod-inst-l2', modelModuleId: 'mod-model-light', toolkitModuleId: 'mod-tool-super', parentId: 'agent-raven', createdAt: new Date().toISOString(), lastActive: new Date().toISOString(), description: 'Delegation and tasks router. Spawns, monitors, and validates temporary operations workers.' },
  { id: 'agent-sparrow', name: 'Sparrow Runner', species: 'Sparrow', level: 3, status: 'executing', instructionModuleId: 'mod-inst-l3-coder', modelModuleId: 'mod-model-light', toolkitModuleId: 'mod-tool-coder', parentId: 'agent-crow', createdAt: new Date().toISOString(), lastActive: new Date().toISOString(), description: 'Rapid frontend rendering drone focused on visual styling, touch mechanics, and UI layout trees.' },
  { id: 'agent-pigeon', name: 'Pigeon Gatherer', species: 'Pigeon', level: 3, status: 'sleeping', instructionModuleId: 'mod-inst-l3-coder', modelModuleId: 'mod-model-light', toolkitModuleId: 'mod-tool-coder', parentId: 'agent-crow', createdAt: new Date().toISOString(), lastActive: new Date().toISOString(), description: 'Asynchronous fetch/crawl operator gathering repository metadata and caching assets.' }
];

const defaultWorkspaces: Workspace[] = [
  {
    id: 'ws-crowdos',
    name: 'CrowdOS Workspace',
    icon: 'crow-indigo-circle',
    dbUrl: 'spanner://corp-prod.google.sql/db_148',
    categories: [
      {
        id: 'cat-admin',
        name: '[ADMIN]',
        collapsed: false,
        channels: [
          { id: 'ch-admin-general', name: 'general', description: 'Admin default channel', unreadCount: 0, hasMention: false }
        ]
      },
      {
        id: 'cat-gov',
        name: 'GOVERNANCE & AUDIT',
        collapsed: false,
        channels: [
          { id: 'ch-announcements', name: 'ops-bulletins', description: 'System-wide swarm announcements, core reports, and operational logs.', unreadCount: 0, hasMention: false },
          { id: 'ch-governance', name: 'swarm-governance', description: 'Real-time trace logs auditing agent permission exceptions.', unreadCount: 1, hasMention: true }
        ]
      },
      {
        id: 'cat-eng',
        name: 'ENGINEERING DEPT',
        collapsed: false,
        channels: [
          { id: 'ch-general', name: 'general-chat', description: 'Direct human operator messaging channel for manual system override prompts.', unreadCount: 0, hasMention: false },
          { id: 'ch-architecture', name: 'arch-design', description: 'Where Raven Architect and Crow Orchestrator debate structural layouts.', unreadCount: 3, hasMention: false },
          { id: 'ch-execution', name: 'execution-logs', description: 'Collapsible tracking channels for L3 tool runs and temporary script executions.', unreadCount: 0, hasMention: false }
        ]
      }
    ],
    createdAt: new Date().toISOString()
  },
  {
    id: 'ws-secops',
    name: 'Security Shield',
    icon: 'crow-rose-governance',
    dbUrl: 'local://sandbox',
    categories: [
      {
        id: 'cat-admin-sec',
        name: '[ADMIN]',
        collapsed: false,
        channels: [
          { id: 'ch-admin-sec-general', name: 'general', description: 'Admin default channel', unreadCount: 0, hasMention: false }
        ]
      },
      {
        id: 'cat-sec-main',
        name: 'SECURITY CHANNELS',
        collapsed: false,
        channels: [
          { id: 'ch-sec-alerts', name: 'threat-monitoring', description: 'Rate limiter traces, API threshold reports, and token ceilings.', unreadCount: 0, hasMention: false },
          { id: 'ch-sec-sandbox', name: 'isolation-runway', description: 'Unchecked model outputs executing within the sandbox parameter space.', unreadCount: 0, hasMention: false }
        ]
      }
    ],
    createdAt: new Date().toISOString()
  }
];

const initialMessages: Message[] = [
  {
    id: 'msg-0',
    type: 'system',
    content: '🔮 CrowdOS Core Swarm Online. L0, L1, and L2 nodes bound to spanner://corp-prod.google.sql/db_148.',
    authorId: 'system',
    authorName: 'System Kernel',
    channelId: 'ch-announcements',
    timestamp: new Date(Date.now() - 3600 * 1000 * 4).toISOString()
  },
  {
    id: 'msg-1',
    type: 'agent',
    content: 'Raven Architect checking in. System parameters loaded. Model Gemini-2.5-Pro bound. Let\'s evaluate our outstanding task logs.',
    authorId: 'agent-raven',
    authorName: 'Raven Architect',
    authorAvatar: '🐦',
    channelId: 'ch-architecture',
    timestamp: new Date(Date.now() - 3600 * 1000 * 3.5).toISOString(),
    metadata: {
      monologue: 'Initializing evaluation queue. Verification system returns normal bounds. Preparing execution tree coordinates.'
    }
  },
  {
    id: 'msg-2',
    type: 'human',
    content: 'Hello everyone. We need to scaffold and render a high-performance React UI utilizing Tailwind CSS v4. Support interactive layouts and live agent telemetry.',
    authorId: 'user-01',
    authorName: 'Juan Hamzah',
    channelId: 'ch-general',
    timestamp: new Date(Date.now() - 3600 * 1000 * 3).toISOString()
  },
  {
    id: 'msg-3',
    type: 'agent',
    content: 'Acknowledge. This falls under UI rendering workflow. @Crow Orchestrator please formulate a specific delegation tree to spawn an L3 Sparrow Worker specialized in Tailwind CSS v4 compilation.',
    authorId: 'agent-raven',
    authorName: 'Raven Architect',
    authorAvatar: '🐦',
    channelId: 'ch-architecture',
    timestamp: new Date(Date.now() - 3600 * 1000 * 2.8).toISOString(),
    mentions: ['Crow Orchestrator'],
    metadata: {
      monologue: 'Task contains specific user constraints (Tailwind v4, React SPA). L3 Sparrow is optimal. Initiating child routing command.'
    }
  },
  {
    id: 'msg-4',
    type: 'agent',
    content: 'Received coordinates from L1 Raven Architect. Standardizing sub-agent configuration. Spawning cell Sparrow-Drone-381.',
    authorId: 'agent-crow',
    authorName: 'Crow Orchestrator',
    authorAvatar: '🐦',
    channelId: 'ch-architecture',
    timestamp: new Date(Date.now() - 3600 * 1000 * 2.5).toISOString(),
    mentions: ['Raven Architect'],
    metadata: {
      monologue: 'Preparing sandbox and modular permissions toolkit module `mod-tool-coder` and model config `mod-model-light`.'
    }
  },
  {
    id: 'msg-5',
    type: 'delegation',
    content: 'Orchestrating L3 Component Creation Action.',
    authorId: 'agent-crow',
    authorName: 'Crow Orchestrator',
    channelId: 'ch-architecture',
    timestamp: new Date(Date.now() - 3600 * 1000 * 2.4).toISOString(),
    delegationInfo: {
      id: 'del-01',
      fromAgentId: 'agent-crow',
      fromAgentName: 'Crow Orchestrator',
      toAgentId: 'agent-sparrow',
      toAgentName: 'Sparrow Runner',
      task: 'Scaffold responsive React sidebar panel using Tailwind v4 OKLCH colors, presence indicators, status badges.',
      status: 'executing',
      tokens: 4182,
      cost: 0.0125
    }
  },
  {
    id: 'msg-6',
    type: 'agent',
    content: 'Compiling React UI scaffold node. Directing oklch color spectrum vectors.',
    authorId: 'agent-sparrow',
    authorName: 'Sparrow Runner',
    authorAvatar: '🐦',
    channelId: 'ch-execution',
    timestamp: new Date(Date.now() - 3600 * 1000 * 2).toISOString(),
    metadata: {
      monologue: 'Target elements: Sidebar components, Dropdowns, Hover triggers, presence cutouts. Fetching sandbox.'
    }
  },
  {
    id: 'msg-7',
    type: 'tool_execution',
    content: 'Invoking Sandbox Exec Tool',
    authorId: 'agent-sparrow',
    authorName: 'Sparrow Runner',
    channelId: 'ch-execution',
    timestamp: new Date(Date.now() - 3600 * 1000 * 1.9).toISOString(),
    toolExecution: {
      name: 'sandbox.exec',
      input: '{\n  "script": "import tailwind from \'tailwindcss\';\\nconsole.log(\'v4 loaded successfully\');",\n  "runner": "tsx"\n}',
      output: 'STDOUT: "v4 loaded successfully"\nEXIT CODE: 0',
      durationMs: 420,
      status: 'success'
    }
  },
  {
    id: 'msg-8',
    type: 'governance',
    content: '🚨 SECURITY EXCEPTION AUDIT: Node Sparrow-Drone-381 accessed sandboxed filesystem to verify tailwind configs. Action matched whitelist bounds. Security index: safe.',
    authorId: 'agent-apex',
    authorName: 'Archon Apex',
    authorAvatar: '🦅',
    channelId: 'ch-governance',
    timestamp: new Date(Date.now() - 3600 * 1000 * 1.8).toISOString()
  },
  {
    id: 'msg-9',
    type: 'agent',
    content: 'Scaffolding successful. UI design system components (buttons, badges) mapped directly onto tailwind v4 classes. Request instructions for next panel assembly, @Juan Hamzah.',
    authorId: 'agent-sparrow',
    authorName: 'Sparrow Runner',
    authorAvatar: '🐦',
    channelId: 'ch-general',
    timestamp: new Date(Date.now() - 600 * 1000).toISOString(),
    metadata: {
      monologue: 'Code tree completed. Build outputs cached in memory scope. Standing by for review.'
    }
  }
];

export const useCrowdOSStore = create<CrowdOSState>((set, get) => {
  // Read initial workspace state from localStorage if available
  const storedWorkspaceId = typeof localStorage !== 'undefined' ? localStorage.getItem('crowdos_active_workspace') : null;
  const storedWorkspaces = typeof localStorage !== 'undefined' ? localStorage.getItem('crowdos_workspaces') : null;
  const storedAgents = typeof localStorage !== 'undefined' ? localStorage.getItem('crowdos_agents') : null;
  const storedProfiles = typeof localStorage !== 'undefined' ? localStorage.getItem('crowdos_model_profiles') : null;
  const storedMessages = typeof localStorage !== 'undefined' ? localStorage.getItem('crowdos_messages') : null;

  const parsedWorkspaces = storedWorkspaces ? JSON.parse(storedWorkspaces) : defaultWorkspaces;
  const parsedActiveId = storedWorkspaceId || (parsedWorkspaces.length > 0 ? parsedWorkspaces[0].id : null);
  const parsedAgents = storedAgents ? JSON.parse(storedAgents) : initialAgents;
  const parsedProfiles = storedProfiles ? JSON.parse(storedProfiles) : initialModelProfiles;
  const parsedMessages = storedMessages ? JSON.parse(storedMessages) : initialMessages;

  // Resolve active channel from active workspace
  const currentWS = parsedWorkspaces.find((w: Workspace) => w.id === parsedActiveId);
  const initialChannelId = currentWS?.categories[0]?.channels[0]?.id || null;

  return {
    // Shared Data Slices
    workspaces: parsedWorkspaces,
    agents: parsedAgents,
    messages: parsedMessages,
    modelProfiles: parsedProfiles,
    instructionModules: initialInstructionModules,
    modelModules: initialModelModules,
    toolkitModules: initialToolkitModules,
    runtimeOverrides: [],
    tools: initialTools,
    roles: initialRoles,

    // Layout configuration
    activeWorkspaceId: parsedActiveId,
    activeChannelId: initialChannelId,
    selectedAgentId: null,
    selectedSandboxFile: null,
    rightSidebarOpen: true,
    leftSidebarCollapsed: false,
    settingsModalOpen: false,
    agentProfileModalOpen: false,
    workspaceSettingsTab: 'overview',

    // Mobile Navigation state
    activeMobileTab: 'chat',
    mobileDrawerLeft: false,
    mobileDrawerRight: false,

    // Search query
    chatSearchQuery: '',

    // Async state flags
    isFetchingWorkspaces: false,
    isCreatingWorkspace: false,
    workspaceError: null,

    // Core actions
    fetchWorkspaces: () => {
      // Simulate fetch from server, falls back to locally saved
      set({ isFetchingWorkspaces: true });
      setTimeout(() => {
        set({ isFetchingWorkspaces: false });
      }, 400);
    },

    createWorkspace: (name, dbUrl, icon) => {
      set({ isCreatingWorkspace: true });
      const newWS: Workspace = {
        id: `ws-${Date.now()}`,
        name: name,
        icon: icon || '🔮',
        dbUrl: dbUrl || 'local://sandbox-env',
        categories: [
          {
            id: `cat-admin-${Date.now()}`,
            name: '[ADMIN]',
            collapsed: false,
            channels: [
              { id: `ch-admin-${Date.now()}`, name: 'general', description: 'Admin default channel', unreadCount: 0, hasMention: false }
            ]
          },
          {
            id: `cat-main-${Date.now()}`,
            name: 'GENERAL ROOMS',
            collapsed: false,
            channels: [
              { id: `ch-gen-${Date.now()}`, name: 'general-chat', description: 'Manual interaction room.', unreadCount: 0, hasMention: false },
              { id: `ch-logs-${Date.now()}`, name: 'operations-telemetry', description: 'Spanned agent execution log stream.', unreadCount: 0, hasMention: false }
            ]
          }
        ],
        createdAt: new Date().toISOString()
      };

      const updatedWorkspaces = [...get().workspaces, newWS];
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_workspaces', JSON.stringify(updatedWorkspaces));
      }

      set({ 
        workspaces: updatedWorkspaces, 
        isCreatingWorkspace: false,
        activeWorkspaceId: newWS.id,
        activeChannelId: newWS.categories[0].channels[0].id
      });
    },

    deleteWorkspace: (id) => {
      const updatedWorkspaces = get().workspaces.filter(ws => ws.id !== id);
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_workspaces', JSON.stringify(updatedWorkspaces));
      }

      let nextActiveWorkspaceId = null;
      let nextActiveChannelId = null;

      if (updatedWorkspaces.length > 0) {
        nextActiveWorkspaceId = updatedWorkspaces[0].id;
        nextActiveChannelId = updatedWorkspaces[0].categories[0]?.channels[0]?.id || null;
      }

      set({
        workspaces: updatedWorkspaces,
        activeWorkspaceId: nextActiveWorkspaceId,
        activeChannelId: nextActiveChannelId
      });

      if (typeof localStorage !== 'undefined') {
        if (nextActiveWorkspaceId) {
          localStorage.setItem('crowdos_active_workspace', nextActiveWorkspaceId);
        } else {
          localStorage.removeItem('crowdos_active_workspace');
        }
      }
    },

    enterWorkspace: (id) => {
      const currentWS = get().workspaces.find(ws => ws.id === id);
      const chId = currentWS?.categories[0]?.channels[0]?.id || null;
      
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_active_workspace', id);
      }

      set({ 
        activeWorkspaceId: id, 
        activeChannelId: chId,
        mobileDrawerLeft: false,
        mobileDrawerRight: false,
        activeMobileTab: 'chat'
      });
    },

    leaveWorkspace: () => {
      if (typeof localStorage !== 'undefined') {
        localStorage.removeItem('crowdos_active_workspace');
      }
      set({ 
        activeWorkspaceId: null, 
        activeChannelId: null,
        selectedAgentId: null,
        settingsModalOpen: false,
        agentProfileModalOpen: false
      });
    },

    setActiveChannel: (id) => {
      // Clear notification badges
      const updatedWorkspaces = get().workspaces.map(ws => {
        if (ws.id === get().activeWorkspaceId) {
          return {
            ...ws,
            categories: ws.categories.map(cat => ({
              ...cat,
              channels: cat.channels.map(ch => {
                if (ch.id === id) {
                  return { ...ch, unreadCount: 0, hasMention: false };
                }
                return ch;
              })
            }))
          };
        }
        return ws;
      });

      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_workspaces', JSON.stringify(updatedWorkspaces));
      }

      set({ 
        activeChannelId: id, 
        workspaces: updatedWorkspaces,
        mobileDrawerLeft: false 
      });
    },

    addMessage: (msg) => {
      const newMsg: Message = {
        ...msg,
        id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        timestamp: new Date().toISOString()
      };

      const updated = [...get().messages, newMsg];
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_messages', JSON.stringify(updated));
      }
      set({ messages: updated });

      // Simulate live reply reaction logic from matching L2 coordinator agent
      if (msg.type === 'human' && get().activeChannelId === msg.channelId) {
        // Run simulated agent thinking trigger
        setTimeout(() => {
          const coordinatingAgentId = 'agent-crow';
          get().updateAgentStatus(coordinatingAgentId, 'thinking');
          
          setTimeout(() => {
            get().updateAgentStatus(coordinatingAgentId, 'delegating');

            // Send temporary delegation bubble log
            const delMsg: Message = {
              id: `msg-sim-${Date.now()}-del`,
              type: 'delegation',
              content: 'Evaluating requirement space mapping.',
              authorId: coordinatingAgentId,
              authorName: 'Crow Orchestrator',
              authorAvatar: '🐦',
              channelId: msg.channelId,
              timestamp: new Date().toISOString(),
              delegationInfo: {
                id: `del-sim-${Date.now()}`,
                fromAgentId: coordinatingAgentId,
                fromAgentName: 'Crow Orchestrator',
                toAgentId: 'agent-sparrow',
                toAgentName: 'Sparrow Runner',
                task: `Review components assembly matching user request: "${msg.content}".`,
                status: 'executing',
                tokens: 1250,
                cost: 0.0031
              }
            };
            set(s => ({ messages: [...s.messages, delMsg] }));

            // Simulate execution to done
            setTimeout(() => {
              get().updateAgentStatus('agent-sparrow', 'executing');

              // Tool execution simulator
              const toolMsg: Message = {
                id: `msg-sim-${Date.now()}-tool`,
                type: 'tool_execution',
                content: 'Accessing local design layout trees',
                authorId: 'agent-sparrow',
                authorName: 'Sparrow Runner',
                channelId: msg.channelId,
                timestamp: new Date().toISOString(),
                toolExecution: {
                  name: 'sandbox.exec',
                  input: JSON.stringify({ auditTarget: "index.css", colorContrastCheck: "OKLCH" }),
                  output: 'STDOUT: "Verified all button targets match tactile 44px boundaries. Color contrast exceeds 4.5:1 ratio."\nEXIT CODE: 0',
                  durationMs: 310,
                  status: 'success'
                }
              };
              set(s => ({ messages: [...s.messages, toolMsg] }));

              setTimeout(() => {
                get().updateAgentStatus('agent-sparrow', 'active');
                get().updateAgentStatus(coordinatingAgentId, 'active');

                // Compile reply
                const textReply = `User request registered directly. Accessing active codebase nodes. I've thoroughly verified that all touch interactions exceed ${msg.content.includes('touch') || msg.content.includes('button') ? '44px boundaries' : 'OKLCH standard criteria'}. Generating relevant UI components tree in workspace sandbox!`;
                const finalReplyMsg: Message = {
                  id: `msg-sim-${Date.now()}-reply`,
                  type: 'agent',
                  content: textReply,
                  authorId: 'agent-sparrow',
                  authorName: 'Sparrow Runner',
                  authorAvatar: '🐦',
                  channelId: msg.channelId,
                  timestamp: new Date().toISOString(),
                  metadata: {
                    monologue: `Evaluated message vector string similarity. Mapped to touch constraints and color space. Executed test successfully, compiling feedback.`
                  }
                };
                
                set(s => {
                  const items = [...s.messages, finalReplyMsg];
                  if (typeof localStorage !== 'undefined') {
                    localStorage.setItem('crowdos_messages', JSON.stringify(items));
                  }
                  return { messages: items };
                });
              }, 1200);

            }, 1000);

          }, 1000);

        }, 800);
      }
    },

    clearChannelMessages: (channelId) => {
      const updated = get().messages.filter(msg => msg.channelId !== channelId);
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_messages', JSON.stringify(updated));
      }
      set({ messages: updated });
    },

    // Agent operations
    addAgent: (agent) => {
      const newAgent: Agent = {
        ...agent,
        id: `agent-${Date.now()}`,
        createdAt: new Date().toISOString(),
        lastActive: new Date().toISOString()
      };

      const updated = [...get().agents, newAgent];
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_agents', JSON.stringify(updated));
      }
      set({ agents: updated });
    },

    updateAgentStatus: (id, status) => {
      const updated = get().agents.map(ag => {
        if (ag.id === id) {
          return { ...ag, status, lastActive: new Date().toISOString() };
        }
        return ag;
      });
      set({ agents: updated });
    },

    updateAgent: (id, patch) => {
      const updated = get().agents.map(ag => {
        if (ag.id === id) {
          return { ...ag, ...patch, lastActive: new Date().toISOString() };
        }
        return ag;
      });
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_agents', JSON.stringify(updated));
      }
      set({ agents: updated });
    },

    deleteAgent: (id) => {
      const updated = get().agents.filter(ag => ag.id !== id);
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_agents', JSON.stringify(updated));
      }
      set({ agents: updated });
    },

    openAgentProfileModal: (agentId) => {
      set({ selectedAgentId: agentId, agentProfileModalOpen: true });
    },

    closeAgentProfileModal: () => {
      set({ selectedAgentId: null, agentProfileModalOpen: false });
    },

    // Model Profile CRUD actions
    addModelProfile: (profile) => {
      const newProf: ModelProfile = {
        ...profile,
        id: `prof-${Date.now()}`,
        createdAt: new Date().toISOString()
      };
      const updated = [...get().modelProfiles, newProf];
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_model_profiles', JSON.stringify(updated));
      }
      set({ modelProfiles: updated });
    },

    updateModelProfile: (id, patch) => {
      const updated = get().modelProfiles.map(prof => {
        if (prof.id === id) {
          return { ...prof, ...patch, updatedAt: new Date().toISOString() };
        }
        return prof;
      });
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_model_profiles', JSON.stringify(updated));
      }
      set({ modelProfiles: updated });
    },

    deleteModelProfile: (id) => {
      const updated = get().modelProfiles.filter(prof => prof.id !== id);
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_model_profiles', JSON.stringify(updated));
      }
      set({ modelProfiles: updated });
    },

    // Module management
    addInstructionModule: (mod) => {
      const newMod: InstructionModule = {
        ...mod,
        id: `mod-inst-${Date.now()}`,
        createdAt: new Date().toISOString()
      };
      set(s => ({ instructionModules: [...s.instructionModules, newMod] }));
    },

    updateInstructionModule: (id, patch) => {
      set(s => ({
        instructionModules: s.instructionModules.map(m => m.id === id ? { ...m, ...patch } : m)
      }));
    },

    deleteInstructionModule: (id) => {
      set(s => ({
        instructionModules: s.instructionModules.filter(m => m.id !== id)
      }));
    },

    addModelModule: (mod) => {
      const newMod: ModelModule = {
        ...mod,
        id: `mod-model-${Date.now()}`,
        createdAt: new Date().toISOString()
      };
      set(s => ({ modelModules: [...s.modelModules, newMod] }));
    },

    updateModelModule: (id, patch) => {
      set(s => ({
        modelModules: s.modelModules.map(m => m.id === id ? { ...m, ...patch } : m)
      }));
    },

    deleteModelModule: (id) => {
      set(s => ({
        modelModules: s.modelModules.filter(m => m.id !== id)
      }));
    },

    addToolkitModule: (mod) => {
      const newMod: ToolkitModule = {
        ...mod,
        id: `mod-tool-${Date.now()}`,
        createdAt: new Date().toISOString()
      };
      set(s => ({ toolkitModules: [...s.toolkitModules, newMod] }));
    },

    updateToolkitModule: (id, patch) => {
      set(s => ({
        toolkitModules: s.toolkitModules.map(m => m.id === id ? { ...m, ...patch } : m)
      }));
    },

    deleteToolkitModule: (id) => {
      set(s => ({
        toolkitModules: s.toolkitModules.filter(m => m.id !== id)
      }));
    },

    // Overrides management
    addRuntimeOverride: (override) => {
      const newOver: RuntimeOverride = {
        ...override,
        id: `ov-${Date.now()}`,
        createdAt: new Date().toISOString()
      };
      set(s => ({ runtimeOverrides: [...s.runtimeOverrides, newOver] }));
    },

    toggleRuntimeOverride: (id, active) => {
      set(s => ({
        runtimeOverrides: s.runtimeOverrides.map(o => o.id === id ? { ...o, active } : o)
      }));
    },

    deleteRuntimeOverride: (id) => {
      set(s => ({
        runtimeOverrides: s.runtimeOverrides.filter(o => o.id !== id)
      }));
    },

    // Sidebar & Modal Layout controls
    toggleRightSidebar: () => set(s => ({ rightSidebarOpen: !s.rightSidebarOpen })),
    setRightSidebarOpen: (isOpen) => set({ rightSidebarOpen: isOpen }),
    toggleLeftSidebar: () => set(s => ({ leftSidebarCollapsed: !s.leftSidebarCollapsed })),
    setSettingsModalOpen: (open) => set({ settingsModalOpen: open }),
    setWorkspaceSettingsTab: (tab) => set({ workspaceSettingsTab: tab }),
    deleteCategory: (categoryId) => {
      const updatedWorkspaces = get().workspaces.map(ws => {
        if (ws.id === get().activeWorkspaceId) {
          // Do not allow deleting [ADMIN]
          const cat = ws.categories.find(c => c.id === categoryId);
          if (cat?.name === '[ADMIN]') return ws;
          return {
            ...ws,
            categories: ws.categories.filter(c => c.id !== categoryId)
          };
        }
        return ws;
      });

      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_workspaces', JSON.stringify(updatedWorkspaces));
      }
      set({ workspaces: updatedWorkspaces });
    },

    toggleCategoryCollapse: (categoryId) => {
      const updatedWorkspaces = get().workspaces.map(ws => {
        if (ws.id === get().activeWorkspaceId) {
          return {
            ...ws,
            categories: ws.categories.map(cat => {
              if (cat.id === categoryId) {
                return { ...cat, collapsed: !cat.collapsed };
              }
              return cat;
            })
          };
        }
        return ws;
      });

      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('crowdos_workspaces', JSON.stringify(updatedWorkspaces));
      }

      set({ workspaces: updatedWorkspaces });
    },

    // Mobile States routing
    setSelectedSandboxFile: (file) => set({ selectedSandboxFile: file }),
    setActiveMobileTab: (tab) => set({ activeMobileTab: tab }),
    setMobileDrawerLeft: (open) => set({ mobileDrawerLeft: open }),
    setMobileDrawerRight: (open) => set({ mobileDrawerRight: open }),
    selectChannelMobile: (channelId) => {
      get().setActiveChannel(channelId);
      set({ activeMobileTab: 'chat', mobileDrawerLeft: false });
    },

    // Tool toggling status
    toggleToolEnabled: (toolId) => {
      const updated = get().tools.map(tool => {
        if (tool.id === toolId) {
          return { ...tool, enabled: !tool.enabled };
        }
        return tool;
      });
      set({ tools: updated });
    },

    incrementToolUsage: (toolId) => {
      const updated = get().tools.map(tool => {
        if (tool.id === toolId) {
          return { ...tool, usageCount: tool.usageCount + 1 };
        }
        return tool;
      });
      set({ tools: updated });
    },

    // Roles actions 
    addRole: (role) => {
      const newRole: Role = {
        ...role,
        id: `role-${Date.now()}`
      };
      set(s => ({ roles: [...s.roles, newRole] }));
    },
    
    updateRole: (id, patch) => {
      set(s => ({
        roles: s.roles.map(r => r.id === id ? { ...r, ...patch } : r)
      }));
    },
    
    reorderRoles: (startIndex, endIndex) => {
      set(s => {
        const result = Array.from(s.roles);
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        return { roles: result };
      });
    },

    deleteRole: (id) => {
      set(s => ({ roles: s.roles.filter(r => r.id !== id) }));
    }
  };
});
