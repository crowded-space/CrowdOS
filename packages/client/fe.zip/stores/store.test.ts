import { afterEach, describe, it, expect, beforeEach, vi } from 'vitest';

// Mock socket.io-client to prevent real network connections
vi.mock('socket.io-client', () => {
  return {
    io: () => ({
      on: vi.fn(),
      off: vi.fn(),
      emit: vi.fn(),
      connect: vi.fn(),
      disconnect: vi.fn(),
    }),
  };
});

// Mock window/localStorage
const localStorageStore: Record<string, string> = {};
const localStorageMock = {
  getItem: vi.fn((key: string) => localStorageStore[key] || null),
  setItem: vi.fn((key: string, value: string) => {
    localStorageStore[key] = value.toString();
  }),
  removeItem: vi.fn((key: string) => {
    delete localStorageStore[key];
  }),
  clear: vi.fn(() => {
    for (const key in localStorageStore) {
      delete localStorageStore[key];
    }
  }),
};

Object.defineProperty(global, 'localStorage', {
  value: localStorageMock,
  writable: true,
});

describe('useCrowdOSStore Zustand Store Tests', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it('should initialize with default workspaces', async () => {
    vi.resetModules();
    const { useCrowdOSStore } = await import('./crowd-os-store');
    const state = useCrowdOSStore.getState();

    expect(state.workspaces).toBeDefined();
    expect(state.workspaces.length).toBeGreaterThan(0);
    expect(state.workspaces[0].id).toBe('crowdos');
    expect(state.activeWorkspaceId).toBe('crowdos');
  });

  it('should perform localStorage ws-crowdos -> crowdos auto-migration', async () => {
    localStorage.setItem('crowdos_active_workspace', 'ws-crowdos');
    localStorage.setItem(
      'crowdos_workspaces',
      JSON.stringify([{ id: 'ws-crowdos', name: 'CrowdOS Workspace', icon: 'crow-indigo-circle', categories: [] }])
    );

    // Reset module registry and dynamically import to evaluate with the mock state
    vi.resetModules();
    const { useCrowdOSStore } = await import('./crowd-os-store');
    const state = useCrowdOSStore.getState();

    expect(state.activeWorkspaceId).toBe('crowdos');
    expect(state.workspaces[0].id).toBe('crowdos');
    expect(localStorage.getItem('crowdos_active_workspace')).toBe('crowdos');
  });

  it('should handle mobile navigation drawer toggle actions', async () => {
    vi.resetModules();
    const { useCrowdOSStore } = await import('./crowd-os-store');
    const store = useCrowdOSStore;

    // Toggle Left Drawer
    store.getState().setMobileDrawerLeft(true);
    expect(store.getState().mobileDrawerLeft).toBe(true);

    store.getState().setMobileDrawerLeft(false);
    expect(store.getState().mobileDrawerLeft).toBe(false);

    // Toggle Right Drawer
    store.getState().setMobileDrawerRight(true);
    expect(store.getState().mobileDrawerRight).toBe(true);
  });

  it('should not mutate ModelModule state when backend delete is rejected', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(
      JSON.stringify({ message: 'ModelModule is still used by agent "Raven".' }),
      {
        status: 409,
        headers: { 'Content-Type': 'application/json' },
      },
    )));

    vi.resetModules();
    const { useCrowdOSStore } = await import('./crowd-os-store');
    const store = useCrowdOSStore;
    const target = store.getState().modelModules[0];
    const initialIds = store.getState().modelModules.map(module => module.id);

    await expect(store.getState().deleteModelModule(target.id)).rejects.toThrow('still used by agent');
    expect(store.getState().modelModules.map(module => module.id)).toEqual(initialIds);
  });
});
