﻿import { io } from "socket.io-client";

// Connect to Fastify Socket.io backend server
export const socket = io("http://localhost:3001", {
  autoConnect: true,
  withCredentials: true,
  transports: ["websocket", "polling"]
});
