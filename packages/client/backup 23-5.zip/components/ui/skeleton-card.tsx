'use client';

interface SkeletonCardProps {
  lines?: number;
  avatar?: boolean;
}

export function SkeletonCard({ lines = 3, avatar = false }: SkeletonCardProps) {
  return (
    <div className="bg-card rounded-lg border border-border p-4 space-y-3 animate-skeleton" aria-hidden="true">
      {avatar && (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-muted" />
          <div className="space-y-2 flex-1">
            <div className="h-3 bg-muted rounded w-1/3" />
            <div className="h-2.5 bg-muted rounded w-1/4" />
          </div>
        </div>
      )}
      {Array.from({ length: lines }).map((_, i) => {
        const widths = ['w-3/4', 'w-full', 'w-2/3', 'w-5/6', 'w-1/2'];
        return (
          <div
            key={i}
            className={`h-2.5 bg-muted rounded ${widths[i % widths.length]}`}
          />
        );
      })}
    </div>
  );
}

export function MessageSkeleton() {
  return (
    <div className="flex gap-3 px-4 py-2 animate-fade-in-up animate-skeleton" aria-hidden="true">
      <div className="w-10 h-10 rounded-full bg-muted shrink-0" />
      <div className="flex-1 space-y-2">
        <div className="flex items-center gap-2">
          <div className="h-3 bg-muted rounded w-24" />
          <div className="h-2 bg-muted rounded w-16" />
        </div>
        <div className="space-y-1.5">
          <div className="h-2.5 bg-muted rounded w-full" />
          <div className="h-2.5 bg-muted rounded w-3/4" />
          <div className="h-2.5 bg-muted rounded w-1/2" />
        </div>
      </div>
    </div>
  );
}

export function ChannelListSkeleton() {
  return (
    <div className="px-2.5 pt-4 space-y-5 animate-fade-in-up" aria-hidden="true">
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="space-y-1">
          <div className="h-3 bg-muted rounded w-24 mb-2" />
          {Array.from({ length: 3 }).map((_, j) => (
            <div key={j} className="flex items-center gap-2 px-2.5 py-2">
              <div className="w-4 h-4 rounded bg-muted" />
              <div className={`h-2.5 bg-muted rounded flex-1 ${['max-w-[60%]', 'max-w-[75%]', 'max-w-[80%]'][j % 3]}`} />
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

export function StatSkeleton() {
  return (
    <div className="grid grid-cols-2 gap-2.5 p-4" aria-hidden="true">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="rounded-lg p-3 bg-card border border-border space-y-2">
          <div className="h-2.5 bg-muted rounded w-12" />
          <div className="h-5 bg-muted rounded w-16" />
        </div>
      ))}
    </div>
  );
}
