'use client';

import { useState, useEffect } from 'react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Spinner } from '@/components/ui/spinner';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Database,
  Trash2,
  Plus,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Server,
} from 'lucide-react';

export function WorkspacePortal() {
  const {
    workspaces,
    isFetchingWorkspaces,
    isCreatingWorkspace,
    fetchWorkspaces,
    createWorkspace,
    deleteWorkspace,
    enterWorkspace,
  } = useCrowdOSStore();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [dbUrl, setDbUrl] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('🌐');
  const [connectionTestState, setConnectionTestState] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [connectionTestError, setConnectionTestError] = useState<string | null>(null);
  const [deleteConfirmState, setDeleteConfirmState] = useState<Record<string, number>>({});

  const emojis = ['🌐', '🚀', '💻', '🧠', '🛡️', '📊', '⚡', '🧬', '🔮', '📡', '🤖', '🎨'];

  useEffect(() => { fetchWorkspaces(); }, [fetchWorkspaces]);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      setDeleteConfirmState((prev) => {
        const next = { ...prev };
        let changed = false;
        Object.entries(next).forEach(([id, time]) => {
          if (now - time > 3000) { delete next[id]; changed = true; }
        });
        return changed ? next : prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleTestConnection = async () => {
    if (!dbUrl) {
      setConnectionTestState('error');
      setConnectionTestError('Database URL is required to test connection.');
      return;
    }
    setConnectionTestState('testing');
    setConnectionTestError(null);
    try {
      const response = await fetch('http://localhost:3001/api/workspaces/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dbUrl }),
      });
      if (response.ok) { setConnectionTestState('success'); }
      else { const data = await response.json(); throw new Error(data.error || 'Connection failed.'); }
    } catch (e: any) {
      console.warn('Backend offline, simulating locally:', e);
      await new Promise((resolve) => setTimeout(resolve, 1200));
      const pgRegex = /^postgres(ql)?:\/\/([^:]+)(?::[^@]+)?@([^/]+)\/(.+)$/;
      if (pgRegex.test(dbUrl.trim())) { setConnectionTestState('success'); }
      else {
        setConnectionTestState('error');
        setConnectionTestError('Invalid connection string. Must match postgresql://user:pass@host:port/database');
      }
    }
  };

  const handleCreateWorkspace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !dbUrl) return;
    await createWorkspace(name, dbUrl, selectedEmoji);
    setName(''); setDbUrl(''); setSelectedEmoji('🌐');
    setConnectionTestState('idle'); setConnectionTestError(null);
    setIsModalOpen(false);
  };

  const handleDeleteClick = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const now = Date.now();
    const lastClick = deleteConfirmState[id];
    if (lastClick && now - lastClick <= 3000) {
      deleteWorkspace(id);
      setDeleteConfirmState((prev) => { const next = { ...prev }; delete next[id]; return next; });
    } else {
      setDeleteConfirmState((prev) => ({ ...prev, [id]: now }));
    }
  };

  function parseDbUrl(url?: string) {
    if (!url) return 'Local Cache';
    try {
      const match = url.match(/postgres(?:ql)?:\/\/([^:]+)(?::[^@]+)?@([^\/]+)\/(.+)$/);
      if (match) { const [, , host, dbname] = match; return dbname + ' \u00b7 ' + host.split(':')[0]; }
      const u = new URL(url);
      return u.pathname.replace(/^\//, '') + ' \u00b7 ' + u.hostname;
    } catch {
      return url.length > 28 ? url.substring(0, 28) + '\u2026' : url;
    }
  }

  return (
    <div
      className="relative flex flex-col items-center justify-center min-h-screen w-full overflow-hidden px-6 md:px-10"
      style={{ backgroundColor: '#09090b' }}
    >
      {/* ── Subtle Brand Glow ── */}
      <div
        className="absolute top-[-20%] left-1/2 -translate-x-1/2 w-[80vw] h-[50vh] rounded-full pointer-events-none opacity-30"
        style={{ background: 'radial-gradient(ellipse at center, rgba(99,102,241,0.15) 0%, transparent 70%)' }}
      />

      {/* ── Sigil + Wordmark Hero ── */}
      <div className="z-10 flex flex-col items-center mb-16 text-center animate-in fade-in slide-in-from-bottom-4 duration-700">
        {/* Crow Sigil */}
        <div className="relative mb-6">
          <img
            src="/icon_only_dark.png"
            alt="CrowdOS Sigil"
            className="w-20 h-20 md:w-24 md:h-24 object-contain rounded-2xl"
            style={{
              filter: 'drop-shadow(0 0 30px rgba(99,102,241,0.15))',
            }}
          />
        </div>

        {/* Wordmark */}
        <h1
          className="text-[2.5rem] md:text-[3.25rem] font-bold tracking-tight leading-none mb-3"
          style={{ fontFamily: "'Geist', sans-serif" }}
        >
          <span style={{ color: '#fafafa' }}>Crow</span>
          <span style={{ color: '#6366f1' }}>d</span>
          <span style={{ color: '#a1a1aa' }}>{' '}OS</span>
        </h1>

        {/* Official Tagline */}
        <p
          className="text-[11px] md:text-xs font-semibold tracking-[0.25em] uppercase"
          style={{ color: '#52525b' }}
        >
          Intelligence · Coordination · Impact
        </p>
      </div>

      {/* ── Dashboard Section ── */}
      <div className="z-10 w-full max-w-4xl animate-in fade-in slide-in-from-bottom-6 delay-150 duration-700">
        {isFetchingWorkspaces ? (
          <div className="flex flex-col items-center justify-center py-24 space-y-4">
            <Spinner className="w-6 h-6" style={{ color: '#6366f1' }} />
            <p className="text-sm" style={{ color: '#71717a' }}>Connecting to servers…</p>
          </div>

        ) : workspaces.length === 0 ? (
          /* ── Empty / First-Time Onboarding ── */
          <div className="flex flex-col items-center text-center max-w-lg mx-auto space-y-8">
            {/* Icon with glow ring */}
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, rgba(99,102,241,0.12) 0%, rgba(99,102,241,0.04) 100%)',
                border: '1px solid rgba(99,102,241,0.2)',
              }}
            >
              <Database className="w-7 h-7" style={{ color: '#6366f1' }} />
            </div>

            <div className="space-y-3">
              <h2
                className="text-2xl font-bold tracking-tight"
                style={{ color: '#fafafa' }}
              >
                Deploy your first server
              </h2>
              <p
                className="text-sm leading-relaxed max-w-md mx-auto"
                style={{ color: '#71717a' }}
              >
                Each workspace runs on its own PostgreSQL instance.
                Connect a database to bootstrap your agents, channels, and modules.
              </p>
            </div>

            <Button
              onClick={() => setIsModalOpen(true)}
              className="h-11 px-6 rounded-lg font-semibold text-sm transition-all duration-200 hover:shadow-[0_0_20px_rgba(99,102,241,0.25)] active:scale-[0.98]"
              style={{
                backgroundColor: '#6366f1',
                color: '#fafafa',
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Connect Database
            </Button>

            {/* Subtle hint */}
            <p className="text-[11px]" style={{ color: '#3f3f46' }}>
              Supports PostgreSQL 14+ with pgvector extension
            </p>
          </div>

        ) : (
          /* ── Server Grid (Has Workspaces) ── */
          <div className="space-y-6">
            {/* Section Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Server className="w-4 h-4" style={{ color: '#6366f1' }} />
                <span
                  className="text-xs font-bold tracking-[0.15em] uppercase"
                  style={{ color: '#52525b' }}
                >
                  Servers
                </span>
                <span
                  className="text-xs font-medium tabular-nums ml-1"
                  style={{ color: '#3f3f46' }}
                >
                  {workspaces.length}
                </span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsModalOpen(true)}
                className="h-8 px-3 rounded-lg text-xs font-semibold transition-colors"
                style={{ color: '#a1a1aa' }}
              >
                <Plus className="w-3.5 h-3.5 mr-1.5" />
                Add
              </Button>
            </div>

            {/* Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {workspaces.map((ws) => {
                const isDeletePending = !!deleteConfirmState[ws.id];
                return (
                  <button
                    key={ws.id}
                    onClick={() => enterWorkspace(ws.id)}
                    className="group relative text-left rounded-xl p-5 transition-all duration-250 cursor-pointer outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 focus-visible:ring-offset-2 focus-visible:ring-offset-black"
                    style={{
                      backgroundColor: '#0a0a0c',
                      border: '1px solid #1c1c22',
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(99,102,241,0.35)';
                      (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 0 24px rgba(99,102,241,0.06)';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLButtonElement).style.borderColor = '#1c1c22';
                      (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none';
                    }}
                  >
                    {/* Top row */}
                    <div className="flex items-start justify-between mb-5">
                      <div
                        className="text-2xl w-11 h-11 rounded-xl flex items-center justify-center transition-transform group-hover:scale-105"
                        style={{
                          backgroundColor: '#18181b',
                          border: '1px solid #27272a',
                        }}
                      >
                        {ws.icon || '🌐'}
                      </div>

                      <div
                        role="button"
                        tabIndex={0}
                        onClick={(e) => handleDeleteClick(e, ws.id)}
                        onKeyDown={(e) => { if (e.key === 'Enter') handleDeleteClick(e as any, ws.id); }}
                        className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors cursor-pointer"
                        style={{
                          backgroundColor: isDeletePending ? 'rgba(239,68,68,0.1)' : 'transparent',
                          border: isDeletePending ? '1px solid rgba(239,68,68,0.3)' : '1px solid transparent',
                          color: isDeletePending ? '#ef4444' : '#3f3f46',
                        }}
                        onMouseEnter={(e) => {
                          if (!isDeletePending) {
                            (e.currentTarget as HTMLDivElement).style.backgroundColor = '#18181b';
                            (e.currentTarget as HTMLDivElement).style.color = '#ef4444';
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (!isDeletePending) {
                            (e.currentTarget as HTMLDivElement).style.backgroundColor = 'transparent';
                            (e.currentTarget as HTMLDivElement).style.color = '#3f3f46';
                          }
                        }}
                        title={isDeletePending ? 'Click again to confirm' : 'Delete'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </div>
                    </div>

                    {/* Info */}
                    <div className="space-y-1.5 mb-4">
                      <h3
                        className="font-semibold text-[15px] truncate transition-colors"
                        style={{ color: '#fafafa' }}
                      >
                        {ws.name}
                      </h3>
                      <div className="flex items-center gap-1.5">
                        <Database className="w-3 h-3 shrink-0" style={{ color: '#6366f1' }} />
                        <span className="text-xs truncate" style={{ color: '#52525b' }}>
                          {parseDbUrl(ws.dbUrl)}
                        </span>
                      </div>
                    </div>

                    {/* Footer */}
                    <div
                      className="flex items-center justify-between pt-3 text-xs"
                      style={{ borderTop: '1px solid #18181b' }}
                    >
                      <Badge
                        variant="outline"
                        className="py-0 px-2 h-5 rounded-full text-[10px] font-bold uppercase tracking-wider"
                        style={{
                          backgroundColor: 'rgba(34,197,94,0.06)',
                          color: '#4ade80',
                          borderColor: 'rgba(34,197,94,0.15)',
                        }}
                      >
                        Online
                      </Badge>
                      <span
                        className="flex items-center gap-1 font-medium transition-all group-hover:translate-x-0.5"
                        style={{ color: '#52525b' }}
                      >
                        Enter
                        <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </button>
                );
              })}

              {/* Add Card */}
              <button
                onClick={() => setIsModalOpen(true)}
                className="group flex flex-col items-center justify-center rounded-xl h-full min-h-[180px] transition-all duration-250 cursor-pointer outline-none"
                style={{
                  border: '1.5px dashed #27272a',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(99,102,241,0.4)';
                  (e.currentTarget as HTMLButtonElement).style.backgroundColor = 'rgba(99,102,241,0.03)';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = '#27272a';
                  (e.currentTarget as HTMLButtonElement).style.backgroundColor = 'transparent';
                }}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center mb-3 transition-transform group-hover:scale-105"
                  style={{
                    backgroundColor: '#18181b',
                    border: '1px solid #27272a',
                    color: '#52525b',
                  }}
                >
                  <Plus className="w-5 h-5" />
                </div>
                <span
                  className="text-sm font-medium transition-colors"
                  style={{ color: '#52525b' }}
                >
                  Add Server
                </span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ── Create Workspace Modal ── */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent
          className="max-w-md sm:max-w-lg shadow-2xl rounded-xl"
          style={{
            backgroundColor: '#0a0a0c',
            border: '1px solid #1c1c22',
            color: '#fafafa',
          }}
        >
          <DialogHeader>
            <DialogTitle className="text-lg font-bold flex items-center gap-2.5" style={{ color: '#fafafa' }}>
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                style={{
                  background: 'linear-gradient(135deg, rgba(99,102,241,0.15) 0%, rgba(99,102,241,0.05) 100%)',
                  border: '1px solid rgba(99,102,241,0.2)',
                }}
              >
                <Database className="w-4 h-4" style={{ color: '#6366f1' }} />
              </div>
              New Server
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm" style={{ color: '#71717a' }}>
              Connect an independent PostgreSQL database to bootstrap a new workspace.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreateWorkspace} className="space-y-5 pt-1">
            {/* Emoji Picker */}
            <div className="space-y-2">
              <Label className="text-[11px] font-bold tracking-[0.15em] uppercase" style={{ color: '#52525b' }}>
                Icon
              </Label>
              <div
                className="grid grid-cols-6 gap-1.5 p-2 rounded-lg"
                style={{ backgroundColor: '#09090b', border: '1px solid #1c1c22' }}
              >
                {emojis.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => setSelectedEmoji(emoji)}
                    className="text-xl p-1.5 rounded-lg transition-all duration-150 focus:outline-none"
                    style={{
                      backgroundColor: selectedEmoji === emoji ? 'rgba(99,102,241,0.12)' : 'transparent',
                      border: selectedEmoji === emoji ? '1px solid rgba(99,102,241,0.35)' : '1px solid transparent',
                      transform: selectedEmoji === emoji ? 'scale(1.08)' : 'scale(1)',
                    }}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            {/* Name */}
            <div className="space-y-2">
              <Label htmlFor="ws-name" className="text-[11px] font-bold tracking-[0.15em] uppercase" style={{ color: '#52525b' }}>
                Server Name
              </Label>
              <Input
                id="ws-name"
                required
                placeholder="e.g. Production Swarm"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-10 rounded-lg text-sm"
                style={{
                  backgroundColor: '#09090b',
                  border: '1px solid #27272a',
                  color: '#fafafa',
                }}
              />
            </div>

            {/* DB URL */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="ws-db-url" className="text-[11px] font-bold tracking-[0.15em] uppercase" style={{ color: '#52525b' }}>
                  Database URL
                </Label>
                <button
                  type="button"
                  onClick={handleTestConnection}
                  disabled={connectionTestState === 'testing' || !dbUrl}
                  className="text-[11px] font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-40 focus:outline-none"
                  style={{ color: '#6366f1' }}
                >
                  {connectionTestState === 'testing' && <Spinner className="w-3 h-3" style={{ color: '#6366f1' }} />}
                  {connectionTestState === 'success' && <CheckCircle2 className="w-3 h-3" style={{ color: '#4ade80' }} />}
                  {connectionTestState === 'error' && <AlertTriangle className="w-3 h-3" style={{ color: '#ef4444' }} />}
                  Test
                </button>
              </div>
              <Input
                id="ws-db-url"
                required
                type="text"
                placeholder="postgresql://user:password@host:5432/dbname"
                value={dbUrl}
                onChange={(e) => {
                  setDbUrl(e.target.value);
                  if (connectionTestState !== 'idle') { setConnectionTestState('idle'); setConnectionTestError(null); }
                }}
                className="h-10 rounded-lg text-sm font-mono"
                style={{
                  backgroundColor: '#09090b',
                  border: connectionTestState === 'success'
                    ? '1px solid rgba(34,197,94,0.4)'
                    : connectionTestState === 'error'
                    ? '1px solid rgba(239,68,68,0.4)'
                    : '1px solid #27272a',
                  color: '#fafafa',
                }}
              />

              {connectionTestState === 'success' && (
                <div
                  className="flex items-center gap-2 text-xs p-2.5 rounded-lg animate-in fade-in duration-200"
                  style={{
                    backgroundColor: 'rgba(34,197,94,0.06)',
                    border: '1px solid rgba(34,197,94,0.15)',
                    color: '#4ade80',
                  }}
                >
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  Connection verified — database is schema-ready.
                </div>
              )}

              {connectionTestState === 'error' && (
                <div
                  className="flex items-start gap-2 text-xs p-2.5 rounded-lg animate-in fade-in duration-200"
                  style={{
                    backgroundColor: 'rgba(239,68,68,0.06)',
                    border: '1px solid rgba(239,68,68,0.15)',
                    color: '#f87171',
                  }}
                >
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{connectionTestError}</span>
                </div>
              )}
            </div>

            {/* Actions */}
            <DialogFooter className="gap-2 sm:gap-0 pt-1">
              <Button
                type="button"
                variant="ghost"
                onClick={() => setIsModalOpen(false)}
                className="rounded-lg text-sm"
                style={{ color: '#71717a' }}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isCreatingWorkspace}
                className="rounded-lg text-sm font-semibold h-10 px-5 transition-all duration-200 hover:shadow-[0_0_20px_rgba(99,102,241,0.2)] active:scale-[0.98]"
                style={{
                  backgroundColor: '#6366f1',
                  color: '#fafafa',
                }}
              >
                {isCreatingWorkspace ? (
                  <>
                    <Spinner className="mr-2 w-4 h-4" />
                    Creating…
                  </>
                ) : (
                  'Create Server'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
