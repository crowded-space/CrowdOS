﻿'use client';

import { useState, useRef, useEffect } from 'react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import {
  ChevronDown,
  Settings,
  FolderPlus,
  Hash,
  Copy,
  LogOut,
} from 'lucide-react';

interface MenuItem {
  label: string;
  icon: React.ReactNode;
  onClick?: () => void;
  danger?: boolean;
  divider?: boolean;
}

export function WorkspaceDropdown() {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const { workspaces, activeWorkspaceId, openSettingsModal, leaveWorkspace } = useCrowdOSStore();

  const workspace = workspaces.find((ws) => ws.id === activeWorkspaceId);

  useEffect(() => {
    function handleOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  if (!workspace) return null;

  const menuItems: MenuItem[] = [
    { label: 'Workspace Settings',    icon: <Settings className="w-5 h-5" />,   onClick: () => { openSettingsModal(); setIsOpen(false); } },
    { label: 'Create Channel',        icon: <Hash className="w-5 h-5" />,       onClick: () => { setIsOpen(false); } },
    { label: 'Create Category',       icon: <FolderPlus className="w-5 h-5" />, onClick: () => { setIsOpen(false); } },
    { label: '', icon: null, divider: true },
    { label: 'Copy Workspace ID',     icon: <Copy className="w-5 h-5" />,       onClick: () => { navigator.clipboard.writeText(workspace.id); setIsOpen(false); } },
    { label: '', icon: null, divider: true },
    { label: 'Leave Workspace',       icon: <LogOut className="w-5 h-5" />,     onClick: () => { leaveWorkspace(); setIsOpen(false); }, danger: true },
  ];

  return (
    <div ref={dropdownRef} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-4 h-16 transition-colors"
        style={{
          backgroundColor: isOpen ? 'var(--accent)' : 'transparent',
        }}
        onMouseEnter={(e) => {
          if (!isOpen) (e.currentTarget as HTMLButtonElement).style.backgroundColor = 'var(--sidebar-accent)';
        }}
        onMouseLeave={(e) => {
          if (!isOpen) (e.currentTarget as HTMLButtonElement).style.backgroundColor = 'transparent';
        }}
      >
        <div className="flex items-center gap-3 min-w-0">
          <img
            src="/icon_only_dark.png"
            alt=""
            className="w-8 h-8 rounded-lg object-cover shrink-0"
          />
          <span className="font-bold text-[16px] truncate text-foreground">
            {workspace.name}
          </span>
        </div>
        <ChevronDown
          className={`w-5 h-5 text-muted-foreground shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      {/* Dropdown menu */}
      {isOpen && (
        <div
          className="absolute top-full left-2 right-2 mt-1 rounded-md shadow-2xl z-50 py-2 max-h-[460px] overflow-y-auto"
          style={{
            backgroundColor: 'var(--popover)',
            border: '1px solid var(--border)',
          }}
        >
          {menuItems.map((item, i) =>
            item.divider ? (
              <div key={i} className="h-px my-1.5 mx-3" style={{ backgroundColor: 'var(--border)' }} />
            ) : (
              <button
                key={i}
                onClick={item.onClick}
                className="w-full flex items-center gap-3 py-2 text-[14px] transition-colors rounded-sm"
                style={{
                  color: item.danger ? 'var(--destructive)' : 'var(--foreground)',
                  margin: '0 6px',
                  paddingLeft: '10px',
                  paddingRight: '10px',
                  width: 'calc(100% - 12px)',
                }}
                onMouseEnter={(e) => {
                  const el = e.currentTarget as HTMLButtonElement;
                  el.style.backgroundColor = item.danger ? 'var(--destructive)' : 'var(--primary)';
                  el.style.color = 'white';
                }}
                onMouseLeave={(e) => {
                  const el = e.currentTarget as HTMLButtonElement;
                  el.style.backgroundColor = 'transparent';
                  el.style.color = item.danger ? 'var(--destructive)' : 'var(--foreground)';
                }}
              >
                {item.icon}
                {item.label}
              </button>
            )
          )}
        </div>
      )}
    </div>
  );
}
