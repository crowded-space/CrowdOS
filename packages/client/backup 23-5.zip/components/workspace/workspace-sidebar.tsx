﻿'use client';

import { useState } from 'react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { ChevronDown, Plus, Hash } from 'lucide-react';
import { WorkspaceDropdown } from './workspace-dropdown';

interface WorkspaceSidebarProps {
  collapsed: boolean;
  inDrawer?: boolean;
}

export function WorkspaceSidebar({ collapsed, inDrawer = false }: WorkspaceSidebarProps) {
  const {
    workspaces,
    activeWorkspaceId,
    activeChannelId,
    selectChannelMobile,
    setActiveChannel,
    toggleCategoryCollapse,
  } = useCrowdOSStore();

  const [collapsedCats, setCollapsedCats] = useState<Record<string, boolean>>({});
  const ws = workspaces.find((w) => w.id === activeWorkspaceId);

  const toggle = (catId: string) => {
    setCollapsedCats((prev) => ({ ...prev, [catId]: !prev[catId] }));
    toggleCategoryCollapse(catId);
  };

  const handleChannelClick = (channelId: string) => {
    if (inDrawer) {
      selectChannelMobile(channelId);
    } else {
      setActiveChannel(channelId);
    }
  };

  return (
    <div
      className={`
        flex flex-col shrink-0 min-w-0 h-full
        ${collapsed && !inDrawer ? 'w-0 overflow-hidden' : 'w-[280px] sm:w-[260px] md:w-[240px] lg:w-[280px]'}
        transition-all duration-200
      `}
      style={{ backgroundColor: 'var(--sidebar)' }}
    >
      {/* Server header */}
      <div
        className="shrink-0"
        style={{ borderBottom: '1px solid color-mix(in oklch, var(--border) 60%, transparent)' }}
      >
        <WorkspaceDropdown />
      </div>

      {/* Channel tree */}
      <div className="flex-1 overflow-y-auto pt-4 pb-3 px-2.5 space-y-5">
        {ws?.categories.map((cat) => {
          const isClosed = collapsedCats[cat.id];
          return (
            <div key={cat.id}>
              {/* Category header */}
              <button
                onClick={() => toggle(cat.id)}
                className="w-full flex items-center gap-1 px-1.5 py-2 mb-1 text-[12px] font-bold uppercase tracking-wider group rounded-md transition-colors hover:bg-accent/20"
                style={{ color: 'var(--muted-foreground)' }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = 'var(--sidebar-foreground)'; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = 'var(--muted-foreground)'; }}
              >
                <ChevronDown
                  className={`w-3.5 h-3.5 shrink-0 transition-transform duration-150 ${isClosed ? '-rotate-90' : ''}`}
                />
                <span className="flex-1 text-left truncate">{cat.name}</span>
                <Plus className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
              </button>

              {/* Channels */}
              {!isClosed && (
                <div className="space-y-[2px]">
                  {cat.channels.map((ch) => {
                    const isActive = activeChannelId === ch.id;
                    const hasUnread = ch.unreadCount > 0;
                    const hasMentions = ch.mentions > 0;

                    return (
                      <button
                        key={ch.id}
                        onClick={() => handleChannelClick(ch.id)}
                        className="w-full flex items-center gap-2 px-2.5 py-[10px] rounded-md text-[15px] transition-colors group leading-normal"
                        style={{
                          backgroundColor: isActive ? 'var(--sidebar-accent)' : 'transparent',
                          color: isActive ? 'var(--sidebar-accent-foreground)' : hasUnread ? 'var(--sidebar-foreground)' : 'var(--muted-foreground)',
                          fontWeight: isActive || hasUnread ? 600 : 400,
                        }}
                        onMouseEnter={(e) => {
                          if (!isActive) {
                            const el = e.currentTarget as HTMLButtonElement;
                            el.style.backgroundColor = 'var(--sidebar-accent)';
                            el.style.color = 'var(--sidebar-accent-foreground)';
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (!isActive) {
                            const el = e.currentTarget as HTMLButtonElement;
                            el.style.backgroundColor = 'transparent';
                            el.style.color = hasUnread ? 'var(--sidebar-foreground)' : 'var(--muted-foreground)';
                          }
                        }}
                      >
                        <Hash className="w-5 h-5 shrink-0 opacity-60" />
                        <span className="flex-1 text-left truncate">{ch.name}</span>

                        {hasMentions && (
                          <span
                            className="text-[11px] font-bold px-[6px] min-w-[18px] h-[18px] flex items-center justify-center rounded-full shrink-0"
                            style={{ backgroundColor: 'var(--destructive)', color: 'white' }}
                          >
                            {ch.mentions}
                          </span>
                        )}
                        {hasUnread && !hasMentions && (
                          <span className="w-[7px] h-[7px] rounded-full shrink-0 bg-foreground/70" />
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

