﻿'use client';

import { format } from 'date-fns';
import { Bot, Reply, MoreHorizontal, Smile } from 'lucide-react';
import type { Message, Agent } from '@/types/crowd-os';
import { PresenceIndicator } from '../ui/presence-indicator';
import { parseMentions } from './mention-parser';

interface AgentMessageProps {
  message: Message;
  agents: Agent[];
  compact?: boolean;
}

const LEVEL_COLOR: Record<number, string> = {
  0: 'var(--role-admin)',
  1: 'var(--role-admin)',
  2: 'var(--role-moderator)',
  3: 'var(--role-member)',
};

function HoverActions() {
  return (
    <div
      className="absolute -top-4 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center rounded-[4px] shadow-md"
      style={{ backgroundColor: 'var(--card)', border: '1px solid var(--border)' }}
    >
      {[
        { icon: Smile,          label: 'Reaction' },
        { icon: Reply,          label: 'Reply' },
        { icon: MoreHorizontal, label: 'More' },
      ].map(({ icon: Icon, label }) => (
        <button
          key={label}
          className="p-1.5 text-muted-foreground hover:text-foreground transition-colors"
          title={label}
        >
          <Icon className="w-[18px] h-[18px]" />
        </button>
      ))}
    </div>
  );
}

export function AgentMessage({ message, agents, compact = false }: AgentMessageProps) {
  const agent = agents.find((a) => a.id === message.authorId);
  const lc = LEVEL_COLOR[agent?.authorityLevel ?? 3] ?? 'var(--muted-foreground)';
  const body = parseMentions(message.content, agents);

  if (compact) {
    return (
      <div className="relative flex gap-4 pl-[72px] pr-12 py-[2px] group rounded-sm transition-colors hover:bg-accent/30">
        <span className="absolute left-[14px] top-1/2 -translate-y-1/2 text-[11px] text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity select-none">
          {format(message.timestamp, 'h:mm')}
        </span>
        <p className="text-[15px] text-foreground/90 break-words leading-[1.375rem]">{body}</p>
        <HoverActions />
      </div>
    );
  }

  return (
    <div className="relative flex gap-4 px-4 py-[2px] mt-[17px] group rounded-sm transition-colors hover:bg-accent/30">
      {/* Avatar */}
      <div className="relative flex-shrink-0 mt-0.5">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center cursor-pointer"
          style={{
            backgroundColor: 'var(--muted)',
            border: `1.5px solid color-mix(in oklch, ${lc} 35%, transparent)`,
          }}
        >
          <Bot className="w-5 h-5" style={{ color: lc }} />
        </div>
        {agent && (
          <div className="absolute -bottom-0.5 -right-0.5">
            <PresenceIndicator status={agent.status} size="sm" borderColor="var(--background)" />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline gap-2">
          <span
            className="font-medium text-[15px] hover:underline cursor-pointer"
            style={{ color: lc }}
          >
            {message.authorName}
          </span>
          {agent && (
            <span
              className="text-[10px] font-semibold px-[5px] py-[1px] rounded-[3px]"
              style={{
                backgroundColor: `color-mix(in oklch, ${lc} 20%, transparent)`,
                color: lc,
              }}
            >
              L{agent.authorityLevel}
            </span>
          )}
          <span className="text-[12px] text-muted-foreground select-none">
            Today at {format(message.timestamp, 'h:mm a')}
          </span>
        </div>
        <p className="text-[15px] text-foreground/90 break-words leading-[1.375rem]">{body}</p>
      </div>
      <HoverActions />
    </div>
  );
}
