﻿'use client';

import type { Message } from '@/types/crowd-os';

interface SystemMessageProps {
  message: Message;
}

export function SystemMessage({ message }: SystemMessageProps) {
  return (
    <div className="flex items-center gap-3 my-3 px-2">
      <div className="h-px flex-1" style={{ backgroundColor: 'var(--border)' }} />
      <span
        className="text-[11px] font-medium px-2 whitespace-nowrap"
        style={{ color: 'var(--muted-foreground)' }}
      >
        {message.content}
      </span>
      <div className="h-px flex-1" style={{ backgroundColor: 'var(--border)' }} />
    </div>
  );
}
