﻿'use client';

import { format } from 'date-fns';
import { Wrench, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import type { Message } from '@/types/crowd-os';

interface ToolExecutionMessageProps {
  message: Message;
}

const STATUS_CONFIG = {
  success: { icon: CheckCircle2, color: 'var(--agent-active)' },
  error:   { icon: XCircle,      color: 'var(--destructive)'  },
  running: { icon: Loader2,      color: 'var(--agent-thinking)', spin: true },
} as const;

export function ToolExecutionMessage({ message }: ToolExecutionMessageProps) {
  const tool = message.toolExecution;
  if (!tool) return null;

  const cfg = STATUS_CONFIG[tool.status] ?? STATUS_CONFIG.running;
  const StatusIcon = cfg.icon;
  const isSpin = 'spin' in cfg && cfg.spin;

  return (
    <div className="py-1 px-2">
      <div
        className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md text-sm"
        style={{
          backgroundColor: `color-mix(in oklch, ${cfg.color} 10%, var(--card))`,
          border: `1px solid color-mix(in oklch, ${cfg.color} 25%, var(--border))`,
        }}
      >
        <Wrench className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
        <span className="font-medium text-foreground/80">{message.authorName}</span>
        <span className="text-muted-foreground">used</span>
        <span className="font-mono font-semibold" style={{ color: cfg.color }}>{tool.toolName}</span>
        <StatusIcon
          className={`w-3.5 h-3.5 shrink-0 ${isSpin ? 'animate-spin' : ''}`}
          style={{ color: cfg.color }}
        />
        {tool.duration && (
          <span className="text-xs text-muted-foreground">{(tool.duration / 1000).toFixed(2)}s</span>
        )}
        <span className="text-xs text-muted-foreground">{format(message.timestamp, 'h:mm a')}</span>
      </div>
    </div>
  );
}
