﻿'use client';

import { format, formatDistanceToNow } from 'date-fns';
import { ArrowRight, Clock, DollarSign, CheckCircle2, Loader2, AlertCircle, Hourglass } from 'lucide-react';
import type { Message } from '@/types/crowd-os';

interface DelegationMessageProps {
  message: Message;
}

const STATUS_CONFIG = {
  pending: {
    label: 'Pending',
    icon: Hourglass,
    color: 'var(--agent-idle)',
  },
  in_progress: {
    label: 'In Progress',
    icon: Loader2,
    color: 'var(--agent-thinking)',
    spin: true,
  },
  completed: {
    label: 'Completed',
    icon: CheckCircle2,
    color: 'var(--agent-active)',
  },
  failed: {
    label: 'Failed',
    icon: AlertCircle,
    color: 'var(--destructive)',
  },
} as const;

export function DelegationMessage({ message }: DelegationMessageProps) {
  const info = message.delegationInfo;
  if (!info) return null;

  const cfg = STATUS_CONFIG[info.status] ?? STATUS_CONFIG.pending;
  const StatusIcon = cfg.icon;
  const isSpin = 'spin' in cfg && cfg.spin;

  const duration = info.completedAt
    ? formatDistanceToNow(info.startedAt)
    : formatDistanceToNow(info.startedAt, { addSuffix: true });

  return (
    <div className="py-2 px-2">
      <div
        className="rounded-lg overflow-hidden"
        style={{
          border: `1px solid color-mix(in oklch, ${cfg.color} 30%, var(--border))`,
          backgroundColor: 'var(--card)',
        }}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-3 py-2 border-b"
          style={{
            borderColor: `color-mix(in oklch, ${cfg.color} 20%, var(--border))`,
            background: `color-mix(in oklch, ${cfg.color} 6%, var(--card))`,
          }}
        >
          {/* Route: From → To */}
          <div className="flex items-center gap-1.5 text-sm min-w-0">
            <span
              className="font-semibold truncate"
              style={{ color: 'var(--role-admin)' }}
            >
              {info.fromAgentName}
            </span>
            <ArrowRight className="w-3.5 h-3.5 shrink-0 text-muted-foreground" />
            <span
              className="font-semibold truncate"
              style={{ color: 'var(--primary)' }}
            >
              {info.toAgentName}
            </span>
          </div>

          {/* Status badge + time */}
          <div className="flex items-center gap-2 shrink-0 ml-3">
            <div
              className="flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded"
              style={{
                color: cfg.color,
                backgroundColor: `color-mix(in oklch, ${cfg.color} 15%, transparent)`,
              }}
            >
              <StatusIcon className={`w-3 h-3 ${isSpin ? 'animate-spin' : ''}`} />
              {cfg.label}
            </div>
            <span className="text-xs text-muted-foreground whitespace-nowrap">
              {format(message.timestamp, 'h:mm a')}
            </span>
          </div>
        </div>

        {/* Body */}
        <div className="px-3 py-2.5">
          <p className="text-sm text-foreground/90">{info.task}</p>
          <div className="flex items-center gap-4 mt-1.5 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {duration}
            </span>
            {info.cost && (
              <span className="flex items-center gap-1" style={{ color: 'var(--agent-active)' }}>
                <DollarSign className="w-3 h-3" />
                ${info.cost.toFixed(3)}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
