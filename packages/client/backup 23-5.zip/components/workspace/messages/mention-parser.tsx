﻿'use client';

import type { Agent } from '@/types/crowd-os';

/**
 * Parses a message string and returns an array of React-renderable segments,
 * wrapping @mentions and #channels in styled spans.
 */
export function parseMentions(text: string, agents: Agent[]): React.ReactNode[] {
  // Build a combined regex: @AgentName or #channel-name
  const agentNames = agents.map((a) => a.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  const pattern = new RegExp(
    `(@(?:${agentNames.join('|')})|@\\w+|#[\\w-]+)`,
    'g'
  );

  const parts = text.split(pattern);

  return parts.map((part, i) => {
    if (part.startsWith('@')) {
      return (
        <span
          key={i}
          className="px-0.5 py-px rounded cursor-pointer font-medium"
          style={{
            backgroundColor: 'color-mix(in oklch, var(--primary) 20%, transparent)',
            color: 'var(--primary)',
          }}
        >
          {part}
        </span>
      );
    }
    if (part.startsWith('#')) {
      return (
        <span
          key={i}
          className="font-medium cursor-pointer hover:underline"
          style={{ color: 'var(--primary)' }}
        >
          {part}
        </span>
      );
    }
    return <span key={i}>{part}</span>;
  });
}
