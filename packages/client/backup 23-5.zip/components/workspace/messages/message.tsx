﻿'use client';

import type { Message, Agent } from '@/types/crowd-os';
import { HumanMessage } from './human-message';
import { AgentMessage } from './agent-message';
import { SystemMessage } from './system-message';
import { DelegationMessage } from './delegation-message';
import { ToolExecutionMessage } from './tool-execution-message';

interface MessageProps {
  message: Message;
  agents: Agent[];
  /** When true, hides avatar/name for consecutive messages from the same author. */
  compact?: boolean;
}

export function Message({ message, agents, compact = false }: MessageProps) {
  switch (message.type) {
    case 'human':
      return <HumanMessage message={message} agents={agents} compact={compact} />;
    case 'agent':
      return <AgentMessage message={message} agents={agents} compact={compact} />;
    case 'system':
      return <SystemMessage message={message} />;
    case 'delegation':
      return <DelegationMessage message={message} />;
    case 'tool_execution':
      return <ToolExecutionMessage message={message} />;
    case 'governance':
      return <SystemMessage message={message} />;
    default:
      return null;
  }
}
