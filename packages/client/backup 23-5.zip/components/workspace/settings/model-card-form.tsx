'use client';

import { useState } from 'react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import {
  X,
  Cpu,
  Eye,
  EyeOff,
  Check,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import type { ModelProfile, ProviderType } from '@/types/crowd-os';

// ── Provider option metadata ──
const PROVIDER_OPTIONS: {
  value: ProviderType;
  label: string;
  description: string;
  models: string;
  hasBaseUrl: boolean;
}[] = [
  {
    value: 'google',
    label: 'Google AI',
    description: 'Gemini & Gemma models',
    models: 'gemini-2.0-flash, gemini-2.0-flash-lite, gemma-3-27b-it, etc.',
    hasBaseUrl: false,
  },
  {
    value: 'openai',
    label: 'OpenAI',
    description: 'GPT models & OpenAI-compatible endpoints',
    models: 'gpt-4o, gpt-4o-mini, gpt-4.1, etc.',
    hasBaseUrl: true,
  },
  {
    value: 'anthropic',
    label: 'Anthropic',
    description: 'Claude models',
    models: 'claude-sonnet-4-20250514, claude-haiku-3-5, claude-opus-4, etc.',
    hasBaseUrl: false,
  },
];

interface ModelCardFormProps {
  /** If provided, we're editing an existing card */
  editProfile?: ModelProfile;
  onClose: () => void;
}

export function ModelCardForm({ editProfile, onClose }: ModelCardFormProps) {
  const { addModelProfile, updateModelProfile } = useCrowdOSStore();

  const [label, setLabel] = useState(editProfile?.label ?? '');
  const [provider, setProvider] = useState<ProviderType>(editProfile?.provider ?? 'openai');
  const [modelName, setModelName] = useState(editProfile?.modelName ?? '');
  const [apiKey, setApiKey] = useState(editProfile?.apiKey ?? '');
  const [baseUrl, setBaseUrl] = useState(editProfile?.baseUrl ?? '');
  const [showKey, setShowKey] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);

  const selectedProvider = PROVIDER_OPTIONS.find((p) => p.value === provider)!;

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!label.trim()) errs.label = 'Label is required';
    if (!modelName.trim()) errs.modelName = 'Model name is required';
    if (!apiKey.trim()) errs.apiKey = 'API key is required';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;

    if (editProfile) {
      updateModelProfile(editProfile.id, {
        label: label.trim(),
        provider,
        modelName: modelName.trim(),
        apiKey: apiKey.trim(),
        baseUrl: provider === 'openai' ? baseUrl.trim() || undefined : undefined,
        apiKeyConfigured: apiKey.trim().length > 0,
      });
    } else {
      addModelProfile({
        label: label.trim(),
        provider,
        modelName: modelName.trim(),
        apiKey: apiKey.trim(),
        baseUrl: provider === 'openai' ? baseUrl.trim() || undefined : undefined,
        apiKeyConfigured: apiKey.trim().length > 0,
      });
    }

    onClose();
  };

  const handleTestConnection = async () => {
    if (!apiKey.trim() || !modelName.trim()) return;
    setTesting(true);
    setTestResult(null);

    // Simulate a connection test (no backend yet — always succeeds)
    await new Promise((r) => setTimeout(r, 1500));

    setTestResult({
      ok: true,
      message: `Connected to ${providerDisplayName(provider)} — endpoint is reachable.`,
    });
    setTesting(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />

      {/* Form dialog */}
      <div
        className="relative w-full max-w-md mx-4 bg-card rounded-xl shadow-2xl overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-label={editProfile ? 'Edit model card' : 'Create model card'}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-primary" />
            <h2 className="text-base font-semibold">
              {editProfile ? 'Edit Model Card' : 'New Model Card'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md hover:bg-accent transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4 max-h-[60vh] overflow-y-auto">
          {/* Label */}
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Card Label</label>
            <input
              type="text"
              value={label}
              onChange={(e) => { setLabel(e.target.value); setErrors((prev) => ({ ...prev, label: '' })); }}
              placeholder="e.g. Flagship Reasoning, Fast Coder"
              className="w-full px-3 py-2 bg-input border border-border rounded-md text-sm outline-none focus:ring-1 focus:ring-ring placeholder:text-muted-foreground"
            />
            {errors.label && <p className="text-xs text-destructive">{errors.label}</p>}
          </div>

          {/* Provider */}
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Provider Type</label>
            <div className="grid grid-cols-3 gap-2">
              {PROVIDER_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => {
                    setProvider(opt.value);
                    if (!opt.hasBaseUrl) setBaseUrl('');
                  }}
                  className={`relative flex flex-col items-center gap-1 p-3 rounded-lg border text-sm transition-all ${
                    provider === opt.value
                      ? 'border-primary bg-primary/10 text-foreground'
                      : 'border-border bg-card text-muted-foreground hover:border-muted-foreground/50'
                  }`}
                >
                  {provider === opt.value && (
                    <Check className="absolute top-1 right-1 w-3 h-3 text-primary" />
                  )}
                  <span className="font-medium">{opt.label}</span>
                  <span className="text-[10px] text-center opacity-70">{opt.description}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Model String */}
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Model Name</label>
            <input
              type="text"
              value={modelName}
              onChange={(e) => { setModelName(e.target.value); setErrors((prev) => ({ ...prev, modelName: '' })); }}
              placeholder={selectedProvider.models}
              className="w-full px-3 py-2 bg-input border border-border rounded-md text-sm outline-none focus:ring-1 focus:ring-ring font-mono placeholder:text-muted-foreground"
            />
            {errors.modelName && <p className="text-xs text-destructive">{errors.modelName}</p>}
          </div>

          {/* API Key */}
          <div className="space-y-1.5">
            <label className="text-sm font-medium">API Key</label>
            <div className="relative">
              <input
                type={showKey ? 'text' : 'password'}
                value={apiKey}
                onChange={(e) => { setApiKey(e.target.value); setErrors((prev) => ({ ...prev, apiKey: '' })); }}
                placeholder="sk-... or AIza..."
                className="w-full px-3 py-2 pr-10 bg-input border border-border rounded-md text-sm outline-none focus:ring-1 focus:ring-ring font-mono placeholder:text-muted-foreground"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground"
                tabIndex={-1}
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {errors.apiKey && <p className="text-xs text-destructive">{errors.apiKey}</p>}
          </div>

          {/* Base URL (OpenAI only) */}
          {provider === 'openai' && (
            <div className="space-y-1.5">
              <label className="text-sm font-medium">
                Base URL{' '}
                <span className="text-muted-foreground font-normal">(optional)</span>
              </label>
              <input
                type="text"
                value={baseUrl}
                onChange={(e) => setBaseUrl(e.target.value)}
                placeholder="https://api.openai.com/v1"
                className="w-full px-3 py-2 bg-input border border-border rounded-md text-sm outline-none focus:ring-1 focus:ring-ring font-mono placeholder:text-muted-foreground"
              />
              <p className="text-xs text-muted-foreground">
                Leave empty for default OpenAI endpoint. Use a custom URL for Ollama, vLLM, or other OpenAI-compatible providers.
              </p>
            </div>
          )}

          {/* Test Connection Result */}
          {testResult && (
            <div
              className={`flex items-start gap-2 p-3 rounded-lg text-sm ${
                testResult.ok
                  ? 'bg-agent-active/10 text-agent-active'
                  : 'bg-destructive/10 text-destructive'
              }`}
            >
              {testResult.ok ? (
                <Check className="w-4 h-4 mt-0.5 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              )}
              <span>{testResult.message}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between gap-3 p-4 border-t border-border">
          <button
            type="button"
            onClick={handleTestConnection}
            disabled={testing || !apiKey.trim() || !modelName.trim()}
            className="flex items-center gap-2 px-3 py-2 text-sm rounded-md border border-border hover:bg-accent transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            {testing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Testing...
              </>
            ) : (
              <>
                <Cpu className="w-4 h-4" />
                Test Connection
              </>
            )}
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm rounded-md hover:bg-accent transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              className="px-4 py-2 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors font-medium"
            >
              {editProfile ? 'Save Changes' : 'Create Card'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function providerDisplayName(provider: ProviderType): string {
  return PROVIDER_OPTIONS.find((p) => p.value === provider)?.label ?? provider;
}
