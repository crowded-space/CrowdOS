﻿'use client';

/**
 * PresenceIndicator — colored dot using design-system CSS custom properties
 * (--agent-*) so colors stay in sync with globals.css.
 */

type StatusKey = 'idle' | 'working' | 'paused' | 'offline';

const STATUS_STYLE: Record<StatusKey, { color: string; pulse: boolean }> = {
  idle:       { color: 'var(--agent-idle)',        pulse: false },
  working:    { color: 'var(--agent-thinking)',    pulse: true  },
  paused:     { color: 'var(--agent-idle)',        pulse: false },
  offline:    { color: 'var(--agent-sleeping)',    pulse: false },
};

interface PresenceIndicatorProps {
  status: string;
  size?: 'sm' | 'md';
  /** Pass matching background color to render border ring (e.g. 'var(--sidebar)'). */
  borderColor?: string;
}

export function PresenceIndicator({ status, size = 'md', borderColor }: PresenceIndicatorProps) {
  const cfg = STATUS_STYLE[status as StatusKey] ?? { color: 'var(--agent-sleeping)', pulse: false };
  const dim = size === 'sm' ? '10px' : '12px';

  return (
    <div
      className={cfg.pulse ? 'animate-pulse-glow' : undefined}
      style={{
        width: dim,
        height: dim,
        borderRadius: '50%',
        backgroundColor: cfg.color,
        flexShrink: 0,
        border: borderColor ? `2px solid ${borderColor}` : undefined,
      }}
    />
  );
}
