'use client';

import { useCrowdOSStore, type BottomNavTab } from '@/stores/crowd-os-store';
import {
  Hash,
  MessageSquare,
  Bot,
  BarChart3,
  Settings,
  MessageCircle,
} from 'lucide-react';

const TABS: { id: BottomNavTab; label: string; icon: React.ElementType }[] = [
  { id: 'channels', label: 'Channels', icon: Hash },
  { id: 'chat',     label: 'Chat',     icon: MessageCircle },
  { id: 'agents',   label: 'Agents',   icon: Bot },
  { id: 'stats',    label: 'Stats',    icon: BarChart3 },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function BottomNav() {
  const {
    activeMobileTab,
    setActiveMobileTab,
    workspaces,
    activeWorkspaceId,
    openMobileDrawerLeft,
    openMobileDrawerRight,
    openSettingsModal,
    closeMobileDrawerLeft,
    closeMobileDrawerRight,
  } = useCrowdOSStore();

  const ws = workspaces.find((w) => w.id === activeWorkspaceId);
  const totalUnread = ws?.categories.reduce(
    (sum, cat) => sum + cat.channels.reduce((s, ch) => s + ch.unreadCount, 0),
    0
  ) ?? 0;

  const totalMentions = ws?.categories.reduce(
    (sum, cat) => sum + cat.channels.reduce((s, ch) => s + ch.mentions, 0),
    0
  ) ?? 0;

  const handleTabPress = (tab: BottomNavTab) => {
    setActiveMobileTab(tab);

    switch (tab) {
      case 'channels':
        openMobileDrawerLeft();
        break;
      case 'agents':
        openMobileDrawerRight();
        break;
      case 'settings':
        openSettingsModal();
        break;
      case 'chat':
        // Already on chat — close any open drawers
        closeMobileDrawerLeft();
        closeMobileDrawerRight();
        break;
      case 'stats':
        // Toggle right sidebar equivalent
        break;
    }
  };

  return (
    <nav className="bottom-nav" role="tablist" aria-label="Main navigation">
      {TABS.map(({ id, label, icon: Icon }) => {
        const isActive = activeMobileTab === id;
        const isChatTab = id === 'chat';
        const showUnread = id === 'channels' && totalUnread > 0;
        const showMentions = id === 'channels' && totalMentions > 0;

        return (
          <button
            key={id}
            onClick={() => handleTabPress(id)}
            role="tab"
            aria-selected={isActive}
            aria-label={label}
            className={`
              relative flex flex-col items-center justify-center
              min-w-0 flex-1 h-full gap-0.5
              transition-colors duration-150
              ${isActive ? 'text-foreground' : 'text-muted-foreground hover:text-foreground/80'}
            `}
            style={{
              paddingTop: '6px',
              paddingBottom: '6px',
            }}
          >
            {/* Icon container with unread badge */}
            <div className="relative">
              {isChatTab && (
                <div
                  className="absolute -top-1 -right-1 w-[18px] h-[18px] rounded-full flex items-center justify-center"
                  style={{
                    backgroundColor: 'var(--primary)',
                    color: 'var(--primary-foreground)',
                    fontSize: '9px',
                    fontWeight: 700,
                  }}
                >
                  1
                </div>
              )}
              <Icon
                className={`w-[22px] h-[22px] ${isActive ? 'drop-shadow-glow' : ''}`}
                style={{
                  strokeWidth: isActive ? 2.5 : 1.75,
                }}
              />
              
              {/* Unread dot for channels */}
              {showUnread && !showMentions && (
                <span
                  className="absolute -top-0.5 -right-0.5 w-[10px] h-[10px] rounded-full border-2"
                  style={{
                    backgroundColor: 'var(--destructive)',
                    borderColor: 'var(--sidebar)',
                  }}
                />
              )}
              {/* Mention badge */}
              {showMentions && (
                <span
                  className="absolute -top-1.5 -right-1.5 text-[10px] font-bold min-w-[18px] h-[18px] flex items-center justify-center rounded-full border-2"
                  style={{
                    backgroundColor: 'var(--destructive)',
                    color: 'white',
                    borderColor: 'var(--sidebar)',
                  }}
                >
                  {totalMentions > 9 ? '9+' : totalMentions}
                </span>
              )}
            </div>

            <span className="text-[10px] font-medium leading-none">{label}</span>

            {/* Active indicator line */}
            {isActive && (
              <span
                className="absolute top-0 left-1/4 right-1/4 h-[2px] rounded-full"
                style={{ backgroundColor: 'var(--primary)' }}
              />
            )}
          </button>
        );
      })}
    </nav>
  );
}
