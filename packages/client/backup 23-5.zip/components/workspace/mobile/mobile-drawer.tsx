'use client';

import { useEffect, useRef } from 'react';

interface MobileDrawerProps {
  open: boolean;
  onClose: () => void;
  side: 'left' | 'right';
  width?: number;
  children: React.ReactNode;
  ariaLabel: string;
}

/**
 * MobileDrawer — a slide-over drawer for mobile navigation.
 * Slides in from left or right with a backdrop overlay.
 * Traps focus and handles escape key.
 */
export function MobileDrawer({
  open,
  onClose,
  side,
  width = 320,
  children,
  ariaLabel,
}: MobileDrawerProps) {
  const drawerRef = useRef<HTMLDivElement>(null);

  // Close on escape
  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  // Lock body scroll when open
  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  // Focus trap
  useEffect(() => {
    if (open) {
      // Small delay for animation to settle
      const timer = setTimeout(() => {
        drawerRef.current?.focus();
      }, 50);
      return () => clearTimeout(timer);
    }
  }, [open]);

  if (!open) return null;

  const isLeft = side === 'left';
  const translateX = isLeft ? '-100%' : '100%';

  return (
    <>
      {/* Backdrop */}
      <div
        className="drawer-overlay"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer panel */}
      <div
        ref={drawerRef}
        role="dialog"
        aria-modal="true"
        aria-label={ariaLabel}
        tabIndex={-1}
        className="fixed top-0 bottom-0 z-50 flex flex-col outline-none"
        style={{
          [isLeft ? 'left' : 'right']: 0,
          width: Math.min(width, typeof window !== 'undefined' ? window.innerWidth - 48 : 320),
          maxWidth: '100vw',
          backgroundColor: 'var(--sidebar)',
          borderRight: isLeft ? '1px solid var(--border)' : 'none',
          borderLeft: isLeft ? 'none' : '1px solid var(--border)',
          // Safe area
          paddingTop: 'var(--safe-top)',
          paddingBottom: 'var(--safe-bottom)',
          // Slide animation (single source of truth)
          animation: `${isLeft ? 'slide-in-left' : 'slide-in-right'} 0.25s cubic-bezier(0.16, 1, 0.3, 1)`,
        }}
      >
        {children}
      </div>
    </>
  );
}
