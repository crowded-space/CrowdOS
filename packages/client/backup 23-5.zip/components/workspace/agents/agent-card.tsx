'use client';

import { PresenceIndicator } from '../ui/presence-indicator';
import { StatusBadge } from '../ui/status-badge';
import type { Agent } from '@/types/crowd-os';

interface AgentCardProps {
  agent: Agent;
  onSelect?: (agentId: string) => void;
  selected?: boolean;
}

export function AgentCard({ agent, onSelect, selected }: AgentCardProps) {
  const authorityLabel = `L${agent.authorityLevel}`;

  return (
    <button
      onClick={() => onSelect?.(agent.id)}
      className={`w-full text-left p-3 rounded-lg border transition-colors ${
        selected
          ? 'bg-slate-700 border-blue-600'
          : 'bg-slate-900 border-slate-700 hover:border-slate-600'
      }`}
    >
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0">
          <PresenceIndicator status={agent.status} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2">
            <p className="text-sm font-semibold text-white truncate">{agent.name}</p>
            <span className="text-xs text-gray-500 whitespace-nowrap">{authorityLabel}</span>
          </div>
          <p className="text-xs text-gray-400 truncate">{agent.title}</p>
          <div className="mt-2">
            <StatusBadge status={agent.status} />
          </div>
        </div>
      </div>
    </button>
  );
}
