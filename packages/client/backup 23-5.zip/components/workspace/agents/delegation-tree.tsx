'use client';

import type { Delegation } from '@/types/crowd-os';

interface DelegationNodeProps {
  delegation: Delegation;
  level?: number;
}

const statusColors = {
  pending: 'border-yellow-600 bg-yellow-500/10',
  in_progress: 'border-blue-600 bg-blue-500/10',
  completed: 'border-green-600 bg-green-500/10',
  failed: 'border-red-600 bg-red-500/10',
};

function DelegationNode({ delegation, level = 0 }: DelegationNodeProps) {
  return (
    <div className="text-xs" style={{ marginLeft: `${level * 16}px` }}>
      <div className={`border-l-2 pl-3 py-2 ${statusColors[delegation.status]}`}>
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-white truncate">
              {delegation.fromAgent.name} → {delegation.toAgent.name}
            </p>
            <p className="text-gray-400 text-xs truncate mt-0.5">{delegation.task}</p>
            <p className="text-gray-500 text-xs mt-1">
              {delegation.cost && `$${delegation.cost.toFixed(3)}`}
            </p>
          </div>
          <span className={`px-2 py-0.5 rounded whitespace-nowrap font-medium ${
            delegation.status === 'pending' ? 'bg-yellow-600 text-yellow-100' :
            delegation.status === 'in_progress' ? 'bg-blue-600 text-blue-100' :
            delegation.status === 'completed' ? 'bg-green-600 text-green-100' :
            'bg-red-600 text-red-100'
          }`}>
            {delegation.status}
          </span>
        </div>
      </div>

      {/* Children */}
      {delegation.children.map((child) => (
        <DelegationNode key={child.id} delegation={child} level={level + 1} />
      ))}
    </div>
  );
}

export function DelegationTree({ delegations }: { delegations: Delegation[] }) {
  return (
    <div className="space-y-2">
      {delegations.map((delegation) => (
        <DelegationNode key={delegation.id} delegation={delegation} />
      ))}
    </div>
  );
}
