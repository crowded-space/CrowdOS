﻿'use client';

import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { BarChart3, Bot, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { PresenceIndicator } from './ui/presence-indicator';

const LEVEL_COLOR: Record<number, string> = {
  0: 'var(--role-admin)',
  1: 'var(--role-admin)',
  2: 'var(--role-moderator)',
  3: 'var(--role-member)',
};

export function RightSidebar() {
  const { agents, delegations, openAgentProfileModal } = useCrowdOSStore();
  const [statsOpen, setStatsOpen] = useState(true);

  const coordinators = agents.filter((a) => a.authorityLevel <= 2);
  const workers      = agents.filter((a) => a.authorityLevel === 3);
  const activeAgents = agents.filter((a) => a.status !== 'offline');

  const totalTokens = delegations.reduce((s, d) => {
    const walk = (n: typeof d): number => (n.tokenUsage || 0) + n.children.reduce((a, c) => a + walk(c), 0);
    return s + walk(d);
  }, 0);
  const totalCost = delegations.reduce((s, d) => {
    const walk = (n: typeof d): number => (n.cost || 0) + n.children.reduce((a, c) => a + walk(c), 0);
    return s + walk(d);
  }, 0);
  const activeTasks = delegations.reduce((s, d) => {
    const walk = (n: typeof d): number => (n.status === 'in_progress' ? 1 : 0) + n.children.reduce((a, c) => a + walk(c), 0);
    return s + walk(d);
  }, 0);

  const AgentRow = ({ agent }: { agent: (typeof agents)[0] }) => {
    const lc = LEVEL_COLOR[agent.authorityLevel] ?? 'var(--muted-foreground)';
    return (
      <button
        onClick={() => openAgentProfileModal(agent.id)}
        className="w-full flex items-center gap-3 px-3 py-2 rounded-md transition-colors group text-left"
        style={{ backgroundColor: 'transparent' }}
        onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.backgroundColor = 'var(--sidebar-accent)'; }}
        onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.backgroundColor = 'transparent'; }}
      >
        {/* Avatar with presence ring */}
        <div className="relative shrink-0">
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center"
            style={{
              backgroundColor: 'var(--muted)',
              border: `2px solid color-mix(in oklch, ${lc} 35%, transparent)`,
            }}
          >
            <Bot className="w-[18px] h-[18px]" style={{ color: lc }} />
          </div>
          <div className="absolute -bottom-[2px] -right-[2px]">
            <PresenceIndicator status={agent.status} size="sm" borderColor="var(--sidebar)" />
          </div>
        </div>

        {/* Name + role */}
        <div className="flex-1 min-w-0">
          <div className="text-[14px] font-medium truncate" style={{ color: lc }}>{agent.name}</div>
          <div className="text-[12px] text-muted-foreground truncate">{agent.title}</div>
        </div>
      </button>
    );
  };

  return (
    <div
      className="w-[280px] sm:w-[260px] lg:w-[280px] flex flex-col shrink-0 overflow-y-auto min-w-0"
      style={{ backgroundColor: 'var(--sidebar)', borderLeft: '1px solid var(--border)' }}
    >
      {/* ── COORDINATORS ── */}
      <div className="pt-5 px-2.5">
        <div className="px-3 mb-2 text-[12px] font-bold uppercase tracking-wider text-muted-foreground">
          Coordinators — {coordinators.length}
        </div>
        <div className="space-y-[3px]">
          {coordinators.map((a) => <AgentRow key={a.id} agent={a} />)}
        </div>
      </div>

      {/* ── WORKERS ── */}
      <div className="pt-5 px-2.5">
        <div className="px-3 mb-2 text-[12px] font-bold uppercase tracking-wider text-muted-foreground">
          Workers — {workers.length}
        </div>
        <div className="space-y-[3px]">
          {workers.map((a) => <AgentRow key={a.id} agent={a} />)}
        </div>
      </div>

      {/* ── STATS ── */}
      <div className="mt-auto px-2.5 pt-4" style={{ borderTop: '1px solid var(--border)' }}>
        <button
          onClick={() => setStatsOpen((v) => !v)}
          className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded transition-colors hover:bg-accent/50"
        >
          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${statsOpen ? '' : '-rotate-90'}`} />
          <BarChart3 className="w-[18px] h-[18px] text-muted-foreground" />
          <span className="text-[12px] font-bold uppercase tracking-wider">Stats</span>
        </button>

        {statsOpen && (
          <div className="px-2 pb-4 grid grid-cols-2 gap-2.5 pt-2">
            {[
              { label: 'Tokens', val: `${(totalTokens / 1000).toFixed(1)}K`, color: 'var(--foreground)' },
              { label: 'Cost',   val: `$${totalCost.toFixed(2)}`,            color: 'var(--agent-active)' },
              { label: 'Active', val: String(activeAgents.length),           color: 'var(--agent-thinking)' },
              { label: 'Tasks',  val: String(activeTasks),                   color: 'var(--agent-delegating)' },
            ].map(({ label, val, color }) => (
              <div
                key={label}
                className="rounded-lg p-3"
                style={{ backgroundColor: 'var(--card)', border: '1px solid var(--border)' }}
              >
                <p className="text-[11px] text-muted-foreground mb-1">{label}</p>
                <p className="text-[16px] font-semibold" style={{ color }}>{val}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
