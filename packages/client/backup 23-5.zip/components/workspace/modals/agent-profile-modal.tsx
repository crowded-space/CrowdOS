﻿'use client';

import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { X, MessageSquare, MoreHorizontal, Bot, Cpu, Shield } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { PresenceIndicator } from '../ui/presence-indicator';
import { StatusBadge } from '../ui/status-badge';
import type { AgentStatus } from '@/types/crowd-os';

/** Level accent using design-system vars */
const LEVEL_COLOR: Record<number, string> = {
  0: 'var(--role-admin)',
  1: 'var(--role-admin)',
  2: 'var(--role-moderator)',
  3: 'var(--role-member)',
};

const LEVEL_LABEL: Record<number, string> = {
  0: 'L0 · Omniscient',
  1: 'L1 · Lead',
  2: 'L2 · Coordinator',
  3: 'L3 · Worker',
};

export function AgentProfileModal() {
  const { agents, selectedAgentId, agentProfileModalOpen, closeAgentProfileModal } =
    useCrowdOSStore();

  const agent = agents.find((a) => a.id === selectedAgentId);
  if (!agentProfileModalOpen || !agent) return null;

  const fallbackAgent = agent.fallbackAgentId ? agents.find((a) => a.id === agent.fallbackAgentId) : null;
  const levelColor   = LEVEL_COLOR[agent.authorityLevel] ?? 'var(--muted-foreground)';
  const levelLabel   = LEVEL_LABEL[agent.authorityLevel] ?? `L${agent.authorityLevel}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={closeAgentProfileModal}
      />

      {/* Modal — responsive: full-screen on mobile, centered card on desktop */}
      <div
        className="
          relative 
          w-full h-full sm:w-auto sm:h-auto 
          sm:w-[380px] sm:max-h-[85vh]
          rounded-none sm:rounded-xl 
          overflow-y-auto
          shadow-2xl
          flex flex-col
        "
        role="dialog"
        aria-modal="true"
        aria-label={`${agent.name} profile`}
        style={{ backgroundColor: 'var(--card)' }}
      >
        {/* Banner – gradient derived from the agent level color */}
        <div
          className="h-[60px]"
          style={{
            background: `linear-gradient(135deg,
              color-mix(in oklch, ${levelColor} 80%, var(--background)) 0%,
              color-mix(in oklch, ${levelColor} 40%, var(--background)) 100%)`,
          }}
        />

        {/* Avatar row */}
        <div className="relative px-4">
          <div className="absolute -top-10 left-4">
            <div className="relative">
              <div
                className="w-20 h-20 rounded-full flex items-center justify-center"
                style={{
                  backgroundColor: 'var(--card)',
                  border: `4px solid var(--card)`,
                  boxShadow: `0 0 0 2px color-mix(in oklch, ${levelColor} 50%, transparent)`,
                }}
              >
                <Bot className="w-10 h-10" style={{ color: levelColor }} />
              </div>
              {/* Live presence dot */}
              <div className="absolute bottom-1.5 right-1.5">
                <PresenceIndicator status={agent.status} size="md" borderColor="var(--card)" />
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex justify-end gap-2 pt-2 pb-3">
            <button className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors">
              <MessageSquare className="w-4 h-4" />
            </button>
            <button className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors">
              <MoreHorizontal className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content card */}
        <div className="mx-4 mb-4 p-3 rounded-lg" style={{ backgroundColor: 'var(--background)' }}>
          {/* Name + title */}
          <div className="mb-3">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-semibold">{agent.name}</h2>
              <span
                className="text-[10px] font-semibold px-1.5 py-0.5 rounded"
                style={{
                  backgroundColor: `color-mix(in oklch, ${levelColor} 20%, transparent)`,
                  color: levelColor,
                }}
              >
                {levelLabel}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mt-0.5">{agent.title}</p>
            {agent.species && <p className="text-xs text-muted-foreground mt-1">{agent.species}</p>}
          </div>

          <div className="h-px bg-border mb-3" />

          {/* Status */}
          <div className="mb-3">
            <h3 className="text-xs font-semibold uppercase text-muted-foreground mb-1.5">Status</h3>
            <div className="flex items-center gap-2">
              <StatusBadge status={agent.status as AgentStatus} />
              <span className="text-xs text-muted-foreground">
                {formatDistanceToNow(agent.updatedAt, { addSuffix: true })}
              </span>
            </div>
          </div>

          <div className="h-px bg-border mb-3" />

          {/* Modules */}
          <div className="mb-3">
            <h3 className="text-xs font-semibold uppercase text-muted-foreground mb-1.5">Modules</h3>
            <div className="flex items-center gap-2 mb-2">
              <Cpu className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-mono">{agent.modelModuleId}</span>
            </div>
            <div className="text-xs text-muted-foreground space-y-1">
              <div>Instruction: <span className="font-mono">{agent.instructionModuleId}</span></div>
              {agent.toolkitModuleId && <div>Toolkit: <span className="font-mono">{agent.toolkitModuleId}</span></div>}
              {agent.constraintsModuleId && <div>Constraints: <span className="font-mono">{agent.constraintsModuleId}</span></div>}
              {agent.capabilitiesModuleId && <div>Capabilities: <span className="font-mono">{agent.capabilitiesModuleId}</span></div>}
            </div>
          </div>

          <div className="h-px bg-border mb-3" />

          {/* Permissions */}
          <div className="mb-3">
            <h3 className="text-xs font-semibold uppercase text-muted-foreground mb-1.5">Permissions</h3>
            <div className="flex flex-wrap gap-1.5">
              {Object.entries(agent.permissions)
                .filter(([, enabled]) => enabled)
                .map(([permission]) => (
                  <span
                    key={permission}
                    className="px-2 py-0.5 text-xs rounded"
                    style={{
                      backgroundColor: 'color-mix(in oklch, var(--primary) 15%, transparent)',
                      color: 'var(--primary)',
                      border: '1px solid color-mix(in oklch, var(--primary) 30%, transparent)',
                    }}
                  >
                    {permission}
                  </span>
                ))}
            </div>
          </div>
          <div className="h-px bg-border mb-3" />

          <div className="mb-3">
            <h3 className="text-xs font-semibold uppercase text-muted-foreground mb-1.5">Registry</h3>
            <div className="text-sm text-muted-foreground space-y-1">
              <div>Memory policy: {agent.memorySharingPolicy}</div>
              <div>Template: {agent.isTemplate ? 'Yes' : 'No'}</div>
              <div>Omniscient: {agent.isOmniscient ? 'Yes' : 'No'}</div>
              {agent.l3Subtype && <div>L3 subtype: {agent.l3Subtype}</div>}
            </div>
          </div>

          {agent.categoryPermissions.length > 0 && (
            <>
              <div className="mb-3">
                <h3 className="text-xs font-semibold uppercase text-muted-foreground mb-1.5">Category Permissions</h3>
                <div className="flex flex-wrap gap-1.5">
                  {agent.categoryPermissions.map((categoryId) => (
                    <span
                      key={categoryId}
                      className="px-2 py-0.5 text-xs rounded"
                      style={{
                        backgroundColor: 'color-mix(in oklch, var(--secondary) 80%, transparent)',
                        color: 'var(--secondary-foreground)',
                      }}
                    >
                      {categoryId}
                    </span>
                  ))}
                </div>
              </div>
              <div className="h-px bg-border mb-3" />
            </>
          )}

          {fallbackAgent && (
            <div>
              <h3 className="text-xs font-semibold uppercase text-muted-foreground mb-1.5">Fallback Agent</h3>
              <div className="flex items-center gap-2">
                <span className="text-sm" style={{ color: 'var(--primary)' }}>{fallbackAgent.name}</span>
              </div>
            </div>
          )}
        </div>

        {/* DM input */}
        <div className="px-4 pb-4">
          <div
            className="flex items-center gap-2 px-3 py-2.5 rounded-md"
            style={{ backgroundColor: 'var(--input)', border: '1px solid var(--border)' }}
          >
            <input
              type="text"
              placeholder={`Message @${agent.name}`}
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
            <Shield className="w-4 h-4 text-muted-foreground" />
          </div>
        </div>

        {/* Close */}
        <button
          onClick={closeAgentProfileModal}
          className="absolute top-2 right-2 p-2 sm:p-1.5 rounded-full transition-colors z-10"
          style={{ backgroundColor: 'rgba(0,0,0,0.4)' }}
          aria-label="Close profile"
        >
          <X className="w-5 h-5 sm:w-4 sm:h-4 text-white" />
        </button>

        {/* Mobile-safe bottom spacer */}
        <div className="h-4 sm:hidden" />
      </div>
    </div>
  );
}
