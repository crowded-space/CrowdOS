'use client';

import { WorkspaceSidebar } from '@/components/workspace/workspace-sidebar';
import { MainChatArea } from '@/components/workspace/main-chat-area';
import { RightSidebar } from '@/components/workspace/right-sidebar';
import { AgentProfileModal } from '@/components/workspace/modals/agent-profile-modal';
import { WorkspaceSettingsModal } from '@/components/workspace/modals/workspace-settings-modal';
import { useCrowdOSStore } from '@/stores/crowd-os-store';

export default function WorkspacePage() {
  const { rightSidebarOpen, leftSidebarCollapsed } = useCrowdOSStore();

  return (
    <>
      <div className="flex h-screen overflow-hidden bg-background">
        {/* Left Sidebar */}
        <WorkspaceSidebar collapsed={leftSidebarCollapsed} />
        
        {/* Main Chat / Activity Area */}
        <MainChatArea />
        
        {/* Right Sidebar */}
        {rightSidebarOpen && <RightSidebar />}
      </div>
      
      {/* Modals */}
      <AgentProfileModal />
      <WorkspaceSettingsModal />
    </>
  );
}
