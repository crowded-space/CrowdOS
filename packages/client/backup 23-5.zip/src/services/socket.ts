import { io, type Socket } from "socket.io-client";

export interface RealtimeAgentStatusPayload {
  agentId: string;
  status: "idle" | "working" | "paused" | "offline";
}

export interface RealtimeMessagePayload {
  id: string;
  channelId: string;
  authorId: string;
  authorName: string;
  authorLevel: number | "stakeholder";
  authorType: "user" | "agent" | "system";
  content: string;
  mentions: unknown[];
  isInternalMonologue: boolean;
  sequenceNumber: number;
  timestamp: string | Date;
}

export interface RealtimeMessageStreamPayload {
  channelId: string;
  agentId: string;
  chunk: string;
}

export interface RealtimeThinkingPayload {
  agentId: string;
  channelId: string;
}

export interface RealtimeClientToServerEvents {
  "user:message": (payload: {
    channelId: string;
    content: string;
    mentions: string[];
  }) => void;
}

export interface RealtimeServerToClientEvents {
  "agent:status": (payload: RealtimeAgentStatusPayload) => void;
  "message:new": (payload: RealtimeMessagePayload) => void;
  "message:stream": (payload: RealtimeMessageStreamPayload) => void;
  "agent:thinking": (payload: RealtimeThinkingPayload) => void;
}

let socketInstance:
  | Socket<RealtimeServerToClientEvents, RealtimeClientToServerEvents>
  | null = null;

function getRealtimeServerUrl() {
  if (typeof window === "undefined") {
    return "http://localhost:3001";
  }

  return `${window.location.protocol}//${window.location.hostname}:3001`;
}

export function getSocket() {
  if (!socketInstance) {
    socketInstance = io(getRealtimeServerUrl(), {
      autoConnect: false,
      transports: ["websocket", "polling"],
    });
  }

  return socketInstance;
}
