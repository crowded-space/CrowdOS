import { create } from 'zustand';
import type { 
  Agent, 
  Workspace, 
  Channel, 
  Message, 
  Delegation,
  GovernanceLog,
  Role,
  Tool,
  ModelProfile,
  WorkspaceSettings
} from '@/types/crowd-os';

// ── Mock Data ──
const mockAgents: Agent[] = [
  {
    id: 'agent-1',
    name: 'Architect',
    role: 'System Architect',
    level: 1,
    status: 'active',
    instructions: 'Design and oversee system architecture decisions',
    provider: 'anthropic',
    model: 'claude-3-opus',
    memoryScope: ['global', 'architecture'],
    skills: ['system-design', 'code-review', 'documentation'],
    tools: ['file-system', 'git', 'terminal'],
    permissions: [
      { id: 'p1', name: 'delegate', enabled: true },
      { id: 'p2', name: 'create-agents', enabled: true },
      { id: 'p3', name: 'modify-workspace', enabled: true },
    ],
    createdAt: new Date('2024-01-15'),
    lastActive: new Date(),
  },
  {
    id: 'agent-2',
    name: 'ResearchLead',
    role: 'Research Coordinator',
    level: 2,
    status: 'thinking',
    instructions: 'Coordinate research tasks and synthesize findings',
    provider: 'openai',
    model: 'gpt-4-turbo',
    memoryScope: ['research', 'papers'],
    skills: ['web-search', 'summarization', 'analysis'],
    tools: ['browser', 'pdf-reader', 'notion'],
    permissions: [
      { id: 'p1', name: 'delegate', enabled: true },
      { id: 'p2', name: 'create-agents', enabled: false },
    ],
    parentId: 'agent-1',
    createdAt: new Date('2024-01-20'),
    lastActive: new Date(),
  },
  {
    id: 'agent-3',
    name: 'BackendWorker',
    role: 'Backend Developer',
    level: 3,
    status: 'executing',
    instructions: 'Implement backend services and APIs',
    provider: 'anthropic',
    model: 'claude-3-sonnet',
    memoryScope: ['backend', 'api'],
    skills: ['coding', 'testing', 'debugging'],
    tools: ['file-system', 'git', 'terminal', 'database'],
    permissions: [
      { id: 'p1', name: 'delegate', enabled: true },
    ],
    parentId: 'agent-1',
    createdAt: new Date('2024-02-01'),
    lastActive: new Date(),
  },
  {
    id: 'agent-4',
    name: 'DocWorker',
    role: 'Documentation Specialist',
    level: 4,
    status: 'idle',
    instructions: 'Create and maintain documentation',
    provider: 'openai',
    model: 'gpt-4',
    memoryScope: ['docs'],
    skills: ['writing', 'markdown', 'diagrams'],
    tools: ['file-system', 'git'],
    permissions: [],
    parentId: 'agent-3',
    createdAt: new Date('2024-02-10'),
    lastActive: new Date(Date.now() - 1000 * 60 * 5),
  },
  {
    id: 'agent-5',
    name: 'Worker-12',
    role: 'General Worker',
    level: 5,
    status: 'delegating',
    instructions: 'Execute assigned tasks',
    provider: 'anthropic',
    model: 'claude-3-haiku',
    memoryScope: ['task-specific'],
    skills: ['execution'],
    tools: ['file-system'],
    permissions: [],
    parentId: 'agent-2',
    createdAt: new Date('2024-02-15'),
    lastActive: new Date(),
  },
];

const mockWorkspaces: Workspace[] = [
  {
    id: 'ws-1',
    name: 'Crowd OS',
    icon: '🌐',
    categories: [
      {
        id: 'cat-1',
        name: 'Software Engineering',
        workspaceId: 'ws-1',
        channels: [
          { id: 'ch-1', name: 'frontend-dev', categoryId: 'cat-1', unreadCount: 3, mentions: 1 },
          { id: 'ch-2', name: 'backend-dev', categoryId: 'cat-1', unreadCount: 0, mentions: 0 },
          { id: 'ch-3', name: 'testing', categoryId: 'cat-1', unreadCount: 5, mentions: 0 },
          { id: 'ch-4', name: 'devops', categoryId: 'cat-1', unreadCount: 0, mentions: 0 },
        ],
      },
      {
        id: 'cat-2',
        name: 'Research',
        workspaceId: 'ws-1',
        channels: [
          { id: 'ch-5', name: 'papers', categoryId: 'cat-2', unreadCount: 12, mentions: 2 },
          { id: 'ch-6', name: 'analysis', categoryId: 'cat-2', unreadCount: 0, mentions: 0 },
          { id: 'ch-7', name: 'experiments', categoryId: 'cat-2', unreadCount: 1, mentions: 0 },
        ],
      },
      {
        id: 'cat-3',
        name: 'Operations',
        workspaceId: 'ws-1',
        channels: [
          { id: 'ch-8', name: 'general', categoryId: 'cat-3', unreadCount: 0, mentions: 0, isActive: true },
          { id: 'ch-9', name: 'governance', categoryId: 'cat-3', unreadCount: 2, mentions: 1 },
          { id: 'ch-10', name: 'swarm-lab', categoryId: 'cat-3', unreadCount: 8, mentions: 0 },
        ],
      },
    ],
    createdAt: new Date('2024-01-01'),
  },
];

const mockMessages: Message[] = [
  {
    id: 'msg-1',
    type: 'human',
    content: 'Hey team, we need to implement the new delegation visualization feature. Can someone take the lead?',
    authorId: 'user-1',
    authorName: 'Human Operator',
    channelId: 'ch-8',
    timestamp: new Date(Date.now() - 1000 * 60 * 30),
  },
  {
    id: 'msg-2',
    type: 'agent',
    content: 'I can coordinate this. Let me analyze the requirements and delegate to the appropriate workers.',
    authorId: 'agent-1',
    authorName: 'Architect',
    channelId: 'ch-8',
    timestamp: new Date(Date.now() - 1000 * 60 * 28),
    mentions: ['user-1'],
  },
  {
    id: 'msg-3',
    type: 'delegation',
    content: 'Delegating frontend implementation task',
    authorId: 'agent-1',
    authorName: 'Architect',
    channelId: 'ch-8',
    timestamp: new Date(Date.now() - 1000 * 60 * 25),
    delegationInfo: {
      fromAgentId: 'agent-1',
      fromAgentName: 'Architect',
      toAgentId: 'agent-3',
      toAgentName: 'BackendWorker',
      task: 'Implement delegation graph component with React Flow',
      status: 'in_progress',
      startedAt: new Date(Date.now() - 1000 * 60 * 25),
    },
  },
  {
    id: 'msg-4',
    type: 'agent',
    content: 'Acknowledged. I\'m starting work on the delegation visualization. Will need to research React Flow patterns first.',
    authorId: 'agent-3',
    authorName: 'BackendWorker',
    channelId: 'ch-8',
    timestamp: new Date(Date.now() - 1000 * 60 * 24),
  },
  {
    id: 'msg-5',
    type: 'system',
    content: '@ResearchLead joined #general',
    authorId: 'system',
    authorName: 'System',
    channelId: 'ch-8',
    timestamp: new Date(Date.now() - 1000 * 60 * 20),
  },
  {
    id: 'msg-6',
    type: 'agent',
    content: 'I can help with the research component. Let me look into existing visualization libraries and patterns.',
    authorId: 'agent-2',
    authorName: 'ResearchLead',
    channelId: 'ch-8',
    timestamp: new Date(Date.now() - 1000 * 60 * 18),
  },
  {
    id: 'msg-7',
    type: 'tool_execution',
    content: 'Executing web search',
    authorId: 'agent-2',
    authorName: 'ResearchLead',
    channelId: 'ch-8',
    timestamp: new Date(Date.now() - 1000 * 60 * 17),
    toolExecution: {
      toolName: 'web-search',
      input: { query: 'React Flow delegation graph visualization patterns' },
      output: { results: 15, topResult: 'React Flow Documentation - Custom Nodes' },
      status: 'success',
      duration: 2340,
    },
  },
  {
    id: 'msg-8',
    type: 'delegation',
    content: 'Sub-delegating documentation task',
    authorId: 'agent-3',
    authorName: 'BackendWorker',
    channelId: 'ch-8',
    timestamp: new Date(Date.now() - 1000 * 60 * 15),
    delegationInfo: {
      fromAgentId: 'agent-3',
      fromAgentName: 'BackendWorker',
      toAgentId: 'agent-4',
      toAgentName: 'DocWorker',
      task: 'Document the delegation graph component API',
      status: 'pending',
      startedAt: new Date(Date.now() - 1000 * 60 * 15),
    },
  },
  {
    id: 'msg-9',
    type: 'agent',
    content: 'Found some excellent patterns. The key insight is using custom nodes with status indicators and animated edges for active delegations. Sharing my findings...',
    authorId: 'agent-2',
    authorName: 'ResearchLead',
    channelId: 'ch-8',
    timestamp: new Date(Date.now() - 1000 * 60 * 10),
  },
  {
    id: 'msg-10',
    type: 'agent',
    content: 'Perfect, integrating those patterns now. The component is taking shape. @DocWorker please start documenting the props interface.',
    authorId: 'agent-3',
    authorName: 'BackendWorker',
    channelId: 'ch-8',
    timestamp: new Date(Date.now() - 1000 * 60 * 5),
    mentions: ['agent-4'],
  },
];

const mockDelegations: Delegation[] = [
  {
    id: 'del-1',
    fromAgent: mockAgents[0],
    toAgent: mockAgents[2],
    task: 'Implement delegation graph component',
    status: 'in_progress',
    startedAt: new Date(Date.now() - 1000 * 60 * 25),
    tokenUsage: 4521,
    cost: 0.045,
    children: [
      {
        id: 'del-2',
        fromAgent: mockAgents[2],
        toAgent: mockAgents[3],
        task: 'Document component API',
        status: 'pending',
        startedAt: new Date(Date.now() - 1000 * 60 * 15),
        children: [],
      },
    ],
  },
  {
    id: 'del-3',
    fromAgent: mockAgents[0],
    toAgent: mockAgents[1],
    task: 'Research visualization patterns',
    status: 'completed',
    startedAt: new Date(Date.now() - 1000 * 60 * 20),
    completedAt: new Date(Date.now() - 1000 * 60 * 10),
    tokenUsage: 2103,
    cost: 0.021,
    children: [
      {
        id: 'del-4',
        fromAgent: mockAgents[1],
        toAgent: mockAgents[4],
        task: 'Collect library examples',
        status: 'completed',
        startedAt: new Date(Date.now() - 1000 * 60 * 18),
        completedAt: new Date(Date.now() - 1000 * 60 * 12),
        tokenUsage: 856,
        cost: 0.008,
        children: [],
      },
    ],
  },
];

const mockRoles: Role[] = [
  {
    id: 'role-1',
    name: 'Administrator',
    color: '#E74C3C',
    permissions: [
      { id: 'rp-1', name: 'manage_agents', description: 'Create, modify, delete agents', enabled: true },
      { id: 'rp-2', name: 'manage_roles', description: 'Create and modify roles', enabled: true },
      { id: 'rp-3', name: 'manage_workspace', description: 'Modify workspace settings', enabled: true },
      { id: 'rp-4', name: 'view_logs', description: 'View governance logs', enabled: true },
    ],
    memberCount: 1,
    createdAt: new Date('2024-01-01'),
  },
  {
    id: 'role-2',
    name: 'Coordinator',
    color: '#5865F2',
    permissions: [
      { id: 'rp-1', name: 'manage_agents', description: 'Create, modify, delete agents', enabled: true },
      { id: 'rp-4', name: 'view_logs', description: 'View governance logs', enabled: true },
    ],
    memberCount: 2,
    createdAt: new Date('2024-01-15'),
  },
  {
    id: 'role-3',
    name: 'Worker',
    color: '#57F287',
    permissions: [
      { id: 'rp-5', name: 'execute_tasks', description: 'Execute assigned tasks', enabled: true },
    ],
    memberCount: 3,
    createdAt: new Date('2024-02-01'),
  },
];

const mockTools: Tool[] = [
  { id: 'tool-1', name: 'file-system', description: 'Read, write, and manage files', category: 'file-system', enabled: true, usageCount: 1245 },
  { id: 'tool-2', name: 'git', description: 'Version control operations', category: 'code', enabled: true, usageCount: 892 },
  { id: 'tool-3', name: 'terminal', description: 'Execute shell commands', category: 'code', enabled: true, usageCount: 567 },
  { id: 'tool-4', name: 'web-search', description: 'Search the web for information', category: 'web', enabled: true, usageCount: 2341 },
  { id: 'tool-5', name: 'browser', description: 'Navigate and interact with websites', category: 'web', enabled: true, usageCount: 456 },
  { id: 'tool-6', name: 'database', description: 'Query and modify databases', category: 'database', enabled: false, usageCount: 123 },
  { id: 'tool-7', name: 'slack', description: 'Send messages via Slack', category: 'communication', enabled: true, usageCount: 89 },
  { id: 'tool-8', name: 'notion', description: 'Read and write Notion pages', category: 'communication', enabled: true, usageCount: 234 },
];

// ── Model Profile (Model Card) Mock Data ──
const mockModelProfiles: ModelProfile[] = [
  {
    id: 'mp-1',
    label: 'Flagship Reasoning',
    provider: 'anthropic',
    modelName: 'claude-sonnet-4-20250514',
    apiKey: 'sk-ant-mock-key-1',
    apiKeyConfigured: true,
    createdAt: new Date('2024-01-10'),
  },
  {
    id: 'mp-2',
    label: 'Fast Coder',
    provider: 'anthropic',
    modelName: 'claude-3-5-haiku-20241022',
    apiKey: 'sk-ant-mock-key-2',
    apiKeyConfigured: true,
    createdAt: new Date('2024-01-15'),
  },
  {
    id: 'mp-3',
    label: 'GPT Flagship',
    provider: 'openai',
    modelName: 'gpt-4o',
    apiKey: 'sk-openai-mock-key',
    baseUrl: '',
    apiKeyConfigured: true,
    createdAt: new Date('2024-02-01'),
  },
  {
    id: 'mp-4',
    label: 'Gemini Pro',
    provider: 'google',
    modelName: 'gemini-2.0-flash',
    apiKey: 'AIzaMockKey123',
    apiKeyConfigured: true,
    createdAt: new Date('2024-02-10'),
  },
  {
    id: 'mp-5',
    label: 'Local Ollama',
    provider: 'openai',
    modelName: 'llama3.2',
    apiKey: 'ollama-no-key-needed',
    baseUrl: 'http://localhost:11434/v1',
    apiKeyConfigured: true,
    createdAt: new Date('2024-03-01'),
  },
];



// ── Types ──
export type BottomNavTab = 'channels' | 'chat' | 'agents' | 'stats' | 'settings';

interface CrowdOSState {
  // Data
  agents: Agent[];
  workspaces: Workspace[];
  messages: Message[];
  delegations: Delegation[];
  governanceLogs: GovernanceLog[];
  roles: Role[];
  tools: Tool[];
  modelProfiles: ModelProfile[];
  
  // UI State
  activeWorkspaceId: string | null;
  activeChannelId: string | null;
  selectedAgentId: string | null;
  rightSidebarOpen: boolean;
  leftSidebarCollapsed: boolean;
  settingsModalOpen: boolean;
  agentProfileModalOpen: boolean;
  
  // ── Mobile UI State ──
  /** Current active bottom nav tab (mobile only) */
  activeMobileTab: BottomNavTab;
  /** Mobile left drawer (channel sidebar) open */
  mobileDrawerLeft: boolean;
  /** Mobile right drawer (agent list) open */
  mobileDrawerRight: boolean;
  
  // Actions
  setActiveWorkspace: (workspaceId: string) => void;
  setActiveChannel: (channelId: string) => void;
  setSelectedAgent: (agentId: string | null) => void;
  toggleRightSidebar: () => void;
  toggleLeftSidebar: () => void;
  toggleCategoryCollapse: (categoryId: string) => void;
  addMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
  updateAgentStatus: (agentId: string, status: Agent['status']) => void;
  openSettingsModal: () => void;
  closeSettingsModal: () => void;
  openAgentProfileModal: (agentId: string) => void;
  closeAgentProfileModal: () => void;
  toggleTool: (toolId: string) => void;

  // ── Model Profile CRUD ──
  addModelProfile: (profile: Omit<ModelProfile, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateModelProfile: (id: string, updates: Partial<ModelProfile>) => void;
  deleteModelProfile: (id: string) => void;
  
  // ── Mobile Actions ──
  setActiveMobileTab: (tab: BottomNavTab) => void;
  openMobileDrawerLeft: () => void;
  closeMobileDrawerLeft: () => void;
  openMobileDrawerRight: () => void;
  closeMobileDrawerRight: () => void;
  /** Select channel and close mobile drawer */
  selectChannelMobile: (channelId: string) => void;

  // ── Dynamic Workspace Actions ──
  isFetchingWorkspaces: boolean;
  isCreatingWorkspace: boolean;
  workspaceError: string | null;
  fetchWorkspaces: () => Promise<void>;
  createWorkspace: (name: string, dbUrl: string, icon: string) => Promise<void>;
  deleteWorkspace: (id: string) => Promise<void>;
  enterWorkspace: (workspaceId: string) => void;
  leaveWorkspace: () => void;
}

export const useCrowdOSStore = create<CrowdOSState>((set) => ({
  // Initial Data
  agents: mockAgents,
  workspaces: mockWorkspaces,
  messages: mockMessages,
  delegations: mockDelegations,
  governanceLogs: [],
  roles: mockRoles,
  tools: mockTools,
  modelProfiles: mockModelProfiles,
  
  // Dynamic Workspace State
  isFetchingWorkspaces: false,
  isCreatingWorkspace: false,
  workspaceError: null,

  // Initial UI State
  activeWorkspaceId: typeof window !== 'undefined' ? localStorage.getItem('crowdos_active_workspace_id') : null,
  activeChannelId: 'ch-8',
  selectedAgentId: null,
  rightSidebarOpen: true,
  leftSidebarCollapsed: false,
  settingsModalOpen: false,
  agentProfileModalOpen: false,
  
  // Mobile UI State
  activeMobileTab: 'chat',
  mobileDrawerLeft: false,
  mobileDrawerRight: false,
  
  // Actions
  setActiveWorkspace: (workspaceId) => set({ activeWorkspaceId: workspaceId }),
  
  setActiveChannel: (channelId) => set({ activeChannelId: channelId }),
  
  setSelectedAgent: (agentId) => set({ selectedAgentId: agentId }),
  
  toggleRightSidebar: () => set((state) => ({ rightSidebarOpen: !state.rightSidebarOpen })),
  
  toggleLeftSidebar: () => set((state) => ({ leftSidebarCollapsed: !state.leftSidebarCollapsed })),
  
  toggleCategoryCollapse: (categoryId) => set((state) => ({
    workspaces: state.workspaces.map((ws) => ({
      ...ws,
      categories: ws.categories.map((cat) =>
        cat.id === categoryId ? { ...cat, collapsed: !cat.collapsed } : cat
      ),
    })),
  })),
  
  addMessage: (message) => set((state) => ({
    messages: [
      ...state.messages,
      {
        ...message,
        id: `msg-${Date.now()}`,
        timestamp: new Date(),
      },
    ],
  })),
  
  updateAgentStatus: (agentId, status) => set((state) => ({
    agents: state.agents.map((agent) =>
      agent.id === agentId ? { ...agent, status, lastActive: new Date() } : agent
    ),
  })),

  openSettingsModal: () => set({ settingsModalOpen: true }),
  
  closeSettingsModal: () => set({ settingsModalOpen: false }),
  
  openAgentProfileModal: (agentId) => set({ selectedAgentId: agentId, agentProfileModalOpen: true }),
  
  closeAgentProfileModal: () => set({ agentProfileModalOpen: false, selectedAgentId: null }),
  
  toggleTool: (toolId) => set((state) => ({
    tools: state.tools.map((tool) =>
      tool.id === toolId ? { ...tool, enabled: !tool.enabled } : tool
    ),
  })),

  // ── Model Profile CRUD ──
  addModelProfile: (profile) => set((state) => ({
    modelProfiles: [
      ...state.modelProfiles,
      {
        ...profile,
        id: `mp-${Date.now()}`,
        createdAt: new Date(),
      },
    ],
  })),
  
  updateModelProfile: (id, updates) => set((state) => ({
    modelProfiles: state.modelProfiles.map((p) =>
      p.id === id ? { ...p, ...updates, updatedAt: new Date() } : p
    ),
  })),
  
  deleteModelProfile: (id) => set((state) => ({
    modelProfiles: state.modelProfiles.filter((p) => p.id !== id),
  })),

  // ── Mobile Actions ──
  setActiveMobileTab: (tab) => set({ activeMobileTab: tab }),
  
  openMobileDrawerLeft: () => set({ mobileDrawerLeft: true }),
  
  closeMobileDrawerLeft: () => set({ mobileDrawerLeft: false }),
  
  openMobileDrawerRight: () => set({ mobileDrawerRight: true }),
  
  closeMobileDrawerRight: () => set({ mobileDrawerRight: false }),
  
  selectChannelMobile: (channelId) => set({
    activeChannelId: channelId,
    mobileDrawerLeft: false,
    // Switch to chat tab on mobile when selecting a channel
    activeMobileTab: 'chat',
  }),

  // ── Dynamic Workspace Actions ──
  fetchWorkspaces: async () => {
    set({ isFetchingWorkspaces: true, workspaceError: null });
    try {
      const response = await fetch('http://localhost:3001/api/workspaces');
      if (!response.ok) throw new Error('Failed to fetch workspaces');
      const data = await response.json();
      set({ workspaces: data, isFetchingWorkspaces: false });
    } catch (error) {
      console.warn('Backend offline, using localStorage/mock fallback for workspaces:', error);
      if (typeof window !== 'undefined') {
        const cached = localStorage.getItem('crowdos_workspaces');
        if (cached) {
          try {
            set({ workspaces: JSON.parse(cached), isFetchingWorkspaces: false });
            return;
          } catch (e) {
            console.error('Failed to parse cached workspaces', e);
          }
        }
        // Save initial default
        localStorage.setItem('crowdos_workspaces', JSON.stringify([
          {
            id: 'ws-1',
            name: 'Crowd OS',
            icon: '🌐',
            categories: [
              {
                id: 'cat-1',
                name: 'Software Engineering',
                workspaceId: 'ws-1',
                channels: [
                  { id: 'ch-1', name: 'frontend-dev', categoryId: 'cat-1', unreadCount: 3, mentions: 1 },
                  { id: 'ch-2', name: 'backend-dev', categoryId: 'cat-1', unreadCount: 0, mentions: 0 },
                  { id: 'ch-3', name: 'testing', categoryId: 'cat-1', unreadCount: 5, mentions: 0 },
                  { id: 'ch-4', name: 'devops', categoryId: 'cat-1', unreadCount: 0, mentions: 0 },
                ],
              },
              {
                id: 'cat-2',
                name: 'Research',
                workspaceId: 'ws-1',
                channels: [
                  { id: 'ch-5', name: 'papers', categoryId: 'cat-2', unreadCount: 12, mentions: 2 },
                  { id: 'ch-6', name: 'analysis', categoryId: 'cat-2', unreadCount: 0, mentions: 0 },
                  { id: 'ch-7', name: 'experiments', categoryId: 'cat-2', unreadCount: 1, mentions: 0 },
                ],
              },
              {
                id: 'cat-3',
                name: 'Operations',
                workspaceId: 'ws-1',
                channels: [
                  { id: 'ch-8', name: 'general', categoryId: 'cat-3', unreadCount: 0, mentions: 0, isActive: true },
                  { id: 'ch-9', name: 'governance', categoryId: 'cat-3', unreadCount: 2, mentions: 1 },
                  { id: 'ch-10', name: 'swarm-lab', categoryId: 'cat-3', unreadCount: 8, mentions: 0 },
                ],
              },
            ],
            createdAt: new Date('2024-01-01'),
          }
        ]));
      }
      set((state) => ({ workspaces: state.workspaces, isFetchingWorkspaces: false }));
    }
  },

  createWorkspace: async (name, dbUrl, icon) => {
    set({ isCreatingWorkspace: true, workspaceError: null });
    try {
      const response = await fetch('http://localhost:3001/api/workspaces', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, dbUrl, icon })
      });
      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || 'Failed to create workspace');
      }
      const newWS = await response.json();
      set((state) => {
        const updated = [...state.workspaces, newWS];
        if (typeof window !== 'undefined') {
          localStorage.setItem('crowdos_workspaces', JSON.stringify(updated));
        }
        return { workspaces: updated, isCreatingWorkspace: false };
      });
    } catch (error) {
      console.warn('Backend offline, simulating workspace creation locally:', error);
      const localWS = {
        id: `ws-${Date.now()}`,
        name,
        icon,
        dbUrl,
        categories: [
          {
            id: `cat-${Date.now()}`,
            name: 'Operations',
            workspaceId: '',
            channels: [
              { id: `ch-${Date.now()}`, name: 'general', categoryId: `cat-${Date.now()}`, unreadCount: 0, mentions: 0, isActive: true }
            ]
          }
        ],
        createdAt: new Date()
      };
      localWS.categories[0].workspaceId = localWS.id;
      
      set((state) => {
        const updated = [...state.workspaces, localWS];
        if (typeof window !== 'undefined') {
          localStorage.setItem('crowdos_workspaces', JSON.stringify(updated));
        }
        return { workspaces: updated, isCreatingWorkspace: false };
      });
    }
  },

  deleteWorkspace: async (id) => {
    try {
      await fetch(`http://localhost:3001/api/workspaces/${id}`, { method: 'DELETE' });
    } catch (error) {
      console.warn('Backend offline, deleting workspace locally:', error);
    }
    set((state) => {
      const updated = state.workspaces.filter((w) => w.id !== id);
      if (typeof window !== 'undefined') {
        localStorage.setItem('crowdos_workspaces', JSON.stringify(updated));
      }
      const isDeletingActive = state.activeWorkspaceId === id;
      return {
        workspaces: updated,
        activeWorkspaceId: isDeletingActive ? null : state.activeWorkspaceId,
        activeChannelId: isDeletingActive ? null : state.activeChannelId
      };
    });
  },

  enterWorkspace: (workspaceId) => {
    set((state) => {
      const ws = state.workspaces.find((w) => w.id === workspaceId);
      if (!ws) return {};
      
      if (typeof window !== 'undefined') {
        localStorage.setItem('crowdos_active_workspace_id', workspaceId);
      }
      
      const firstChannelId = ws.categories?.[0]?.channels?.[0]?.id || null;
      
      return {
        activeWorkspaceId: workspaceId,
        activeChannelId: firstChannelId
      };
    });
  },

  leaveWorkspace: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('crowdos_active_workspace_id');
    }
    set({
      activeWorkspaceId: null,
      activeChannelId: null
    });
  },
}));
