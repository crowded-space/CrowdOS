// Crowd OS Type Definitions

export type AgentStatus = 
  | 'active' 
  | 'idle' 
  | 'thinking' 
  | 'delegating' 
  | 'executing' 
  | 'sleeping';

export type AgentLevel = 0 | 1 | 2 | 3 | 4 | 5;

export interface Agent {
  id: string;
  name: string;
  role: string;
  level: AgentLevel;
  status: AgentStatus;
  avatar?: string;
  instructions: string;
  /** References a ModelProfile id — replaces flat provider/model strings */
  modelProfileId?: string;
  /** Legacy fields kept for backward compatibility */
  provider: string;
  model: string;
  memoryScope: string[];
  skills: string[];
  tools: string[];
  permissions: Permission[];
  parentId?: string;
  createdAt: Date;
  lastActive: Date;
}

export interface Permission {
  id: string;
  name: string;
  enabled: boolean;
  description?: string;
}

export interface Workspace {
  id: string;
  name: string;
  icon?: string;
  dbUrl?: string;
  categories: Category[];
  createdAt: Date;
}

export interface Category {
  id: string;
  name: string;
  workspaceId: string;
  channels: Channel[];
  collapsed?: boolean;
}

export interface Channel {
  id: string;
  name: string;
  categoryId: string;
  description?: string;
  unreadCount: number;
  mentions: number;
  isActive?: boolean;
}

export type MessageType = 
  | 'human' 
  | 'agent' 
  | 'system' 
  | 'governance' 
  | 'delegation' 
  | 'tool_execution';

export interface Message {
  id: string;
  type: MessageType;
  content: string;
  authorId: string;
  authorName: string;
  authorAvatar?: string;
  channelId: string;
  timestamp: Date;
  mentions?: string[];
  delegationInfo?: DelegationInfo;
  toolExecution?: ToolExecution;
  metadata?: Record<string, unknown>;
}

export interface DelegationInfo {
  fromAgentId: string;
  fromAgentName: string;
  toAgentId: string;
  toAgentName: string;
  task: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  startedAt: Date;
  completedAt?: Date;
  cost?: number;
  tokenUsage?: number;
}

export interface ToolExecution {
  toolName: string;
  input: Record<string, unknown>;
  output?: unknown;
  status: 'running' | 'success' | 'error';
  duration?: number;
}

export interface Delegation {
  id: string;
  fromAgent: Agent;
  toAgent: Agent;
  task: string;
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  children: Delegation[];
  startedAt: Date;
  completedAt?: Date;
  cost?: number;
  tokenUsage?: number;
}

export interface GovernanceLog {
  id: string;
  action: string;
  actorId: string;
  actorName: string;
  targetType: 'agent' | 'channel' | 'workspace' | 'permission' | 'tool';
  targetId: string;
  details: string;
  timestamp: Date;
  approved: boolean;
  approvedBy?: string;
}

export interface Thread {
  id: string;
  parentMessageId: string;
  messages: Message[];
  channelId: string;
}

// Role Management Types
export interface Role {
  id: string;
  name: string;
  color: string;
  permissions: RolePermission[];
  memberCount: number;
  createdAt: Date;
}

export interface RolePermission {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
}

// Tool Types
export interface Tool {
  id: string;
  name: string;
  description: string;
  category: 'file-system' | 'web' | 'database' | 'communication' | 'code' | 'ai';
  enabled: boolean;
  usageCount: number;
  lastUsed?: Date;
}

// ── Model Profile Types (Model Cards) ──

export type ProviderType = 'google' | 'openai' | 'anthropic';

/** A saved model configuration card — like a Discord role, assignable to agents */
export interface ModelProfile {
  id: string;
  /** User-defined label (e.g. "Flagship Reasoning", "Fast Coder") */
  label: string;
  /** The LLM provider engine */
  provider: ProviderType;
  /** Exact model name string — never modified by system */
  modelName: string;
  /** API key (stored as masked in UI) */
  apiKey?: string;
  /** Custom base URL — primarily for OpenAI-compatible endpoints */
  baseUrl?: string;
  /** Whether the API key has been configured */
  apiKeyConfigured: boolean;
  createdAt: Date;
  updatedAt?: Date;
}

// Workspace Settings
export interface WorkspaceSettings {
  id: string;
  workspaceId: string;
  defaultModel: string;
  maxConcurrentAgents: number;
  allowAgentCreation: boolean;
  allowDelegation: boolean;
  maxDelegationDepth: number;
  costLimit: number;
  tokenLimit: number;
}
