import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { WorkspaceSidebar } from '@/components/workspace/workspace-sidebar';
import { MainChatArea } from '@/components/workspace/main-chat-area';
import { RightSidebar } from '@/components/workspace/right-sidebar';
import { AgentProfileModal } from '@/components/workspace/modals/agent-profile-modal';
import { WorkspaceSettingsModal } from '@/components/workspace/modals/workspace-settings-modal';
import { BottomNav } from '@/components/workspace/mobile/bottom-nav';
import { MobileDrawer } from '@/components/workspace/mobile/mobile-drawer';
import { WorkspacePortal } from '@/components/portal/WorkspacePortal';

export default function App() {
  const {
    rightSidebarOpen,
    leftSidebarCollapsed,
    activeWorkspaceId,
    // Mobile state
    mobileDrawerLeft,
    mobileDrawerRight,
    closeMobileDrawerLeft,
    closeMobileDrawerRight,
  } = useCrowdOSStore();

  if (!activeWorkspaceId) {
    return <WorkspacePortal />;
  }

  return (
    <>
      <div className="flex h-screen overflow-hidden bg-background">
        {/* ── Desktop Left Sidebar (hidden on mobile) ── */}
        <div className="desktop-only flex">
          <WorkspaceSidebar collapsed={leftSidebarCollapsed} />
        </div>

        {/* ── Mobile Left Drawer (slide-over) ── */}
        <MobileDrawer
          open={mobileDrawerLeft}
          onClose={closeMobileDrawerLeft}
          side="left"
          ariaLabel="Channel sidebar"
        >
          <WorkspaceSidebar collapsed={false} inDrawer={true} />
        </MobileDrawer>

        {/* ── Main Chat / Activity Area ── */}
        <MainChatArea />

        {/* ── Desktop Right Sidebar (hidden on mobile) ── */}
        <div className="desktop-only flex">
          {rightSidebarOpen && <RightSidebar />}
        </div>

        {/* ── Mobile Right Drawer (agent list) ── */}
        <MobileDrawer
          open={mobileDrawerRight}
          onClose={closeMobileDrawerRight}
          side="right"
          ariaLabel="Agent list"
        >
          <RightSidebar />
        </MobileDrawer>
      </div>

      {/* ── Mobile Bottom Navigation ── */}
      <BottomNav />

      {/* ── Modals ── */}
      <AgentProfileModal />
      <WorkspaceSettingsModal />
    </>
  );
}
