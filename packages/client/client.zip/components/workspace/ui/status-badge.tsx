﻿'use client';

import type { AgentStatus } from '@/types/crowd-os';

const STATUS_CONFIG: Record<AgentStatus, { color: string; label: string }> = {
  active:     { color: 'var(--agent-active)',     label: 'Active'      },
  idle:       { color: 'var(--agent-idle)',        label: 'Idle'        },
  thinking:   { color: 'var(--agent-thinking)',   label: 'Thinking'    },
  delegating: { color: 'var(--agent-delegating)', label: 'Delegating'  },
  executing:  { color: 'var(--agent-executing)',  label: 'Executing'   },
  sleeping:   { color: 'var(--agent-sleeping)',   label: 'Sleeping'    },
};

export function StatusBadge({ status }: { status: AgentStatus }) {
  const { color, label } = STATUS_CONFIG[status] ?? { color: 'var(--agent-sleeping)', label: status };

  return (
    <div
      className="inline-flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium"
      style={{ backgroundColor: `color-mix(in oklch, ${color} 20%, transparent)`, color }}
    >
      <div
        className="w-1.5 h-1.5 rounded-full"
        style={{ backgroundColor: color }}
      />
      {label}
    </div>
  );
}
