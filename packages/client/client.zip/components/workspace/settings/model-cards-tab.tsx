'use client';

import { useState } from 'react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { ModelCardForm } from './model-card-form';
import type { ModelProfile, ProviderType } from '@/types/crowd-os';
import {
  Plus,
  Trash2,
  Pencil,
  Cpu,
  Check,
  X,
  AlertCircle,
  Loader2,
  Bot,
  Globe,
  Database,
} from 'lucide-react';

// ── Provider display config ──
const PROVIDER_META: Record<ProviderType, { label: string; color: string; bg: string }> = {
  google: {
    label: 'Google AI',
    color: 'var(--agent-active)',
    bg: 'color-mix(in oklch, var(--agent-active) 15%, transparent)',
  },
  openai: {
    label: 'OpenAI',
    color: 'var(--agent-thinking)',
    bg: 'color-mix(in oklch, var(--agent-thinking) 15%, transparent)',
  },
  anthropic: {
    label: 'Anthropic',
    color: 'var(--agent-delegating)',
    bg: 'color-mix(in oklch, var(--agent-delegating) 15%, transparent)',
  },
};

export function ModelCardsTab() {
  const { modelProfiles, agents, deleteModelProfile, updateModelProfile } = useCrowdOSStore();

  const [showForm, setShowForm] = useState(false);
  const [editingProfile, setEditingProfile] = useState<ModelProfile | undefined>(undefined);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, { ok: boolean; message: string }>>({});
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const handleAdd = () => {
    setEditingProfile(undefined);
    setShowForm(true);
  };

  const handleEdit = (profile: ModelProfile) => {
    setEditingProfile(profile);
    setShowForm(true);
  };

  const handleDelete = (id: string) => {
    deleteModelProfile(id);
    setConfirmDeleteId(null);
  };

  const handleTestConnection = async (profile: ModelProfile) => {
    if (!profile.apiKeyConfigured) return;
    setTestingId(profile.id);
    setTestResults((prev) => {
      const next = { ...prev };
      delete next[profile.id];
      return next;
    });

    // Simulate connection test (no backend yet — always succeeds)
    await new Promise((r) => setTimeout(r, 1500));

    const meta = PROVIDER_META[profile.provider];
    setTestResults((prev) => ({
      ...prev,
      [profile.id]: {
        ok: true,
        message: `Connected to ${meta.label} — ${profile.modelName} is reachable.`,
      },
    }));
    setTestingId(null);
  };

  // Count agents using each model profile
  const agentCountByProfile = agents.reduce<Record<string, number>>((acc, agent) => {
    if (agent.modelProfileId) {
      acc[agent.modelProfileId] = (acc[agent.modelProfileId] || 0) + 1;
    }
    return acc;
  }, {});

  if (showForm) {
    return (
      <ModelCardForm
        editProfile={editingProfile}
        onClose={() => {
          setShowForm(false);
          setEditingProfile(undefined);
        }}
      />
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">
            Create and manage model profiles — assign them to agents like Discord roles.
          </p>
        </div>
        <button
          onClick={handleAdd}
          className="flex items-center gap-1.5 px-3 py-2 text-sm rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors font-medium"
        >
          <Plus className="w-4 h-4" />
          New Card
        </button>
      </div>

      {/* Cards list */}
      {modelProfiles.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-2xl bg-card border border-border flex items-center justify-center mb-4">
            <Cpu className="w-8 h-8 text-muted-foreground" />
          </div>
          <h3 className="text-base font-semibold mb-1">No model cards yet</h3>
          <p className="text-sm text-muted-foreground max-w-sm">
            Create your first model card to configure an LLM provider. Cards can be assigned to agents later.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {modelProfiles.map((profile) => {
            const meta = PROVIDER_META[profile.provider];
            const testResult = testResults[profile.id];
            const isTesting = testingId === profile.id;
            const usedByCount = agentCountByProfile[profile.id] || 0;

            return (
              <div
                key={profile.id}
                className="bg-card rounded-lg border border-border overflow-hidden group"
              >
                {/* Main row */}
                <div className="flex items-center gap-3 p-4">
                  {/* Provider icon */}
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                    style={{ backgroundColor: meta.bg }}
                  >
                    <Cpu className="w-5 h-5" style={{ color: meta.color }} />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm truncate">{profile.label}</span>
                      <span
                        className="text-[10px] font-medium px-1.5 py-0.5 rounded shrink-0"
                        style={{ backgroundColor: meta.bg, color: meta.color }}
                      >
                        {meta.label}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <code className="text-xs font-mono text-muted-foreground truncate">
                        {profile.modelName}
                      </code>
                      {profile.baseUrl && (
                        <span className="text-[10px] text-muted-foreground flex items-center gap-1 shrink-0">
                          <Globe className="w-3 h-3" />
                          Custom endpoint
                        </span>
                      )}
                    </div>
                  </div>

                  {/* API key status */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    {profile.apiKeyConfigured ? (
                      <span className="flex items-center gap-1 text-xs text-agent-active">
                        <Check className="w-3 h-3" />
                        Key set
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-xs text-agent-idle">
                        <AlertCircle className="w-3 h-3" />
                        No key
                      </span>
                    )}
                  </div>

                  {/* Used by count */}
                  {usedByCount > 0 && (
                    <div className="flex items-center gap-1 shrink-0 px-2 py-1 rounded-md bg-secondary text-xs text-muted-foreground">
                      <Bot className="w-3 h-3" />
                      {usedByCount} agent{usedByCount !== 1 ? 's' : ''}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center gap-1 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => handleEdit(profile)}
                      className="p-1.5 rounded-md hover:bg-accent transition-colors"
                      title="Edit card"
                    >
                      <Pencil className="w-4 h-4 text-muted-foreground" />
                    </button>
                    {confirmDeleteId === profile.id ? (
                      <>
                        <button
                          onClick={() => handleDelete(profile.id)}
                          className="p-1.5 rounded-md bg-destructive/20 hover:bg-destructive/40 transition-colors"
                          title="Confirm delete"
                        >
                          <Check className="w-4 h-4 text-destructive" />
                        </button>
                        <button
                          onClick={() => setConfirmDeleteId(null)}
                          className="p-1.5 rounded-md hover:bg-accent transition-colors"
                          title="Cancel delete"
                        >
                          <X className="w-4 h-4 text-muted-foreground" />
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => setConfirmDeleteId(profile.id)}
                        className="p-1.5 rounded-md hover:bg-destructive/20 transition-colors"
                        title="Delete card"
                      >
                        <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Base URL row (if set) */}
                {profile.baseUrl && (
                  <div className="px-4 pb-3 -mt-1">
                    <code className="text-xs font-mono text-muted-foreground bg-secondary px-2 py-1 rounded">
                      {profile.baseUrl}
                    </code>
                  </div>
                )}

                {/* Test connection row */}
                <div className="px-4 pb-3 flex items-center gap-2">
                  <button
                    onClick={() => handleTestConnection(profile)}
                    disabled={isTesting || !profile.apiKeyConfigured}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs rounded-md border border-border hover:bg-accent transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    {isTesting ? (
                      <>
                        <Loader2 className="w-3 h-3 animate-spin" />
                        Testing...
                      </>
                    ) : (
                      <>
                        <Database className="w-3 h-3" />
                        Test Connection
                      </>
                    )}
                  </button>

                  {testResult && (
                    <span
                      className={`flex items-center gap-1 text-xs ${
                        testResult.ok ? 'text-agent-active' : 'text-destructive'
                      }`}
                    >
                      {testResult.ok ? (
                        <Check className="w-3 h-3" />
                      ) : (
                        <AlertCircle className="w-3 h-3" />
                      )}
                      {testResult.message}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
