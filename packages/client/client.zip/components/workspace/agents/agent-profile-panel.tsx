'use client';

import { X } from 'lucide-react';
import { StatusBadge } from '../ui/status-badge';
import type { Agent } from '@/types/crowd-os';

interface AgentProfilePanelProps {
  agent: Agent;
  onClose: () => void;
}

export function AgentProfilePanel({ agent, onClose }: AgentProfilePanelProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-end z-50">
      <div className="w-full sm:w-96 bg-slate-900 border-t border-slate-700 max-h-[80vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-start justify-between p-4 border-b border-slate-700 sticky top-0 bg-slate-900">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm`}>
              {agent.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">{agent.name}</h2>
              <p className="text-xs text-gray-400">{agent.role}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Status & Level */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-400 uppercase">Status</p>
            <StatusBadge status={agent.status} />
            <p className="text-sm text-gray-300 mt-2">Level: <span className="font-bold">{agent.level}</span></p>
          </div>

          {/* Instructions */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-400 uppercase">Instructions</p>
            <p className="text-sm text-gray-300 bg-slate-800 p-3 rounded">{agent.instructions}</p>
          </div>

          {/* Model */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-400 uppercase">Model</p>
            <div className="bg-slate-800 p-3 rounded space-y-1">
              <p className="text-sm text-gray-300"><span className="text-gray-500">Provider:</span> {agent.provider}</p>
              <p className="text-sm text-gray-300"><span className="text-gray-500">Model:</span> {agent.model}</p>
            </div>
          </div>

          {/* Memory Scope */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-400 uppercase">Memory Scope</p>
            <div className="flex flex-wrap gap-1">
              {agent.memoryScope.map((scope) => (
                <span key={scope} className="text-xs bg-blue-600/30 text-blue-200 px-2 py-1 rounded">
                  {scope}
                </span>
              ))}
            </div>
          </div>

          {/* Skills */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-400 uppercase">Skills</p>
            <div className="flex flex-wrap gap-1">
              {agent.skills.map((skill) => (
                <span key={skill} className="text-xs bg-green-600/30 text-green-200 px-2 py-1 rounded">
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Tools */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-400 uppercase">Tools</p>
            <div className="flex flex-wrap gap-1">
              {agent.tools.map((tool) => (
                <span key={tool} className="text-xs bg-purple-600/30 text-purple-200 px-2 py-1 rounded">
                  {tool}
                </span>
              ))}
            </div>
          </div>

          {/* Permissions */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-400 uppercase">Permissions</p>
            <div className="space-y-1">
              {agent.permissions.map((perm) => (
                <div key={perm.id} className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={perm.enabled} disabled className="w-4 h-4" />
                  <span className={perm.enabled ? 'text-gray-300' : 'text-gray-500'}>{perm.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Hierarchy */}
          {agent.parentId && (
            <div className="space-y-2 border-t border-slate-700 pt-4">
              <p className="text-xs font-semibold text-gray-400 uppercase">Parent Agent</p>
              <p className="text-sm text-gray-300">Delegated by parent agent</p>
            </div>
          )}

          {/* Timestamps */}
          <div className="space-y-2 border-t border-slate-700 pt-4 text-xs text-gray-500">
            <p>Created: {agent.createdAt.toLocaleDateString()}</p>
            <p>Last Active: {agent.lastActive.toLocaleString()}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
