﻿'use client';

import { useEffect, useRef } from 'react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { Message } from './messages/message';
import {
  Hash,
  Bell,
  Pin,
  Users,
  Search,
  Inbox,
  HelpCircle,
  PlusCircle,
  Smile,
  Send,
} from 'lucide-react';
import type { Message as MessageType } from '@/types/crowd-os';

const NON_GROUPABLE = new Set(['system', 'delegation', 'tool_execution', 'governance']);

function isCompact(msg: MessageType, prev: MessageType | undefined): boolean {
  if (!prev) return false;
  if (NON_GROUPABLE.has(msg.type) || NON_GROUPABLE.has(prev.type)) return false;
  if (msg.authorId !== prev.authorId) return false;
  return msg.timestamp.getTime() - prev.timestamp.getTime() < 5 * 60 * 1000;
}

export function MainChatArea() {
  const {
    workspaces,
    activeWorkspaceId,
    activeChannelId,
    messages,
    agents,
    addMessage,
    toggleRightSidebar,
    rightSidebarOpen,
    openMobileDrawerLeft,
  } = useCrowdOSStore();

  const endRef = useRef<HTMLDivElement>(null);
  const ws = workspaces.find((w) => w.id === activeWorkspaceId);
  const ch = ws?.categories.flatMap((c) => c.channels).find((c) => c.id === activeChannelId);
  const chMsgs = messages.filter((m) => m.channelId === activeChannelId);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [chMsgs]);

  const handleSend = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const txt = (fd.get('message') as string)?.trim();
    if (txt) {
      addMessage({ type: 'human', content: txt, authorId: 'user-1', authorName: 'Human Operator', channelId: activeChannelId || 'ch-8' });
      e.currentTarget.reset();
    }
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 pb-[env(safe-area-inset-bottom,0px)] lg:pb-0" style={{ backgroundColor: 'var(--background)' }}>
      {/* ── Channel Header ── */}
      <div
        className="h-12 sm:h-14 md:h-16 flex items-center justify-between px-3 sm:px-4 shrink-0"
        style={{ borderBottom: '1px solid var(--border)', boxShadow: '0 1px 0 color-mix(in oklch, var(--border) 30%, transparent)' }}
      >
        <div className="flex items-center gap-2 min-w-0">
          {/* Mobile hamburger — hidden on desktop */}
          <button
            onClick={openMobileDrawerLeft}
            className="mobile-only p-1.5 -ml-1 rounded-md hover:bg-accent/50 transition-colors"
            aria-label="Open channels"
          >
            <Hash className="w-5 h-5" style={{ color: 'var(--muted-foreground)' }} />
          </button>
          <Hash className="w-5 h-5 shrink-0 desktop-only" style={{ color: 'var(--muted-foreground)' }} />
          <h1 className="font-semibold text-[15px] truncate">{ch?.name}</h1>
          <div className="h-6 w-px mx-2 shrink-0 desktop-only" style={{ backgroundColor: 'var(--border)' }} />
          <span className="text-[13px] text-muted-foreground truncate hidden md:block">
            Agent collaboration workspace
          </span>
        </div>

        {/* Right toolbar */}
        <div className="flex items-center gap-0.5 sm:gap-1 shrink-0">
          {/* Desktop-only toolbar buttons */}
          <div className="desktop-only flex items-center gap-0.5">
            {[
              { icon: Bell, label: 'Notifications' },
              { icon: Pin, label: 'Pinned Messages' },
            ].map(({ icon: Icon, label }) => (
              <button
                key={label}
                className="p-1.5 rounded transition-colors text-muted-foreground hover:text-foreground"
                title={label}
              >
                <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            ))}
          </div>

          {/* Member list toggle — visible on all sizes */}
          <button
            onClick={toggleRightSidebar}
            className="p-1.5 rounded transition-colors desktop-only"
            title="Member List"
            style={{
              color: rightSidebarOpen ? 'var(--foreground)' : 'var(--muted-foreground)',
            }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = 'var(--foreground)'; }}
            onMouseLeave={(e) => { if (!rightSidebarOpen) (e.currentTarget as HTMLButtonElement).style.color = 'var(--muted-foreground)'; }}
          >
            <Users className="w-4 h-4 sm:w-5 sm:h-5" />
          </button>

          {/* Search box — desktop only */}
          <div className="relative ml-1 desktop-only">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground pointer-events-none" />
            <input
              type="text"
              placeholder="Search"
              className="w-[120px] lg:w-[144px] pl-7 pr-2 py-1 rounded text-[13px] outline-none focus:w-[160px] lg:focus:w-[200px] transition-all placeholder:text-muted-foreground"
              style={{ backgroundColor: 'var(--input)', border: '1px solid transparent' }}
              onFocus={(e) => { (e.currentTarget as HTMLInputElement).style.borderColor = 'var(--ring)'; }}
              onBlur={(e) => { (e.currentTarget as HTMLInputElement).style.borderColor = 'transparent'; }}
            />
          </div>

          {/* Desktop-only icons */}
          <div className="desktop-only flex items-center">
            <button className="p-1.5 rounded text-muted-foreground hover:text-foreground transition-colors" title="Inbox">
              <Inbox className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
            <button className="p-1.5 rounded text-muted-foreground hover:text-foreground transition-colors" title="Help">
              <HelpCircle className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* ── Messages ── */}
      <div className="flex-1 overflow-y-auto">
        {chMsgs.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center px-4 max-w-md mx-auto animate-fade-in-up">
            <div
              className="w-14 h-14 sm:w-[68px] sm:h-[68px] rounded-full flex items-center justify-center mb-3 sm:mb-4"
              style={{ backgroundColor: 'var(--card)' }}
            >
              <Hash className="w-8 h-8 sm:w-10 sm:h-10 text-muted-foreground" />
            </div>
            <h2 className="text-xl sm:text-[32px] font-bold mb-1.5 sm:mb-2">Welcome to #{ch?.name}!</h2>
            <p className="text-muted-foreground text-sm sm:text-[15px] max-w-[420px]">
              This is the beginning of the <strong>#{ch?.name}</strong> channel.
            </p>
          </div>
        ) : (
          <div className="py-3 sm:py-4 px-2 sm:px-4">
            {chMsgs.map((msg, idx) => {
              const prev = idx > 0 ? chMsgs[idx - 1] : undefined;
              return (
                <Message
                  key={msg.id}
                  message={msg}
                  agents={agents}
                  compact={isCompact(msg, prev)}
                />
              );
            })}
            <div ref={endRef} />
          </div>
        )}
      </div>

      {/* ── Composer ── */}
      <div className="composer-container px-2 sm:px-4 pb-2 sm:pb-3 md:pb-6 pt-0 shrink-0">
        <form onSubmit={handleSend}>
          <div
            className="flex items-center rounded-lg"
            style={{
              backgroundColor: 'var(--input)',
              border: 'none',
            }}
          >
            <button
              type="button"
              className="px-3 sm:px-4 py-2.5 shrink-0 text-muted-foreground hover:text-foreground transition-colors"
            >
              <PlusCircle className="w-5 h-5 sm:w-6 sm:h-6" />
            </button>
            <input
              type="text"
              name="message"
              autoComplete="off"
              placeholder={`Message #${ch?.name}`}
              className="flex-1 bg-transparent py-[11px] text-[15px] outline-none placeholder:text-muted-foreground min-w-0"
            />
            <div className="flex items-center gap-0.5 pr-2 sm:pr-3 shrink-0">
              <button type="button" className="p-1.5 text-muted-foreground hover:text-foreground transition-colors rounded">
                <Smile className="w-5 h-5 sm:w-[22px] sm:h-[22px]" />
              </button>
              <button
                type="submit"
                className="p-1.5 transition-colors rounded"
                style={{ color: 'var(--primary)' }}
              >
                <Send className="w-5 h-5 sm:w-[22px] sm:h-[22px]" />
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

