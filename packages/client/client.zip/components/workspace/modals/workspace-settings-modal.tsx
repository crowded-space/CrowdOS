﻿'use client';

import { useState } from 'react';
import { useCrowdOSStore } from '@/stores/crowd-os-store';
import { 
  X, 
  Bot, 
  Shield, 
  Wrench, 
  Cpu, 
  Settings, 
  Hash, 
  Bell, 
  Lock,
  Trash2,
  Search,
  MoreVertical,
  ChevronDown
} from 'lucide-react';
import { ModelCardsTab } from '@/components/workspace/settings/model-cards-tab';
import { formatDistanceToNow } from 'date-fns';

type SettingsTab = 'overview' | 'agents' | 'roles' | 'tools' | 'model-cards' | 'channels' | 'safety';

const STATUS_COLORS: Record<string, string> = {
  active: 'var(--agent-active)',
  idle: 'var(--agent-idle)',
  thinking: 'var(--agent-thinking)',
  delegating: 'var(--agent-delegating)',
  executing: 'var(--agent-executing)',
  sleeping: 'var(--agent-sleeping)',
};

export function WorkspaceSettingsModal() {
  const { 
    settingsModalOpen, 
    closeSettingsModal, 
    workspaces, 
    activeWorkspaceId,
    agents,
    roles,
    tools,
    toggleTool,
    openAgentProfileModal
  } = useCrowdOSStore();
  
  const [activeTab, setActiveTab] = useState<SettingsTab>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  
  const workspace = workspaces.find(ws => ws.id === activeWorkspaceId);
  
  if (!settingsModalOpen || !workspace) return null;
  
  const tabs: { id: SettingsTab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Overview', icon: <Settings className="w-4 h-4" /> },
    { id: 'agents', label: 'Agents', icon: <Bot className="w-4 h-4" /> },
    { id: 'roles', label: 'Roles', icon: <Shield className="w-4 h-4" /> },
    { id: 'tools', label: 'Tools', icon: <Wrench className="w-4 h-4" /> },
    { id: 'model-cards', label: 'Model Cards', icon: <Cpu className="w-4 h-4" /> },
    { id: 'channels', label: 'Channels', icon: <Hash className="w-4 h-4" /> },
    { id: 'safety', label: 'Safety', icon: <Lock className="w-4 h-4" /> },
  ];
  
  const filteredAgents = agents.filter(a => 
    a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={closeSettingsModal}
      />
      
      {/* Modal — full-screen on mobile, centered on desktop */}
      <div 
        className="
          relative 
          w-full h-full sm:w-[90vw] sm:max-w-[880px] sm:h-[85vh] sm:max-h-[680px]
          bg-background 
          rounded-none sm:rounded-lg 
          overflow-hidden 
          shadow-2xl 
          flex flex-col
        "
        role="dialog"
        aria-modal="true"
        aria-label="Workspace settings"
      >
        {/* Mobile header with tabs (horizontal scroll) */}
        <div className="sm:hidden flex items-center justify-between px-3 py-2 border-b border-border shrink-0">
          <h2 className="text-sm font-semibold">Settings</h2>
          <button onClick={closeSettingsModal} className="p-1.5 rounded-md hover:bg-accent/50 transition-colors" aria-label="Close settings">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="sm:hidden flex gap-1 px-2 pb-2 overflow-x-auto shrink-0 border-b border-border scrollbar-none">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs whitespace-nowrap transition-colors ${
                activeTab === tab.id 
                  ? 'bg-accent text-accent-foreground' 
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        {/* Desktop layout: sidebar + content */}
        <div className="hidden sm:flex flex-1 overflow-hidden">
          {/* Sidebar */}
          <div className="w-[200px] bg-sidebar border-r border-border flex flex-col shrink-0">
          <div className="p-3 border-b border-border flex items-center justify-center">
            <img src="/icon_only_dark.png" alt="Crowd OS" className="h-6 w-6 rounded-md object-cover" />
          </div>
          
          <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded text-sm transition-colors ${
                  activeTab === tab.id 
                    ? 'bg-accent text-accent-foreground' 
                    : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
        
        {/* Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header — desktop only */}
          <div className="hidden sm:flex items-center justify-between p-4 border-b border-border shrink-0">
            <h1 className="text-lg font-semibold">
              {tabs.find(t => t.id === activeTab)?.label}
            </h1>
            <button 
              onClick={closeSettingsModal}
              className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              ESC
              <X className="w-4 h-4" />
            </button>
          </div>
          
          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto p-3 sm:p-4 pb-[calc(env(safe-area-inset-bottom,0px)+16px)] sm:pb-4">
            {activeTab === 'overview' && (
              <OverviewTab workspace={workspace} agents={agents} />
            )}
            
            {activeTab === 'agents' && (
              <AgentsTab 
                agents={filteredAgents} 
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                onAgentClick={(id) => {
                  closeSettingsModal();
                  openAgentProfileModal(id);
                }}
              />
            )}
            
            {activeTab === 'roles' && (
              <RolesTab roles={roles} />
            )}
            
            {activeTab === 'tools' && (
              <ToolsTab tools={tools} toggleTool={toggleTool} />
            )}
            
            {activeTab === 'model-cards' && (
              <ModelCardsTab />
            )}
            
            {activeTab === 'channels' && (
              <ChannelsTab workspace={workspace} />
            )}
            
            {activeTab === 'safety' && (
              <SafetyTab />
            )}          </div>
        </div>
      </div>
    </div>
    </div>
  );
}



// Overview Tab
function OverviewTab({ workspace, agents }: { workspace: any; agents: any[] }) {
  const activeAgents = agents.filter(a => a.status !== 'sleeping').length;
  
  return (
    <div className="space-y-6">
      <div className="flex items-start gap-4">
        <div className="w-20 h-20 rounded-2xl overflow-hidden bg-[#0A0A0C] border border-border flex items-center justify-center">
          <img 
            src="/icon_only_dark.png" alt="Crowd OS" className="w-full h-full object-cover rounded-2xl" 
          />
        </div>
        <div className="flex-1">
          <h2 className="text-xl font-semibold">{workspace.name}</h2>
          <p className="text-sm text-muted-foreground mt-1">
            AI agent orchestration workspace
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-4">
        <div className="p-4 bg-card rounded-lg border border-border">
          <div className="text-2xl font-bold">{agents.length}</div>
          <div className="text-sm text-muted-foreground">Total Agents</div>
        </div>
        <div className="p-4 bg-card rounded-lg border border-border">
          <div className="text-2xl font-bold" style={{ color: 'var(--agent-active)' }}>{activeAgents}</div>
          <div className="text-sm text-muted-foreground">Active Now</div>
        </div>
        <div className="p-4 bg-card rounded-lg border border-border">
          <div className="text-2xl font-bold">{workspace.categories.reduce((acc: number, cat: any) => acc + cat.channels.length, 0)}</div>
          <div className="text-sm text-muted-foreground">Channels</div>
        </div>
      </div>
      
      <div className="space-y-3">
        <h3 className="text-sm font-semibold uppercase text-muted-foreground">Settings</h3>
        
        <div className="space-y-2">
          <SettingRow 
            label="Allow Agent Creation" 
            description="Agents can create sub-agents"
            enabled={true}
          />
          <SettingRow 
            label="Allow Delegation" 
            description="Agents can delegate tasks to others"
            enabled={true}
          />
          <SettingRow 
            label="Max Delegation Depth" 
            description="Maximum levels of delegation"
            value="5"
          />
          <SettingRow 
            label="Cost Limit" 
            description="Maximum daily spend"
            value="$100.00"
          />
        </div>
      </div>
    </div>
  );
}

function SettingRow({ label, description, enabled, value }: { label: string; description: string; enabled?: boolean; value?: string }) {
  return (
    <div className="flex items-center justify-between p-3 bg-card rounded-lg border border-border">
      <div>
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs text-muted-foreground">{description}</div>
      </div>
      {value !== undefined ? (
        <div className="text-sm font-medium">{value}</div>
      ) : (
        <div className={`w-10 h-5 rounded-full transition-colors ${enabled ? '' : 'bg-muted'} relative`} style={enabled ? { backgroundColor: 'var(--agent-active)' } : undefined}>
          <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${enabled ? 'left-5' : 'left-0.5'}`} />
        </div>
      )}
    </div>
  );
}

// Agents Tab
function AgentsTab({ agents, searchQuery, setSearchQuery, onAgentClick }: { 
  agents: any[]; 
  searchQuery: string; 
  setSearchQuery: (q: string) => void;
  onAgentClick: (id: string) => void;
}) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Show Agents in Channel List</span>
          <div className="w-10 h-5 rounded-full bg-green-500 relative">
            <div className="absolute top-0.5 left-5 w-4 h-4 rounded-full bg-white shadow" />
          </div>
        </div>
      </div>
      
      <p className="text-sm text-muted-foreground">
        Manage all agents in your workspace. Click an agent to view their profile.
      </p>
      
      {/* Search and Actions */}
      <div className="flex items-center gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name or role"
            className="w-full pl-10 pr-4 py-2 bg-input border border-border rounded-md text-sm outline-none focus:ring-1 focus:ring-ring"
          />
        </div>
        <button className="flex items-center gap-2 px-3 py-2 bg-secondary rounded-md text-sm hover:bg-secondary/80">
          Sort
          <ChevronDown className="w-4 h-4" />
        </button>
        <button className="px-3 py-2 bg-destructive text-destructive-foreground rounded-md text-sm hover:bg-destructive/90">
          Prune
        </button>
      </div>
      
      {/* Table */}
      <div className="border border-border rounded-lg overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-card text-left text-xs text-muted-foreground uppercase">
              <th className="p-3 font-medium">Name</th>
              <th className="p-3 font-medium">Status</th>
              <th className="p-3 font-medium">Role</th>
              <th className="p-3 font-medium">Level</th>
              <th className="p-3 font-medium">Last Active</th>
              <th className="p-3 w-10"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {agents.map(agent => (
              <tr 
                key={agent.id} 
                className="hover:bg-card/50 cursor-pointer transition-colors"
                onClick={() => onAgentClick(agent.id)}
              >
                <td className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                        <Bot className="w-4 h-4 text-muted-foreground" />
                      </div>
                      <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-background" style={{ backgroundColor: STATUS_COLORS[agent.status] }} />
                    </div>
                    <div>
                      <div className="font-medium text-sm">{agent.name}</div>
                      <div className="text-xs text-muted-foreground">{agent.model}</div>
                    </div>
                  </div>
                </td>
                <td className="p-3">
                  <span
                    className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs"
                    style={{
                      backgroundColor: `color-mix(in oklch, ${STATUS_COLORS[agent.status]} 20%, transparent)`,
                      color: STATUS_COLORS[agent.status],
                    }}
                  >
                    <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: STATUS_COLORS[agent.status] }} />
                    {agent.status}
                  </span>
                </td>
                <td className="p-3 text-sm text-muted-foreground">{agent.role}</td>
                <td className="p-3">
                  <span className="px-2 py-0.5 text-xs rounded bg-primary/20 text-primary">
                    L{agent.level}
                  </span>
                </td>
                <td className="p-3 text-sm text-muted-foreground">
                  {formatDistanceToNow(agent.lastActive, { addSuffix: true })}
                </td>
                <td className="p-3">
                  <button className="p-1 hover:bg-accent rounded" onClick={(e) => e.stopPropagation()}>
                    <MoreVertical className="w-4 h-4 text-muted-foreground" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <span>Showing {agents.length} agents</span>
        <div className="flex items-center gap-2">
          <button className="px-3 py-1 hover:bg-accent rounded">Back</button>
          <span className="px-2 py-1 bg-primary text-primary-foreground rounded">1</span>
          <button className="px-3 py-1 hover:bg-accent rounded">Next</button>
        </div>
      </div>
    </div>
  );
}

// Roles Tab
function RolesTab({ roles }: { roles: any[] }) {
  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Manage roles and permissions for agents in your workspace.
      </p>
      
      <div className="space-y-2">
        {roles.map(role => (
          <div key={role.id} className="flex items-center justify-between p-4 bg-card rounded-lg border border-border hover:border-border/80 transition-colors">
            <div className="flex items-center gap-3">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: role.color }}
              />
              <div>
                <div className="font-medium">{role.name}</div>
                <div className="text-xs text-muted-foreground">
                  {role.memberCount} agent{role.memberCount !== 1 ? 's' : ''} - {role.permissions.length} permissions
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="p-2 hover:bg-accent rounded">
                <Settings className="w-4 h-4 text-muted-foreground" />
              </button>
              <button className="p-2 hover:bg-destructive/20 rounded">
                <Trash2 className="w-4 h-4 text-destructive" />
              </button>
            </div>
          </div>
        ))}
      </div>
      
      <button className="w-full p-3 border border-dashed border-border rounded-lg text-sm text-muted-foreground hover:text-foreground hover:border-border/80 transition-colors">
        + Create Role
      </button>
    </div>
  );
}

// Tools Tab
function ToolsTab({ tools, toggleTool }: { tools: any[]; toggleTool: (id: string) => void }) {
  const categories = ['file-system', 'web', 'database', 'communication', 'code', 'ai'];
  
  return (
    <div className="space-y-6">
      <p className="text-sm text-muted-foreground">
        Enable or disable tools available to agents in this workspace.
      </p>
      
      {categories.map(category => {
        const categoryTools = tools.filter(t => t.category === category);
        if (categoryTools.length === 0) return null;
        
        return (
          <div key={category} className="space-y-2">
            <h3 className="text-xs font-semibold uppercase text-muted-foreground">
              {category.replace('-', ' ')}
            </h3>
            <div className="space-y-1">
              {categoryTools.map(tool => (
                <div 
                  key={tool.id} 
                  className="flex items-center justify-between p-3 bg-card rounded-lg border border-border"
                >
                  <div className="flex items-center gap-3">
                    <Wrench className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <div className="font-medium text-sm">{tool.name}</div>
                      <div className="text-xs text-muted-foreground">{tool.description}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs text-muted-foreground">{tool.usageCount} uses</span>
                    <button
                      onClick={() => toggleTool(tool.id)}
                      className={`w-10 h-5 rounded-full transition-colors ${tool.enabled ? '' : 'bg-muted'} relative`}
                      style={tool.enabled ? { backgroundColor: 'var(--agent-active)' } : undefined}
                    >
                      <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${tool.enabled ? 'left-5' : 'left-0.5'}`} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// Channels Tab
function ChannelsTab({ workspace }: { workspace: any }) {
  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Manage channels and categories in your workspace.
      </p>
      
      {workspace.categories.map((category: any) => (
        <div key={category.id} className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-semibold uppercase text-muted-foreground">
              {category.name}
            </h3>
            <button className="text-xs text-muted-foreground hover:text-foreground">
              + Add Channel
            </button>
          </div>
          <div className="space-y-1">
            {category.channels.map((channel: any) => (
              <div 
                key={channel.id} 
                className="flex items-center justify-between p-3 bg-card rounded-lg border border-border"
              >
                <div className="flex items-center gap-2">
                  <Hash className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">{channel.name}</span>
                  {channel.unreadCount > 0 && (
                    <span className="px-1.5 py-0.5 text-xs bg-destructive text-destructive-foreground rounded-full">
                      {channel.unreadCount}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-1 hover:bg-accent rounded">
                    <Bell className="w-4 h-4 text-muted-foreground" />
                  </button>
                  <button className="p-1 hover:bg-accent rounded">
                    <Settings className="w-4 h-4 text-muted-foreground" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
      
      <button className="w-full p-3 border border-dashed border-border rounded-lg text-sm text-muted-foreground hover:text-foreground hover:border-border/80 transition-colors">
        + Create Category
      </button>
    </div>
  );
}

// Safety Tab
function SafetyTab() {
  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Configure safety settings and guardrails for agent behavior.
      </p>
      
      <div className="space-y-2">
        <SettingRow 
          label="Require Human Approval" 
          description="Require human approval for high-risk actions"
          enabled={true}
        />
        <SettingRow 
          label="Content Filtering" 
          description="Filter harmful or inappropriate content"
          enabled={true}
        />
        <SettingRow 
          label="Rate Limiting" 
          description="Limit API calls per minute"
          value="100/min"
        />
        <SettingRow 
          label="Audit Logging" 
          description="Log all agent actions for review"
          enabled={true}
        />
        <SettingRow 
          label="Emergency Stop" 
          description="Enable emergency stop functionality"
          enabled={true}
        />
      </div>
    </div>
  );
}



